# StreamForge Studio — Live Production & Church Media Suite

**[Richard Lukeman | +2347030518468] designed this software for churches. Send a DM.**

StreamForge Studio is a broadcast control room and church media suite inspired by OBS Studio and vMix. It provides GPU-accelerated compositing, multi-camera capture, NDI/SRT/RTMP/WebRTC streams, Zoom meeting integration, offline Bible scripture lookups, Praise & Worship lyrics projection, and 4-slot vMix-style overlays.

---

## Developer & Contact
- **Developer Name:** Richard Lukeman
- **Phone / WhatsApp:** +2347030518468
- **Church Media Deployment & Support:** Send a DM directly to the number above.

---

## 1. Quick Web App Usage (Zero-CMD for Non-Technical Users)
1. Run `npm run build` once to create the self-contained bundle at `dist/index.html`.
2. **Double-Click & Run:** Non-technical operators do **NOT** need Command Prompt (`cmd`). Simply double-click `dist/index.html` to open StreamForge Studio in Microsoft Edge or Google Chrome.
3. **1-Click Desktop App Shortcut:**
   Create a desktop shortcut or batch file `Launch StreamForge.bat`:
   ```bat
   start msedge --app="%CD%\dist\index.html"
   ```
   Double-clicking this shortcut launches StreamForge Studio in its own native app window without address bars or terminal windows!

---

## 2. Plug and Play Portable Folder (No Install Needed)
To copy StreamForge Studio to a USB flash drive or another PC and run it immediately without installation:
1. Build the production files: `npm run build`
2. Create a folder named `StreamForge Studio` containing:
   - `dist/index.html` (the full app)
   - `Launch StreamForge.bat` (1-click app launcher)
   - `app.ico` (custom church logo icon)
3. Copy this folder to any Windows PC. When opened, the app automatically recognizes the system, initializes local camera/audio hardware and offline scripture caches, and runs instantly!

---

## 3. Building Standalone Windows Executable (.exe)
To package into a native Windows installer or standalone executable:
- **Tauri (.msi / .exe):**
  ```bash
  npm run build
  npm run tauri build
  ```
  The installer is produced in `src-tauri/target/release/bundle/msi/`.

- **Electron (.exe):**
  ```bash
  npm run build
  npx electron-builder --win nsis
  ```
  The installer is produced in `release/StreamForge Studio Setup.exe`.

---

## 4. Features & Controls
- **OBS-Style Layout:** Scenes, Sources, Audio Mixer, Scene Transitions, and Controls docked at the bottom.
- **Offline Scripture Engine:** Complete KJV text offline, autocomplete book/chapter/verse, and Live Verse Listening.
- **Praise & Worship Engine:** Global song lyrics search (online + offline cache), lower thirds, and full-screen Roma font layout.
- **4-Slot Overlays:** vMix-style 1, 2, 3, 4 overlay buttons on every source.
- **Zoom Bridge:** Native meeting window with real camera, mic, and screen share capture.
