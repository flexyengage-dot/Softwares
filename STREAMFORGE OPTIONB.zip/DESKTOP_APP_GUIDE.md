# StreamForge Studio — Desktop & Portable App Guide

**[Richard Lukeman | +2347030518468] designed this software for churches. Send a DM.**

StreamForge Studio is a lightweight, OBS/vMix-class broadcast console that runs as a
web app **and** can be packaged into a native **Windows / macOS / Linux desktop app**
or a 1-click Plug and Play portable folder. This guide covers all installation methods.

---

## 1. Run it as a web app (fastest)

```bash
npm install
npm run dev        # opens http://localhost:5173
```

To create the production build (a single self-contained `dist/index.html`):

```bash
npm run build
npm run preview    # serves the built file locally
```

Because the build inlines everything into one HTML file, you can also just
**double-click `dist/index.html`** to run it in any modern browser.

---

## 2. Package it as a native Desktop App (Tauri)

Tauri wraps the web build in a tiny native window (a few MB, not hundreds like
Electron). It gives you a real app icon, a taskbar entry, global hotkeys, and a
proper installer (`.msi` / `.exe` on Windows, `.dmg` on macOS, `.AppImage`/`.deb`
on Linux).

### Prerequisites (one time)

- **Node.js 18+**
- **Rust** — install from <https://rustup.rs>
- **Windows:** Microsoft C++ Build Tools + WebView2 (ships with Windows 11)
- **macOS:** Xcode Command Line Tools (`xcode-select --install`)
- **Linux:** `webkit2gtk`, `libappindicator`, `librsvg` dev packages

### Steps

```bash
# 1) from the project root, add Tauri to this app
npm install -D @tauri-apps/cli
npx tauri init
#    When prompted:
#      • App name ............. StreamForge Studio
#      • Window title ......... StreamForge Studio
#      • Web assets (dist) .... ../dist
#      • Dev server URL ....... http://localhost:5173
#      • Dev command .......... npm run dev
#      • Build command ........ npm run build

# 2) run it as a desktop window during development
npx tauri dev

# 3) produce the installer
npx tauri build
```

The finished installer is written to:

```
src-tauri/target/release/bundle/
├─ msi/     StreamForge Studio_x64_en-US.msi     (Windows installer)
├─ nsis/    StreamForge Studio_x64-setup.exe     (Windows setup)
├─ dmg/     StreamForge Studio.dmg               (macOS)
└─ appimage/ StreamForge Studio.AppImage         (Linux)
```

Run the installer and StreamForge Studio appears in your Start Menu / Applications
like any other program.

> **Tip:** For the smoothest low-latency capture on Windows, keep WebView2 updated —
> it provides the GPU-accelerated compositor the app renders through.

---

## 3. Using the console

### Layout at a glance
- **Left rail** — Scenes, the **Add Input** button, the vMix-style **Input Boxes**,
  source transform/zoom properties, and the **Zoom Bridge**.
- **Center** — **Preview** (left) and **Program** (right) monitors with the vertical
  **Transition tower** and the red/green **FULLSCREEN** button between them, and the
  collapsible **Multiview** underneath.
- **Right rail** — the **Audio Mixer** (with monitor-source select), **Stream
  Control** (encoder, resolution, destination, recording format & path), and the
  **Event Log**.

### Adding inputs (one button, like vMix)
Click **+ ADD INPUT** to open a single dialog holding every input command, grouped
into Capture / Files / Graphics / Zoom Meeting. Selecting one drops it into the
current Preview scene. **Picture File** and **Video File** open a real file picker.

### Input Boxes (the tiles)
Each added input becomes a live tile with:
- **✕ Close** (top-right) — removes that input; the empty slot remains.
- **👁 Visibility** — show/hide the input on Program.
- **▶ / ⏸ Play-Pause** — for video/media inputs (single toggling icon).
- **⟳ Loop** — loop the clip.
- **🔊 / 🔇 Audio** — mute/un-mute just that input's audio (so a clip can play
  silently under other audio, then tap again to bring the sound back).

### Editing a source
Click a tile to select it, then **double-click the Preview monitor** to open the
**Source Transform** dialog — crop (L/R/T/B), zoom, and **Angle X / Angle Y**.
You can also drag to move, drag corners to resize, and scroll to zoom directly.

### Going to air
Load Preview, pick a transition on the tower, drag the vertical **T-bar** or press
**AUTO**/**CUT**. **FTB** fades to black. Press **FULLSCREEN** (turns **green**) to
push Program to a connected external monitor; press again (turns **red**) to stop.

### Zoom Bridge
Enter the externally-provided Zoom username/password and **Connect**. Once linked,
choose the **Send to → PREVIEW / PROGRAM** target, then **SEND** any participant to
that output, or drop the whole gallery grid in.

### Recording
In Stream Control, choose the **REC format** (MKV/MP4/WebM/MOV) and the **Save to**
folder, then press **REC**. The write path and running file size show live.

### Keyboard shortcuts
`C` Cut · `A` Auto · `F` FTB · `L` Live · `R` Record · `1–6` scenes · `Esc` deselect

### Persistence
Your scenes, inputs, mixer and settings **autosave to the browser/app storage** and
restore on next launch. Use **File ▸ Export / Import** to move a scene collection
between machines, and **File ▸ Save layout now** to force a save.

---

Enjoy the show. 🎬
