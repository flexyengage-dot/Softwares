export type SfxKind = "tick" | "select" | "whoosh" | "thud" | "chime" | "deny" | "low";

let ctx: AudioContext | null = null;
let noiseBuf: AudioBuffer | null = null;
let enabled = true;

function ac(): AudioContext | null {
  try {
    if (!ctx) {
      const AC =
        window.AudioContext ??
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AC) return null;
      ctx = new AC();
      const len = Math.floor(ctx.sampleRate * 0.35);
      noiseBuf = ctx.createBuffer(1, len, ctx.sampleRate);
      const d = noiseBuf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    }
    if (ctx.state === "suspended") void ctx.resume();
    return ctx;
  } catch {
    return null;
  }
}

/** Fully synthesized console audio — no assets, gesture-safe. */
export const sfx = {
  setEnabled(v: boolean) {
    enabled = v;
  },
  play(kind: SfxKind, durMs = 420) {
    if (!enabled) return;
    const c = ac();
    if (!c || !noiseBuf) return;
    try {
      const t0 = c.currentTime + 0.005;
      const out = c.createGain();
      out.connect(c.destination);

      const osc = (type: OscillatorType, f0: number, f1: number, peak: number, dur: number, at = 0) => {
        const o = c.createOscillator();
        const g = c.createGain();
        o.type = type;
        o.frequency.setValueAtTime(f0, t0 + at);
        o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t0 + at + dur);
        g.gain.setValueAtTime(0.0001, t0 + at);
        g.gain.exponentialRampToValueAtTime(peak, t0 + at + 0.012);
        g.gain.exponentialRampToValueAtTime(0.0001, t0 + at + dur);
        o.connect(g).connect(out);
        o.start(t0 + at);
        o.stop(t0 + at + dur + 0.02);
      };

      const noise = (peak: number, dur: number, f0: number, f1: number) => {
        const src = c.createBufferSource();
        src.buffer = noiseBuf;
        const bp = c.createBiquadFilter();
        bp.type = "bandpass";
        bp.Q.value = 0.9;
        bp.frequency.setValueAtTime(f0, t0);
        bp.frequency.exponentialRampToValueAtTime(f1, t0 + dur);
        const g = c.createGain();
        g.gain.setValueAtTime(0.0001, t0);
        g.gain.exponentialRampToValueAtTime(peak, t0 + 0.03);
        g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
        src.connect(bp).connect(g).connect(out);
        src.start(t0);
        src.stop(t0 + dur + 0.02);
      };

      switch (kind) {
        case "tick":
          osc("square", 1900, 1500, 0.035, 0.035);
          break;
        case "select":
          osc("sine", 760, 520, 0.05, 0.07);
          break;
        case "whoosh":
          noise(0.11, Math.min(durMs, 1200) / 1000, 260, 2600);
          break;
        case "thud":
          osc("sine", 150, 44, 0.16, 0.15);
          break;
        case "chime":
          osc("sine", 660, 655, 0.055, 0.3);
          osc("sine", 990, 984, 0.05, 0.34, 0.09);
          break;
        case "deny":
          osc("sawtooth", 150, 110, 0.06, 0.13);
          break;
        case "low":
          osc("sine", 96, 58, 0.1, 0.45);
          break;
      }
    } catch {
      /* audio must never break the console */
    }
  },
};
