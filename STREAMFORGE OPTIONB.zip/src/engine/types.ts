export const CW = 1920;
export const CH = 1080;

export type SourceType =
  | "camera"
  | "live-cam"
  | "display"
  | "browser"
  | "image"
  | "image-file"
  | "video-file"
  | "color"
  | "text"
  | "media"
  | "zoom-guest"
  | "zoom-grid"
  | "ndi"
  | "gt"
  | "stinger"
  | "srt-listener"
  | "srt-caller"
  | "webrtc"
  | "rtmp"
  | "worship"
  | "bible";

/** network inputs each spawn their own dedicated scene on init */
export const NETWORK_TYPES: SourceType[] = ["srt-listener", "srt-caller", "webrtc", "rtmp"];

export interface Participant {
  id: string;
  name: string;
  initials: string;
  hue: number;
  camOn: boolean;
  micOn: boolean;
  talking: boolean;
}

export interface Src {
  id: string;
  name: string;
  type: SourceType;
  x: number;
  y: number;
  w: number;
  h: number;
  /** original (100% zoom) size */
  bw: number;
  bh: number;
  visible: boolean;
  hue: number;
  seed: number;
  text?: string;
  color?: string;
  participantId?: string;
  url?: string;
  assetId?: string;
  /** crop per side, % of width/height (0–45) */
  cropL?: number;
  cropR?: number;
  cropT?: number;
  cropB?: number;
  /** projected rotation about each axis, degrees (±85) */
  angleX?: number;
  angleY?: number;
  /** media transport — used by video/media inputs */
  playing?: boolean;
  loop?: boolean;
  /** per-input audio mute (independent of the mixer bus) */
  audioMuted?: boolean;
  audioVol?: number;
  /** scripture card backdrop: transparent | solid | default art | own image */
  bibleBg?: "transparent" | "solid" | "default" | "image";
  bibleBgColor?: string;
  bibleBgVariant?: number;
  bibleBgAsset?: string;
  /** worship lyric display: lower-third strip or centred full-screen */
  worshipMode?: "lower" | "full";
  worshipFont?: string;
  worshipBg?: string;
}

export interface SceneDef {
  id: string;
  name: string;
  sources: Src[];
}

export interface AudioChannel {
  id: string;
  name: string;
  kind: "mic" | "zoom" | "desktop" | "media" | "music" | "master";
  volume: number;
  muted: boolean;
  /** user-selected hardware routing (set via the I/O dialog) */
  inputDevice?: string;
  outputDevice?: string;
  monitorMode?: "off" | "monitor" | "both";
}

export const AUDIO_INPUTS = [
  "Default Microphone",
  "Focusrite Scarlett 2i2 (USB)",
  "Shure MV7 (USB)",
  "Rode NT-USB Mini",
  "System Audio (loopback)",
  "Zoom Bridge Mix",
];
export const AUDIO_OUTPUTS = [
  "System Default",
  "Speakers (Realtek)",
  "Headphones (Focusrite USB)",
  "External Monitor Speakers",
  "NDI / Stream Embed Only",
];

export type TransitionKind = "cut" | "fade" | "wipe" | "zoom" | "dip";

export interface StudioModel {
  scenes: SceneDef[];
  previewId: string;
  programId: string;
  selectedId: string | null;
  trans: { active: boolean; kind: TransitionKind; t: number; dur: number; from: string; to: string };
  transKind: TransitionKind;
  transDur: number;
  ftb: { alpha: number; target: number };
  live: boolean;
  recording: boolean;
  liveStart: number;
  recStart: number;
  safeAreas: boolean;
  showMultiview: boolean;
  /** vMix-style overlay slots: source ids composited ON TOP of Program (1–4) */
  overlays: (string | null)[];
  /** once the first scripture lands in Preview, later verses go straight to Program */
  bibleArmed: boolean;
  zoom: {
    phase: "idle" | "connecting" | "connected";
    step: number;
    meetingId: string;
    user: string;
    sendTarget: "preview" | "program";
    participants: Participant[];
  };
  audio: AudioChannel[];
  audioMonitor: string;
  metrics: {
    fps: number;
    frameMs: number;
    latency: number;
    dropped: number;
    cpu: number;
    gpu: number;
    bitrate: number;
    buffer: number;
    jitter: number;
  };
  events: { t: number; msg: string; kind: "info" | "ok" | "warn" }[];
  viewers: number;
  sound: boolean;
  encoder: string;
  outputRes: string;
  dest: string;
  streamKey: string;
  recFormat: string;
  recPath: string;
  /* general / theme */
  theme: "dark" | "obs" | "light" | "midnight";
  language: string;
  confirmGoLive: boolean;
  autoRemux: boolean;
  /* video */
  baseCanvas: string;
  outputScaled: string;
  fpsTarget: number;
  scaleFilter: "bilinear" | "bicubic" | "lanczos" | "area";
  /* audio */
  sampleRate: 44100 | 48000;
  audioChannels: 1 | 2 | 6;
  monitorDevice: string;
  peakMeterType: "sample" | "true";
  /* advanced */
  processPriority: "idle" | "below-normal" | "normal" | "above-normal" | "high";
  colorFormat: "NV12" | "I420" | "P010" | "RGB";
  colorSpace: "601" | "709" | "2100-PQ" | "2100-HLG";
  colorRange: "partial" | "full";
  browserHwAccel: boolean;
  lowLatencyAudio: boolean;
  /* hotkeys */
  hotkeys: Record<string, string>;
}

let n = 0;
export const uid = (p = "s") => `${p}${Date.now().toString(36)}${(n++).toString(36)}`;
export const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
/** deterministic per-seed pseudo random 0..1 */
export const rnd = (seed: number, i: number) => {
  const v = Math.sin(seed * 127.1 + i * 311.7) * 43758.5453;
  return v - Math.floor(v);
};



export function makeParticipants(): Participant[] {
  return [
    { id: "p1", name: "Amara Chen", initials: "AC", hue: 158, camOn: true, micOn: true, talking: true },
    { id: "p2", name: "David Okafor", initials: "DO", hue: 24, camOn: true, micOn: true, talking: false },
    { id: "p3", name: "Priya Nair", initials: "PN", hue: 268, camOn: true, micOn: false, talking: false },
    { id: "p4", name: "Leo Martins", initials: "LM", hue: 204, camOn: false, micOn: true, talking: false },
    { id: "p5", name: "Sofia Reyes", initials: "SR", hue: 336, camOn: true, micOn: true, talking: false },
  ];
}

/** OBS-style: scenes list starts completely empty. All creation via + button. */
export function makeInitialScenes(): SceneDef[] {
  return [];
}

export function makeAudio(): AudioChannel[] {
  return [
    { id: "ch-mic", name: "HOST MIC", kind: "mic", volume: 82, muted: false },
    { id: "ch-zoom", name: "ZOOM", kind: "zoom", volume: 74, muted: false },
    { id: "ch-desk", name: "DESKTOP", kind: "desktop", volume: 58, muted: false },
    { id: "ch-media", name: "MEDIA", kind: "media", volume: 66, muted: false },
    { id: "ch-music", name: "MUSIC", kind: "music", volume: 40, muted: true },
    { id: "ch-master", name: "MASTER", kind: "master", volume: 88, muted: false },
  ];
}

export function makeModel(): StudioModel {
  const scenes = makeInitialScenes();
  return {
    scenes,
    previewId: "",
    programId: "",
    selectedId: null,
    trans: { active: false, kind: "fade", t: 0, dur: 500, from: "", to: "" },
    transKind: "fade",
    transDur: 500,
    ftb: { alpha: 0, target: 0 },
    live: false,
    recording: false,
    liveStart: 0,
    recStart: 0,
    safeAreas: false,
    showMultiview: true,
    overlays: [null, null, null, null],
    bibleArmed: false,
    zoom: { phase: "idle", step: 0, meetingId: "894 2210 7731", user: "", sendTarget: "preview", participants: makeParticipants() },
    audio: makeAudio(),
    audioMonitor: "ch-master",
    metrics: { fps: 60, frameMs: 16.6, latency: 11, dropped: 0, cpu: 14, gpu: 22, bitrate: 6000, buffer: 62, jitter: 3 },
    events: [
      { t: Date.now() - 4000, msg: "Scene collection loaded — 6 scenes", kind: "info" },
      { t: Date.now() - 2200, msg: "Pipeline ready — GPU composite @ 60Hz", kind: "ok" },
      { t: Date.now() - 700, msg: "Zoom bridge on standby", kind: "info" },
    ],
    viewers: 0,
    sound: true,
    encoder: "nvenc",
    outputRes: "1080p60",
    dest: "twitch",
    streamKey: "",
    recFormat: "mkv",
    recPath: "C:\\Users\\Operator\\Videos\\StreamForge",
    theme: "obs",
    language: "en-US",
    confirmGoLive: true,
    autoRemux: true,
    baseCanvas: "1920x1080",
    outputScaled: "1920x1080",
    fpsTarget: 60,
    scaleFilter: "lanczos",
    sampleRate: 48000,
    audioChannels: 2,
    monitorDevice: "System Default",
    peakMeterType: "true",
    processPriority: "normal",
    colorFormat: "NV12",
    colorSpace: "709",
    colorRange: "partial",
    browserHwAccel: true,
    lowLatencyAudio: true,
    hotkeys: {
      cut: "C",
      auto: "A",
      ftb: "F",
      live: "L",
      record: "R",
      scenePrev: "PageUp",
      sceneNext: "PageDown",
    },
  };
}

export const REC_FORMATS: { v: string; label: string }[] = [
  { v: "mkv", label: "MKV" },
  { v: "mp4", label: "MP4" },
  { v: "webm", label: "WebM" },
  { v: "mov", label: "MOV" },
];

export const DESTS: { v: string; label: string }[] = [
  { v: "twitch", label: "Twitch RTMP" },
  { v: "youtube", label: "YouTube Live" },
  { v: "zoom", label: "Zoom Bridge" },
  { v: "custom", label: "Custom RTMP" },
];
export const destLabel = (v: string) => DESTS.find((d) => d.v === v)?.label ?? v;

export const ENCODERS: { v: string; label: string }[] = [
  { v: "nvenc", label: "NVENC H.264" },
  { v: "x264", label: "x264 (CPU)" },
  { v: "av1", label: "AV1 — SVT" },
];
export const RESOLUTIONS: { v: string; label: string }[] = [
  { v: "1080p60", label: "1080p60" },
  { v: "1080p30", label: "1080p30" },
  { v: "720p60", label: "720p60" },
  { v: "2160p30", label: "2160p30" },
];
export const encLabel = (v: string) => ENCODERS.find((e) => e.v === v)?.label ?? v;

/* ------------------------------ persistence ------------------------------ */

export const SAVE_KEY = "streamforge.layout.v1";

export function saveModel(m: StudioModel): boolean {
  try {
    localStorage.setItem(
      SAVE_KEY,
      JSON.stringify({
        v: 1,
        savedAt: Date.now(),
        scenes: m.scenes,
        audio: m.audio,
        encoder: m.encoder,
        outputRes: m.outputRes,
        dest: m.dest,
        streamKey: m.streamKey,
        recFormat: m.recFormat,
        recPath: m.recPath,
        audioMonitor: m.audioMonitor,
        sound: m.sound,
        transKind: m.transKind,
        transDur: m.transDur,
        safeAreas: m.safeAreas,
        showMultiview: m.showMultiview,
        previewId: m.previewId,
        programId: m.programId,
        zoomUser: m.zoom.user,
      }),
    );
    return true;
  } catch {
    return false;
  }
}

export function loadSave(): Record<string, unknown> | null {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    return raw ? (JSON.parse(raw) as Record<string, unknown>) : null;
  } catch {
    return null;
  }
}

export function applySave(m: StudioModel, d: Record<string, unknown>) {
  const scenes = d.scenes;
  if (
    Array.isArray(scenes) &&
    scenes.length > 0 &&
    scenes.every((s) => s && typeof s === "object" && typeof (s as SceneDef).id === "string" && Array.isArray((s as SceneDef).sources))
  ) {
    m.scenes = scenes as SceneDef[];
  }
  const ids = m.scenes.map((s) => s.id);
  if (typeof d.previewId === "string" && ids.includes(d.previewId)) m.previewId = d.previewId;
  else m.previewId = ids[0];
  if (typeof d.programId === "string" && ids.includes(d.programId)) m.programId = d.programId;
  else m.programId = ids[0];
  const audio = d.audio;
  if (Array.isArray(audio)) {
    for (const saved of audio as AudioChannel[]) {
      const ch = m.audio.find((c) => c.id === saved?.id);
      if (ch && typeof saved.volume === "number") {
        ch.volume = clamp(saved.volume, 0, 100);
        ch.muted = !!saved.muted;
      }
    }
  }
  for (const k of ["encoder", "outputRes", "dest", "streamKey", "transKind", "recFormat", "recPath", "audioMonitor"] as const) {
    if (typeof d[k] === "string") (m as unknown as Record<string, string>)[k] = d[k] as string;
  }
  if (typeof d.transDur === "number") m.transDur = clamp(d.transDur, 100, 4000);
  if (typeof d.sound === "boolean") m.sound = d.sound;
  if (typeof d.safeAreas === "boolean") m.safeAreas = d.safeAreas;
  if (typeof d.showMultiview === "boolean") m.showMultiview = d.showMultiview;
  if (typeof d.zoomUser === "string") m.zoom.user = d.zoomUser;
  m.selectedId = null;
  m.trans.active = false;
}

export const SOURCE_META: { type: SourceType; label: string }[] = [
  { type: "live-cam", label: "USB / Built-in Camera" },
  { type: "camera", label: "IP Camera (WiFi / LAN)" },
  { type: "image-file", label: "Picture File" },
  { type: "video-file", label: "Video File" },
  { type: "display", label: "Display" },
  { type: "browser", label: "Browser" },
  { type: "media", label: "Media File" },
  { type: "image", label: "Image" },
  { type: "text", label: "Text / GFX" },
  { type: "color", label: "Color Fill" },
  { type: "zoom-grid", label: "Zoom Grid" },
  { type: "zoom-guest", label: "Zoom Guest" },
  { type: "ndi", label: "NDI Source" },
  { type: "gt", label: "GT Titles" },
  { type: "stinger", label: "Text Stinger" },
];
