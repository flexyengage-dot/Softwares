import { clamp } from "./types";

export type IoState = "idle" | "starting" | "live" | "denied";

type BufParam = Parameters<AnalyserNode["getByteTimeDomainData"]>[0];

/**
 * Singleton live-I/O bus: real camera frames + real microphone energy.
 * Everything is opt-in (started from a user gesture) so the app never
 * prompts on load and never logs errors when permission is withheld.
 */
class CaptureBus {
  camState: IoState = "idle";
  micState: IoState = "idle";
  video: HTMLVideoElement | null = null;
  /** smoothed RMS mic energy 0..1 */
  level = 0;

  private camStream: MediaStream | null = null;
  private micStream: MediaStream | null = null;
  private audioCtx: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private buf: Uint8Array | null = null;
  private listeners = new Set<() => void>();

  subscribe(fn: () => void) {
    this.listeners.add(fn);
    return () => {
      this.listeners.delete(fn);
    };
  }
  private emit() {
    this.listeners.forEach((f) => f());
  }

  async startCamera(): Promise<boolean> {
    if (this.camState === "live" || this.camState === "starting") return this.camState === "live";
    this.camState = "starting";
    this.emit();
    try {
      const s = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false,
      });
      const v = document.createElement("video");
      v.srcObject = s;
      v.muted = true;
      v.playsInline = true;
      await v.play();
      this.camStream = s;
      this.video = v;
      this.camState = "live";
    } catch {
      this.camState = "denied";
    }
    this.emit();
    return this.camState === "live";
  }

  stopCamera() {
    this.camStream?.getTracks().forEach((t) => t.stop());
    this.camStream = null;
    this.video = null;
    this.camState = "idle";
    this.emit();
  }

  async startMic(): Promise<boolean> {
    if (this.micState === "live" || this.micState === "starting") return this.micState === "live";
    this.micState = "starting";
    this.emit();
    try {
      const s = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
      const Ctx = window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ctx = new Ctx();
      if (ctx.state === "suspended") await ctx.resume();
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 1024;
      analyser.smoothingTimeConstant = 0.55;
      ctx.createMediaStreamSource(s).connect(analyser);
      this.micStream = s;
      this.audioCtx = ctx;
      this.analyser = analyser;
      this.buf = new Uint8Array(analyser.fftSize);
      this.micState = "live";
    } catch {
      this.micState = "denied";
    }
    this.emit();
    return this.micState === "live";
  }

  stopMic() {
    this.micStream?.getTracks().forEach((t) => t.stop());
    void this.audioCtx?.close().catch(() => undefined);
    this.micStream = null;
    this.audioCtx = null;
    this.analyser = null;
    this.buf = null;
    this.level = 0;
    this.micState = "idle";
    this.emit();
  }

  /** called once per frame from the studio loop */
  tick() {
    if (this.analyser && this.buf) {
      this.analyser.getByteTimeDomainData(this.buf as BufParam);
      let sum = 0;
      for (let i = 0; i < this.buf.length; i++) {
        const d = (this.buf[i] - 128) / 128;
        sum += d * d;
      }
      const rms = Math.sqrt(sum / this.buf.length);
      const target = clamp(rms * 3.4, 0, 1);
      this.level += (target - this.level) * (target > this.level ? 0.5 : 0.18);
    }
  }

  hasVideo() {
    return !!this.video && this.video.readyState >= 2 && this.video.videoWidth > 0;
  }
  hasAudio() {
    return this.micState === "live";
  }
}

export const capture = new CaptureBus();
