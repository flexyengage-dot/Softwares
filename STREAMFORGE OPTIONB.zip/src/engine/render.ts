import { CW, CH, clamp, rnd, type Participant, type SceneDef, type Src, type StudioModel } from "./types";
import { capture } from "./capture";
import { assets } from "./assets";

type Ctx = CanvasRenderingContext2D;

/* ---------------------------------- helpers ---------------------------------- */

const rr = (ctx: Ctx, x: number, y: number, w: number, h: number, r: number) => {
  const q = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + q, y);
  ctx.arcTo(x + w, y, x + w, y + h, q);
  ctx.arcTo(x + w, y + h, x, y + h, q);
  ctx.arcTo(x, y + h, x, y, q);
  ctx.arcTo(x, y, x + w, y, q);
  ctx.closePath();
};

const mono = (px: number) => `500 ${px}px "IBM Plex Mono", monospace`;
const disp = (px: number, wt = 700) => `${wt} ${px}px "Barlow Condensed", "Arial Narrow", sans-serif`;

function clipRect(ctx: Ctx, x: number, y: number, w: number, h: number, r = 4) {
  ctx.save();
  rr(ctx, x, y, w, h, r);
  ctx.clip();
}

/* ------------------------------- source content ------------------------------- */

function drawCamera(ctx: Ctx, x: number, y: number, w: number, h: number, s: Src, t: number) {
  /* IP / network camera: render the real stream when attached */
  const asset = assets.get(s.assetId);
  if (asset && asset.ready) {
    if (asset.kind === "image") coverDraw(ctx, asset.img, asset.img.naturalWidth, asset.img.naturalHeight, x, y, w, h);
    else if (asset.kind === "video") coverDraw(ctx, asset.video, asset.video.videoWidth, asset.video.videoHeight, x, y, w, h);
    /* live badge */
    ctx.fillStyle = "rgba(0,0,0,0.55)";
    rr(ctx, x + w * 0.03, y + h * 0.04, w * 0.17, h * 0.06, 3);
    ctx.fill();
    ctx.fillStyle = "#e9edf3";
    ctx.font = mono(Math.max(8, h * 0.03));
    ctx.textAlign = "left";
    ctx.textBaseline = "middle";
    ctx.fillText("IP CAM • LIVE", x + w * 0.045, y + h * 0.072);
    return;
  }

  /* No stream attached — honest NO SIGNAL slate */
  const g = ctx.createLinearGradient(x, y, x, y + h);
  g.addColorStop(0, `hsl(${s.hue} 30% 12%)`);
  g.addColorStop(1, `hsl(${s.hue} 36% 5%)`);
  ctx.fillStyle = g;
  ctx.fillRect(x, y, w, h);

  /* NO SIGNAL slate — only real, capturable cameras belong here */
  drawSmpteBars(ctx, x, y, w, h * 0.5);
  ctx.fillStyle = "rgba(0,0,0,0.5)";
  ctx.fillRect(x, y + h * 0.5, w, h * 0.5);
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillStyle = "#ff6a5f";
  ctx.font = disp(h * 0.075, 600);
  ctx.fillText("NO SIGNAL", x + w / 2, y + h * 0.66);
  ctx.fillStyle = "#b6bfcc";
  ctx.font = mono(Math.max(8, h * 0.032));
  ctx.fillText("Open this source's properties and paste your", x + w / 2, y + h * 0.78);
  ctx.fillText("IP camera's MJPEG / HLS stream URL (same WiFi/LAN)", x + w / 2, y + h * 0.84);
  ctx.textAlign = "left";
  void t;
}

function drawSmpteBars(ctx: Ctx, x: number, y: number, w: number, h: number) {
  const cols = ["#b4b4b4", "#b4b40f", "#0fb4b4", "#0fb40f", "#b40fb4", "#b40f0f", "#0f0fb4"];
  const top = h * 0.62;
  cols.forEach((c, i) => {
    ctx.fillStyle = c;
    ctx.fillRect(x + (w / 7) * i, y, w / 7 + 1, top);
  });
  const mid = ["#0f0fb4", "#131313", "#b40fb4", "#131313", "#0fb4b4", "#131313", "#b4b4b4"];
  mid.forEach((c, i) => {
    ctx.fillStyle = c;
    ctx.fillRect(x + (w / 7) * i, y + top, w / 7 + 1, h * 0.1);
  });
  ctx.fillStyle = "#131313";
  ctx.fillRect(x, y + top + h * 0.1, w, h - top - h * 0.1);
}

function drawLiveCam(ctx: Ctx, x: number, y: number, w: number, h: number, s: Src, t: number) {
  if (capture.hasVideo() && capture.video) {
    const v = capture.video;
    const vr = v.videoWidth / v.videoHeight;
    const tr = w / h;
    let sw: number, sh: number, sx: number, sy: number;
    if (vr > tr) {
      sh = v.videoHeight; sw = sh * tr; sx = (v.videoWidth - sw) / 2; sy = 0;
    } else {
      sw = v.videoWidth; sh = sw / tr; sx = 0; sy = (v.videoHeight - sh) / 2;
    }
    ctx.drawImage(v, sx, sy, sw, sh, x, y, w, h);
    // gentle broadcast grade
    const grade = ctx.createLinearGradient(x, y, x, y + h);
    grade.addColorStop(0, "rgba(20,26,40,0.14)");
    grade.addColorStop(0.5, "rgba(0,0,0,0)");
    grade.addColorStop(1, "rgba(8,10,16,0.3)");
    ctx.fillStyle = grade;
    ctx.fillRect(x, y, w, h);
  } else if (capture.camState === "starting") {
    ctx.fillStyle = "#0d1016";
    ctx.fillRect(x, y, w, h);
    const bw = w * 0.5;
    for (let i = 0; i < 5; i++) {
      const ph = Math.abs(Math.sin(t * 3 + i * 0.8));
      ctx.fillStyle = `rgba(47,210,115,${0.25 + ph * 0.5})`;
      ctx.fillRect(x + (w - bw) / 2 + (bw / 5) * i, y + h * 0.52 - ph * h * 0.12, bw / 5 - 6, ph * h * 0.24 + 4);
    }
    ctx.fillStyle = "#8b95a6";
    ctx.font = disp(h * 0.055, 600);
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("ACQUIRING SIGNAL", x + w / 2, y + h * 0.34);
    ctx.textAlign = "left";
  } else {
    drawSmpteBars(ctx, x, y, w, h);
    ctx.fillStyle = "rgba(0,0,0,0.55)";
    const bw2 = w * 0.62, bh2 = h * 0.2;
    rr(ctx, x + (w - bw2) / 2, y + (h - bh2) / 2, bw2, bh2, 6);
    ctx.fill();
    ctx.fillStyle = "#e9edf3";
    ctx.font = disp(h * 0.075, 600);
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("NO SIGNAL", x + w / 2, y + h / 2 - h * 0.022);
    ctx.fillStyle = "#8b95a6";
    ctx.font = mono(Math.max(8, h * 0.032));
    ctx.fillText("enable CAM in the LIVE I/O rail", x + w / 2, y + h / 2 + h * 0.052);
    ctx.textAlign = "left";
  }

  // OSD: label + live tally
  ctx.fillStyle = "rgba(0,0,0,0.55)";
  rr(ctx, x + w * 0.03, y + h * 0.04, w * 0.19, h * 0.058, 3);
  ctx.fill();
  ctx.fillStyle = "#e9edf3";
  ctx.font = mono(Math.max(8, h * 0.03));
  ctx.textAlign = "left";
  ctx.textBaseline = "middle";
  ctx.fillText(s.name.toUpperCase().slice(0, 15), x + w * 0.045, y + h * 0.07);
  const liveDot = capture.camState === "live";
  const pulse = liveDot ? 0.45 + 0.55 * Math.abs(Math.sin(t * 2.6)) : 0.35;
  ctx.fillStyle = liveDot ? `rgba(255,68,56,${pulse})` : "rgba(103,113,129,0.8)";
  ctx.beginPath();
  ctx.arc(x + w * 0.95, y + h * 0.069, Math.max(3, w * 0.008), 0, Math.PI * 2);
  ctx.fill();
}

function drawDisplay(ctx: Ctx, x: number, y: number, w: number, h: number, s: Src, t: number) {
  const g = ctx.createLinearGradient(x, y, x + w, y + h);
  g.addColorStop(0, "#1a2230");
  g.addColorStop(1, "#0e1420");
  ctx.fillStyle = g;
  ctx.fillRect(x, y, w, h);

  // editor window
  const ex = x + w * 0.04, ey = y + h * 0.1, ew = w * 0.58, eh = h * 0.72;
  ctx.fillStyle = "#12161f";
  rr(ctx, ex, ey, ew, eh, 6);
  ctx.fill();
  ctx.fillStyle = "#1c2230";
  rr(ctx, ex, ey, ew, eh * 0.09, 6);
  ctx.fill();
  ctx.fillRect(ex, ey + eh * 0.05, ew, eh * 0.04);
  ["#ff5f57", "#febc2e", "#28c840"].forEach((c, i) => {
    ctx.fillStyle = c;
    ctx.beginPath();
    ctx.arc(ex + ew * 0.035 + i * ew * 0.032, ey + eh * 0.045, eh * 0.016, 0, Math.PI * 2);
    ctx.fill();
  });
  // scrolling code
  ctx.save();
  ctx.beginPath();
  ctx.rect(ex, ey + eh * 0.09, ew, eh * 0.91);
  ctx.clip();
  const lineH = eh * 0.062;
  const off = (t * lineH * 0.55) % lineH;
  const rows = Math.ceil(eh / lineH) + 2;
  for (let i = 0; i < rows; i++) {
    const li = i + Math.floor((t * 0.55));
    const lw = (0.25 + 0.6 * rnd(s.seed, li)) * ew * 0.62;
    const hue = [205, 150, 38, 275][li % 4];
    ctx.fillStyle = `hsla(${hue} 65% 62% / 0.55)`;
    ctx.fillRect(ex + ew * 0.09 + rnd(s.seed, li + 3) * ew * 0.14, ey + eh * 0.12 + i * lineH - off, lw, lineH * 0.34);
    ctx.fillStyle = "rgba(140,150,170,0.35)";
    ctx.fillRect(ex + ew * 0.03, ey + eh * 0.12 + i * lineH - off, ew * 0.028, lineH * 0.34);
  }
  ctx.restore();

  // metrics window
  const mx = x + w * 0.66, my = y + h * 0.22, mw = w * 0.3, mh = h * 0.5;
  ctx.fillStyle = "#151a26";
  rr(ctx, mx, my, mw, mh, 6);
  ctx.fill();
  ctx.fillStyle = "#8b95a6";
  ctx.font = disp(mh * 0.09, 600);
  ctx.textAlign = "left";
  ctx.textBaseline = "alphabetic";
  ctx.fillText("PIPELINE", mx + mw * 0.08, my + mh * 0.14);
  for (let i = 0; i < 9; i++) {
    const bh2 = (0.25 + 0.6 * Math.abs(Math.sin(t * 1.8 + i * 0.9))) * mh * 0.5;
    ctx.fillStyle = i > 6 ? "rgba(255,176,32,0.75)" : "rgba(47,210,115,0.7)";
    ctx.fillRect(mx + mw * 0.08 + i * mw * 0.098, my + mh * 0.86 - bh2, mw * 0.06, bh2);
  }

  // roaming cursor
  const px = x + w * (0.5 + 0.3 * Math.sin(t * 0.55));
  const py = y + h * (0.5 + 0.24 * Math.sin(t * 0.78 + 1.3));
  ctx.save();
  ctx.shadowColor = "rgba(0,0,0,0.6)";
  ctx.shadowBlur = 6;
  ctx.fillStyle = "#f2f5fa";
  ctx.beginPath();
  ctx.moveTo(px, py);
  ctx.lineTo(px + w * 0.018, py + w * 0.026);
  ctx.lineTo(px + w * 0.004, py + w * 0.026);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

function drawBrowser(ctx: Ctx, x: number, y: number, w: number, h: number, s: Src, t: number) {
  ctx.fillStyle = "#eef0f4";
  ctx.fillRect(x, y, w, h);
  // chrome bar
  ctx.fillStyle = "#d9dde5";
  ctx.fillRect(x, y, w, h * 0.07);
  ctx.fillStyle = "#f7f8fb";
  rr(ctx, x + w * 0.14, y + h * 0.018, w * 0.6, h * 0.036, h * 0.018);
  ctx.fill();
  ctx.fillStyle = "#9aa3b2";
  ctx.font = mono(h * 0.024);
  ctx.textAlign = "left";
  ctx.textBaseline = "middle";
  ctx.fillText((s.url ?? "streamforge.app/live-dashboard").replace(/^https?:\/\//, "").slice(0, 46), x + w * 0.16, y + h * 0.037);
  ["#ff5f57", "#febc2e", "#28c840"].forEach((c, i) => {
    ctx.fillStyle = c;
    ctx.beginPath();
    ctx.arc(x + w * 0.02 + i * w * 0.022, y + h * 0.036, h * 0.012, 0, Math.PI * 2);
    ctx.fill();
  });

  // scrolling page
  ctx.save();
  ctx.beginPath();
  ctx.rect(x, y + h * 0.07, w, h * 0.93);
  ctx.clip();
  const total = h * 1.6;
  const off = (t * h * 0.06) % total;
  const drawPass = (baseY: number) => {
    ctx.fillStyle = "#23304a";
    rr(ctx, x + w * 0.05, baseY + h * 0.05, w * 0.9, h * 0.2, 8);
    ctx.fill();
    ctx.fillStyle = "#2fd273";
    ctx.font = disp(h * 0.09);
    ctx.fillText("LIVE DASHBOARD", x + w * 0.09, baseY + h * 0.17);
    for (let i = 0; i < 7; i++) {
      ctx.fillStyle = i % 3 === 0 ? "#dfe3ea" : "#e8ebf1";
      rr(ctx, x + w * 0.05, baseY + h * (0.32 + i * 0.085), w * (0.55 + 0.35 * rnd(s.seed, i)), h * 0.05, 4);
      ctx.fill();
    }
    ctx.fillStyle = "#d3e8dc";
    rr(ctx, x + w * 0.05, baseY + h * 0.95, w * 0.42, h * 0.26, 8);
    ctx.fill();
    ctx.fillStyle = "#e3e8f0";
    rr(ctx, x + w * 0.52, baseY + h * 0.95, w * 0.43, h * 0.26, 8);
    ctx.fill();
  };
  drawPass(y + h * 0.07 - off);
  drawPass(y + h * 0.07 - off + total);
  ctx.restore();
}

function drawImage(ctx: Ctx, x: number, y: number, w: number, h: number, s: Src, t: number) {
  // Ken Burns breathing — the "zoom" showpiece for stills
  const kb = 1.06 + 0.05 * Math.sin(t * 0.22 + s.seed);
  ctx.save();
  ctx.translate(x + w / 2, y + h / 2);
  ctx.scale(kb, kb);
  ctx.translate(-(x + w / 2), -(y + h / 2));
  const hue = ((s.hue % 360) + 360) % 360;
  const g = ctx.createLinearGradient(x, y, x, y + h);
  g.addColorStop(0, `hsl(${hue} 74% 62%)`);
  g.addColorStop(0.55, `hsl(${hue + 24} 68% 46%)`);
  g.addColorStop(1, `hsl(${hue + 40} 55% 24%)`);
  ctx.fillStyle = g;
  ctx.fillRect(x - w * 0.08, y - h * 0.08, w * 1.16, h * 1.16);
  // sun
  const sx = x + w * (0.3 + 0.4 * rnd(s.seed, 5)), sy = y + h * 0.34;
  const sg = ctx.createRadialGradient(sx, sy, 0, sx, sy, h * 0.22);
  sg.addColorStop(0, "rgba(255,244,214,0.95)");
  sg.addColorStop(1, "transparent");
  ctx.fillStyle = sg;
  ctx.fillRect(x - w * 0.08, y - h * 0.08, w * 1.16, h * 1.16);
  // ridges
  for (let l = 0; l < 3; l++) {
    ctx.fillStyle = `hsla(${hue + 40} 50% ${16 - l * 4}% / ${0.75 + l * 0.12})`;
    ctx.beginPath();
    ctx.moveTo(x - w * 0.08, y + h);
    for (let i = 0; i <= 8; i++) {
      const px = x - w * 0.08 + (w * 1.16 * i) / 8;
      const py = y + h * (0.62 + l * 0.11) - rnd(s.seed, l * 31 + i) * h * (0.16 - l * 0.04);
      ctx.lineTo(px, py);
    }
    ctx.lineTo(x + w * 1.08, y + h);
    ctx.closePath();
    ctx.fill();
  }
  ctx.restore();
}

function drawMedia(ctx: Ctx, x: number, y: number, w: number, h: number, s: Src, t: number) {
  const g = ctx.createLinearGradient(x, y, x, y + h);
  g.addColorStop(0, "#141021");
  g.addColorStop(1, "#0b0912");
  ctx.fillStyle = g;
  ctx.fillRect(x, y, w, h);
  // spectrum
  const bars = 30;
  for (let i = 0; i < bars; i++) {
    const v = Math.abs(Math.sin(t * 2.4 + i * 0.55 + s.seed)) * 0.72 + 0.06;
    const bh2 = v * h * 0.52;
    const hue = s.hue + i * 3;
    ctx.fillStyle = `hsla(${hue} 80% 62% / 0.8)`;
    const bw = (w * 0.84) / bars;
    ctx.fillRect(x + w * 0.08 + i * bw, y + h * 0.68 - bh2, bw * 0.62, bh2);
  }
  // progress
  const p = (t * 0.045 + rnd(s.seed, 2)) % 1;
  ctx.fillStyle = "rgba(255,255,255,0.14)";
  rr(ctx, x + w * 0.08, y + h * 0.8, w * 0.84, h * 0.016, h * 0.008);
  ctx.fill();
  ctx.fillStyle = "#ffb020";
  rr(ctx, x + w * 0.08, y + h * 0.8, w * 0.84 * p, h * 0.016, h * 0.008);
  ctx.fill();
  ctx.fillStyle = "#b6bfcc";
  ctx.font = mono(Math.max(9, h * 0.032));
  ctx.textAlign = "left";
  ctx.textBaseline = "alphabetic";
  const sec = Math.floor(p * 94);
  ctx.fillText(`00:${String(sec).padStart(2, "0")} / 01:34`, x + w * 0.08, y + h * 0.77);
  ctx.textAlign = "right";
  ctx.fillText(`${s.name.toUpperCase().slice(0, 18)} • 1080p60`, x + w * 0.92, y + h * 0.77);
  ctx.textAlign = "left";
}

function drawText(ctx: Ctx, x: number, y: number, w: number, h: number, s: Src, t: number) {
  ctx.save();
  ctx.textAlign = "left";
  ctx.textBaseline = "middle";
  const size = h * 0.62;
  ctx.font = disp(size);
  try {
    (ctx as unknown as { letterSpacing: string }).letterSpacing = `${Math.round(size * 0.045)}px`;
  } catch {
    /* older canvas */
  }
  ctx.shadowColor = "rgba(0,0,0,0.55)";
  ctx.shadowBlur = h * 0.12;
  ctx.fillStyle = "#f2f5fa";
  ctx.fillText(s.text ?? "TEXT", x, y + h * 0.52);
  ctx.shadowBlur = 0;
  // accent underline sweep
  const tw = ctx.measureText(s.text ?? "TEXT").width;
  const sweep = 0.72 + 0.28 * Math.sin(t * 1.4 + s.seed);
  ctx.fillStyle = "#2fd273";
  ctx.fillRect(x, y + h * 0.88, Math.min(tw, w) * sweep, Math.max(2, h * 0.045));
  ctx.restore();
}

function participantOf(s: Src, participants: Participant[]) {
  return participants.find((p) => p.id === s.participantId);
}

function drawZoomGuest(
  ctx: Ctx, x: number, y: number, w: number, h: number,
  p: Participant | undefined, connected: boolean, t: number,
) {
  ctx.fillStyle = "#10141a";
  ctx.fillRect(x, y, w, h);
  if (!p || !connected) {
    ctx.fillStyle = "#1a2029";
    ctx.fillRect(x, y, w, h);
    ctx.fillStyle = "#67718199";
    ctx.font = disp(h * 0.09, 600);
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(connected ? "NO PARTICIPANT" : "ZOOM BRIDGE OFFLINE", x + w / 2, y + h / 2);
    ctx.textAlign = "left";
    return;
  }
  const hue = p.hue;
  const bg = ctx.createRadialGradient(x + w / 2, y + h * 0.42, h * 0.05, x + w / 2, y + h * 0.5, h * 0.9);
  bg.addColorStop(0, `hsl(${hue} 26% 20%)`);
  bg.addColorStop(1, `hsl(${hue} 24% 10%)`);
  ctx.fillStyle = bg;
  ctx.fillRect(x, y, w, h);

  if (p.camOn) {
    const bob = Math.sin(t * 1.2 + hue) * h * 0.008;
    const cx = x + w / 2, headR = h * 0.13, headY = y + h * 0.42 + bob;
    ctx.fillStyle = `hsl(${hue} 30% 30%)`;
    ctx.beginPath();
    ctx.arc(cx, headY, headR, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(cx, y + h * 0.9, w * 0.24, h * 0.3, 0, Math.PI, 0);
    ctx.fill();
    ctx.fillStyle = `hsl(${hue} 34% 38%)`;
    ctx.beginPath();
    ctx.arc(cx - headR * 0.28, headY - headR * 0.12, headR * 0.55, 0, Math.PI * 2);
    ctx.fill();
    // speaking glow ring
    if (p.talking) {
      ctx.strokeStyle = "#2fd273";
      ctx.lineWidth = Math.max(2, w * 0.006);
      ctx.setLineDash([w * 0.05, w * 0.025]);
      ctx.lineDashOffset = -t * w * 0.12;
      ctx.beginPath();
      ctx.arc(cx, headY, headR * 1.28, 0, Math.PI * 2);
      ctx.stroke();
      ctx.setLineDash([]);
    }
  } else {
    const r = h * 0.17;
    ctx.fillStyle = `hsl(${hue} 42% 30%)`;
    ctx.beginPath();
    ctx.arc(x + w / 2, y + h * 0.44, r, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#eef2f8";
    ctx.font = disp(r * 0.9);
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(p.initials, x + w / 2, y + h * 0.44 + r * 0.06);
    ctx.textAlign = "left";
    if (p.talking) {
      ctx.strokeStyle = "rgba(47,210,115,0.9)";
      ctx.lineWidth = Math.max(2, w * 0.005);
      ctx.beginPath();
      ctx.arc(x + w / 2, y + h * 0.44, r * 1.18 + Math.sin(t * 6) * 2, 0, Math.PI * 2);
      ctx.stroke();
    }
  }

  // name tag
  ctx.fillStyle = "rgba(0,0,0,0.62)";
  rr(ctx, x + w * 0.03, y + h * 0.88, w * 0.42, h * 0.085, 4);
  ctx.fill();
  ctx.fillStyle = "#e9edf3";
  ctx.font = `600 ${Math.max(8, h * 0.045)}px "IBM Plex Sans", sans-serif`;
  ctx.textBaseline = "middle";
  ctx.fillText(p.name, x + w * 0.05, y + h * 0.923);
  // mic state
  ctx.fillStyle = p.micOn ? "#2fd273" : "#ff4438";
  ctx.beginPath();
  ctx.arc(x + w * 0.93, y + h * 0.92, Math.max(3, w * 0.012), 0, Math.PI * 2);
  ctx.fill();
  // zoom tag
  ctx.fillStyle = "#2d8cff";
  rr(ctx, x + w * 0.03, y + h * 0.035, w * 0.13, h * 0.06, 3);
  ctx.fill();
  ctx.fillStyle = "#fff";
  ctx.font = disp(h * 0.04, 600);
  ctx.fillText("ZOOM", x + w * 0.045, y + h * 0.072);
}

function drawZoomGrid(
  ctx: Ctx, x: number, y: number, w: number, h: number,
  participants: Participant[], connected: boolean, t: number,
) {
  ctx.fillStyle = "#0c0f14";
  ctx.fillRect(x, y, w, h);
  const gap = w * 0.012;
  const cw = (w - gap * 3) / 2;
  const chh = (h - gap * 3) / 2;
  participants.slice(0, 4).forEach((p, i) => {
    const cx = x + gap + (i % 2) * (cw + gap);
    const cy = y + gap + Math.floor(i / 2) * (chh + gap);
    clipRect(ctx, cx, cy, cw, chh, 6);
    drawZoomGuest(ctx, cx, cy, cw, chh, p, connected, t);
    ctx.restore();
    if (p.talking) {
      ctx.strokeStyle = "rgba(47,210,115,0.95)";
      ctx.lineWidth = Math.max(2, w * 0.004);
      rr(ctx, cx + 2, cy + 2, cw - 4, chh - 4, 5);
      ctx.stroke();
    }
  });
  ctx.fillStyle = "rgba(0,0,0,0.6)";
  rr(ctx, x + w - w * 0.21, y + h * 0.03, w * 0.18, h * 0.055, 4);
  ctx.fill();
  ctx.fillStyle = "#e9edf3";
  ctx.font = mono(Math.max(8, h * 0.032));
  ctx.textAlign = "left";
  ctx.textBaseline = "middle";
  ctx.fillText(`${participants.length} IN MEETING`, x + w - w * 0.195, y + h * 0.058);
}

function drawFileMedia(ctx: Ctx, x: number, y: number, w: number, h: number, s: Src, t: number) {
  const a = assets.get(s.assetId);
  const isVideo = s.type === "video-file";

  if (!a) {
    ctx.fillStyle = "#0d1016";
    ctx.fillRect(x, y, w, h);
    ctx.strokeStyle = "rgba(255,68,56,0.35)";
    ctx.lineWidth = Math.max(1.5, w * 0.003);
    ctx.strokeRect(x + w * 0.02, y + h * 0.035, w * 0.96, h * 0.93);
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillStyle = "#ff6a5f";
    ctx.font = disp(h * 0.08, 600);
    ctx.fillText("MEDIA OFFLINE", x + w / 2, y + h * 0.44);
    ctx.fillStyle = "#8b95a6";
    ctx.font = mono(Math.max(8, h * 0.034));
    ctx.fillText(`${s.name} — re-add the file via ADD INPUT`, x + w / 2, y + h * 0.56);
    ctx.textAlign = "left";
    return;
  }

  if (!a.ready) {
    ctx.fillStyle = "#0d1016";
    ctx.fillRect(x, y, w, h);
    const bw = w * 0.4;
    const ph = (Math.sin(t * 4) + 1) / 2;
    ctx.fillStyle = "rgba(47,210,115,0.7)";
    ctx.fillRect(x + (w - bw) / 2, y + h * 0.56, bw * ph, Math.max(3, h * 0.014));
    ctx.strokeStyle = "rgba(47,210,115,0.25)";
    ctx.strokeRect(x + (w - bw) / 2, y + h * 0.56, bw, Math.max(3, h * 0.014));
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillStyle = "#b6bfcc";
    ctx.font = disp(h * 0.06, 600);
    ctx.fillText(`LOADING ${isVideo ? "VIDEO" : "PICTURE"}`, x + w / 2, y + h * 0.44);
    ctx.textAlign = "left";
    return;
  }

  if (a.kind === "image") {
    const el = a.img;
    const kb = 1.04 + 0.035 * Math.sin(t * 0.2 + s.seed);
    ctx.save();
    ctx.translate(x + w / 2, y + h / 2);
    ctx.scale(kb, kb);
    ctx.translate(-(x + w / 2), -(y + h / 2));
    coverDraw(ctx, el, el.naturalWidth, el.naturalHeight, x - w * 0.05, y - h * 0.05, w * 1.1, h * 1.1);
    ctx.restore();
  } else {
    const el = a.video;
    coverDraw(ctx, el, el.videoWidth, el.videoHeight, x, y, w, h);
  }

  // OSD chip
  ctx.fillStyle = "rgba(0,0,0,0.55)";
  rr(ctx, x + w * 0.025, y + h * 0.045, w * 0.3, h * 0.065, 3);
  ctx.fill();
  ctx.fillStyle = "#e9edf3";
  ctx.font = mono(Math.max(8, h * 0.032));
  ctx.textAlign = "left";
  ctx.textBaseline = "middle";
  ctx.fillText(s.name.toUpperCase().slice(0, 24), x + w * 0.04, y + h * 0.078);
  if (isVideo) {
    const pulse = 0.45 + 0.55 * Math.abs(Math.sin(t * 2.4));
    ctx.fillStyle = `rgba(47,210,115,${pulse})`;
    ctx.beginPath();
    ctx.arc(x + w * 0.95, y + h * 0.077, Math.max(3, w * 0.008), 0, Math.PI * 2);
    ctx.fill();
  }
}

function coverDraw(
  ctx: Ctx, el: CanvasImageSource, ew: number, eh: number,
  x: number, y: number, w: number, h: number,
) {
  if (!ew || !eh) return;
  const sr = ew / eh, tr = w / h;
  let sw: number, sh: number, sx: number, sy: number;
  if (sr > tr) {
    sh = eh; sw = sh * tr; sx = (ew - sw) / 2; sy = 0;
  } else {
    sw = ew; sh = sw / tr; sx = 0; sy = (eh - sh) / 2;
  }
  ctx.drawImage(el, sx, sy, sw, sh, x, y, w, h);
}

/* ----------------------------- broadcast extras ----------------------------- */

function drawNdi(ctx: Ctx, x: number, y: number, w: number, h: number, s: Src, t: number) {
  const anyS = s as unknown as Record<string, unknown>;
  const bridgeReady = Boolean(anyS.ndiBridgeReady);
  const g = ctx.createLinearGradient(x, y, x, y + h);
  g.addColorStop(0, `hsl(${s.hue} 32% 15%)`);
  g.addColorStop(1, `hsl(${s.hue} 38% 6%)`);
  ctx.fillStyle = g;
  ctx.fillRect(x, y, w, h);
  if (!bridgeReady) {
    ctx.fillStyle = "rgba(0,0,0,0.55)";
    ctx.fillRect(x, y, w, h);
    ctx.strokeStyle = "rgba(255,176,32,0.42)";
    ctx.lineWidth = Math.max(1, w * 0.003);
    ctx.setLineDash([w * 0.025, w * 0.015]);
    ctx.strokeRect(x + w * 0.05, y + h * 0.08, w * 0.9, h * 0.84);
    ctx.setLineDash([]);
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillStyle = "#ffb020";
    ctx.font = disp(h * 0.09, 700);
    ctx.fillText("NDI BRIDGE OFFLINE", x + w / 2, y + h * 0.43);
    ctx.fillStyle = "#b6bfcc";
    ctx.font = mono(Math.max(8, h * 0.035));
    ctx.fillText(String(anyS.ndiSource ?? s.name), x + w / 2, y + h * 0.55);
    ctx.fillText("Install/connect NDI bridge to receive real video", x + w / 2, y + h * 0.63);
    ctx.textAlign = "left";
    void t;
    return;
  }
  // rolling scanline feed
  for (let i = 0; i < 24; i++) {
    const ly = y + ((i * h) / 24 + t * h * 0.06) % h;
    ctx.fillStyle = `rgba(255,255,255,${0.015 + 0.02 * rnd(s.seed, i)})`;
    ctx.fillRect(x, ly, w, 2);
  }
  // silhouette
  const cx = x + w * 0.5, headR = h * 0.11, bob = Math.sin(t * 1.1) * h * 0.006;
  ctx.fillStyle = `hsl(${s.hue} 24% 9%)`;
  ctx.beginPath();
  ctx.arc(cx, y + h * 0.48 + bob, headR, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(cx, y + h * 0.9, w * 0.22, h * 0.28, 0, Math.PI, 0);
  ctx.fill();
  // NDI badge + source label
  ctx.fillStyle = "#0e7a5f";
  rr(ctx, x + w * 0.03, y + h * 0.04, w * 0.12, h * 0.07, 3);
  ctx.fill();
  ctx.fillStyle = "#eafff7";
  ctx.font = disp(h * 0.05, 600);
  ctx.textAlign = "left";
  ctx.textBaseline = "middle";
  ctx.fillText("NDI", x + w * 0.045, y + h * 0.08);
  ctx.fillStyle = "rgba(0,0,0,0.55)";
  rr(ctx, x + w * 0.03, y + h * 0.87, w * 0.44, h * 0.09, 3);
  ctx.fill();
  ctx.fillStyle = "#cfe8e0";
  ctx.font = mono(Math.max(8, h * 0.034));
  ctx.fillText(s.name.toUpperCase().slice(0, 28), x + w * 0.045, y + h * 0.915);
}

function drawGt(ctx: Ctx, x: number, y: number, w: number, h: number, s: Src, t: number) {
  const anyS = s as unknown as Record<string, unknown>;
  const align = (anyS.gtAlign as "left" | "center" | "right") ?? "center";
  const bgMode = (anyS.gtBg as "rect" | "card" | "bar" | "transparent") ?? "rect";
  const template = Math.floor(rnd(s.seed, 1) * 3);
  const title = s.text ?? "GT TITLES";
  const subtitle = s.url ?? "";
  const accents = ["#2fd273", "#ffb020", "#2d8cff"];
  const ac = accents[template % 3];

  ctx.font = disp(h * 0.2);
  const tw = ctx.measureText(title).width;
  ctx.font = disp(h * 0.075, 500);
  const sw = subtitle ? ctx.measureText(subtitle).width : 0;
  const blockW = Math.max(tw, sw) + w * 0.08;

  // horizontal anchor by alignment
  const ax = align === "left" ? x + w * 0.05 : align === "right" ? x + w * 0.95 : x + w * 0.5;
  const bx = align === "left" ? x + w * 0.05 : align === "right" ? x + w * 0.95 - blockW : x + (w - blockW) / 2;

  // background variants
  if (bgMode === "rect") {
    ctx.fillStyle = "#0b0d12";
    ctx.fillRect(x, y, w, h);
  } else if (bgMode === "card") {
    ctx.fillStyle = "rgba(11,13,18,0.78)";
    rr(ctx, bx, y + h * 0.14, blockW, h * 0.72, h * 0.08);
    ctx.fill();
  } else if (bgMode === "bar") {
    ctx.fillStyle = "rgba(11,13,18,0.85)";
    ctx.fillRect(bx, y + h * 0.58, blockW, h * 0.3);
  }
  // "transparent" draws no background

  // accent by alignment + template
  ctx.fillStyle = ac;
  if (bgMode === "rect") {
    if (template === 0) ctx.fillRect(x, y + h * 0.22, w, h * 0.012);
    if (template === 1) ctx.fillRect(x + (align === "right" ? w * 0.94 : w * 0.06), y + h * 0.18, w * 0.012, h * 0.64);
    if (template === 2) {
      ctx.beginPath();
      ctx.moveTo(x, y + h);
      ctx.lineTo(x + w * 0.35, y + h * 0.62);
      ctx.lineTo(x, y + h * 0.62);
      ctx.closePath();
      ctx.fill();
    }
  } else {
    // accent tick beside the text block
    const tickX = align === "right" ? bx + blockW + w * 0.01 : bx - w * 0.018;
    ctx.fillRect(align === "right" ? tickX : bx, y + h * 0.32, w * 0.008, h * 0.36);
  }

  ctx.textAlign = align;
  ctx.textBaseline = "middle";
  ctx.fillStyle = "#f2f5fa";
  ctx.font = disp(h * 0.2);
  ctx.fillText(title, ax, y + h * 0.45);
  if (subtitle) {
    ctx.fillStyle = "rgba(182,191,204,0.85)";
    ctx.font = disp(h * 0.075, 500);
    ctx.fillText(subtitle, ax, y + h * (bgMode === "bar" ? 0.73 : 0.63));
  }
  ctx.textAlign = "left";
  void t;
}

function drawStinger(ctx: Ctx, x: number, y: number, w: number, h: number, s: Src, t: number) {
  const anyS = s as unknown as Record<string, unknown>;
  const style = (anyS.stingerStyle as string) ?? "Scroll";
  const duration = Math.max(1, Number(anyS.stingerDuration ?? 8));
  const text = (s.text ?? "TEXT STINGER").toUpperCase();
  ctx.fillStyle = "rgba(10,12,16,0.92)";
  rr(ctx, x, y, w, h, 8);
  ctx.fill();
  const sweep = (t * 0.5 + rnd(s.seed, 2)) % 1;
  const g = ctx.createLinearGradient(x, 0, x + w, 0);
  g.addColorStop(clamp(sweep - 0.18, 0, 1), "transparent");
  g.addColorStop(sweep, "rgba(255,176,32,0.28)");
  g.addColorStop(clamp(sweep + 0.18, 0, 1), "transparent");
  ctx.fillStyle = g;
  rr(ctx, x, y, w, h, 8);
  ctx.fill();
  ctx.fillStyle = "#ffb020";
  ctx.fillRect(x, y + h * 0.42, w * 0.03, h * 0.16);

  ctx.save();
  rr(ctx, x + w * 0.04, y, w * 0.92, h, 6);
  ctx.clip();
  ctx.fillStyle = "#f2f5fa";
  ctx.font = disp(h * 0.34);
  const textW = ctx.measureText(text).width;
  let tx = x + w * 0.06;
  if (style === "Slide") {
    const p = (t / duration) % 1;
    tx = x + w * (0.06 + 0.16 * Math.sin(p * Math.PI * 2));
  } else if (style === "Flash") {
    ctx.globalAlpha = 0.55 + 0.45 * Math.abs(Math.sin(t * Math.PI * 1.8));
  } else {
    // default: continuous reader crawl from right to left.
    const p = (t / duration) % 1;
    tx = x + w - p * (w + textW + w * 0.14);
  }
  ctx.textAlign = "left";
  ctx.textBaseline = "middle";
  ctx.fillText(text, tx, y + h * 0.52);
  ctx.restore();
}

function drawNetwork(ctx: Ctx, x: number, y: number, w: number, h: number, s: Src, t: number) {
  const kind = s.type as "srt-listener" | "srt-caller" | "webrtc" | "rtmp";
  const META: Record<string, { label: string; color: string; state: string }> = {
    "srt-listener": { label: "SRT • LISTENER", color: "#2d8cff", state: "LISTENING" },
    "srt-caller": { label: "SRT • CALLER", color: "#2d8cff", state: "DIALING" },
    webrtc: { label: "WEBRTC PEER", color: "#2fd273", state: "NEGOTIATING" },
    rtmp: { label: "RTMP INGEST", color: "#ffb020", state: "RECEIVING" },
  };
  const meta = META[kind];
  const g = ctx.createLinearGradient(x, y, x, y + h);
  g.addColorStop(0, "#0d1420");
  g.addColorStop(1, "#080b12");
  ctx.fillStyle = g;
  ctx.fillRect(x, y, w, h);
  // grid
  ctx.strokeStyle = "rgba(45,140,255,0.07)";
  ctx.lineWidth = 1;
  for (let i = 1; i < 10; i++) {
    ctx.beginPath();
    ctx.moveTo(x + (w / 10) * i, y);
    ctx.lineTo(x + (w / 10) * i, y + h);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x, y + (h / 6) * i);
    ctx.lineTo(x + w, y + (h / 6) * i);
    ctx.stroke();
  }
  // travelling packets
  for (let i = 0; i < 6; i++) {
    const p = (t * 0.28 + i / 6 + rnd(s.seed, i)) % 1;
    const py = y + h * (0.3 + 0.1 * Math.sin(i * 2.2));
    ctx.fillStyle = meta.color;
    ctx.globalAlpha = 0.35 + 0.5 * (1 - p);
    ctx.fillRect(x + p * w * 0.92 + w * 0.04, py, w * 0.03, h * 0.018);
    ctx.globalAlpha = 1;
  }
  // badge
  ctx.fillStyle = meta.color;
  rr(ctx, x + w * 0.035, y + h * 0.05, w * 0.22, h * 0.085, 3);
  ctx.fill();
  ctx.fillStyle = "#06131f";
  ctx.font = disp(h * 0.055, 600);
  ctx.textAlign = "left";
  ctx.textBaseline = "middle";
  ctx.fillText(meta.label, x + w * 0.05, y + h * 0.095);
  // address
  ctx.fillStyle = "rgba(0,0,0,0.55)";
  rr(ctx, x + w * 0.035, y + h * 0.83, w * 0.5, h * 0.1, 3);
  ctx.fill();
  ctx.fillStyle = "#9fb4c8";
  ctx.font = mono(Math.max(8, h * 0.038));
  ctx.fillText(s.url ?? `${kind.includes("srt") ? "srt" : kind}://0.0.0.0:9000`, x + w * 0.05, y + h * 0.882);
  // state lamp
  const pulse = 0.45 + 0.55 * Math.abs(Math.sin(t * 2.4));
  ctx.fillStyle = meta.color;
  ctx.globalAlpha = pulse;
  ctx.beginPath();
  ctx.arc(x + w * 0.93, y + h * 0.09, Math.max(4, w * 0.011), 0, Math.PI * 2);
  ctx.fill();
  ctx.globalAlpha = 1;
  ctx.fillStyle = "#cfe0ef";
  ctx.font = mono(Math.max(8, h * 0.036));
  ctx.textAlign = "right";
  ctx.fillText(meta.state, x + w * 0.9, y + h * 0.093);
  ctx.textAlign = "left";
}

function drawWorship(ctx: Ctx, x: number, y: number, w: number, h: number, s: Src, t: number) {
  const full = s.worshipMode === "full";
  const font = s.worshipFont ?? `Tahoma, "Segoe UI", Verdana, sans-serif`;
  const titleLine = s.url ?? "";

  if (full) {
    /* full-screen centred lyric, Roma/Times face, like the scripture card */
    const bgMode = s.bibleBg ?? "default";
    const savedBg = s.bibleBg;
    s.bibleBg = bgMode; // reuse the scripture backdrop engine
    drawBibleBg(ctx, x, y, w, h, s);
    s.bibleBg = savedBg;

    const text = s.text ?? "";
    const cx = x + w / 2;
    const maxW = w * 0.82;
    const wrap = (fs: number) => {
      ctx.font = `400 ${fs}px ${font}`;
      const out: string[] = [];
      let cur = "";
      for (const wd of text.split(/\s+/)) {
        const trial = cur ? cur + " " + wd : wd;
        if (ctx.measureText(trial).width > maxW && cur) { out.push(cur); cur = wd; }
        else cur = trial;
      }
      if (cur) out.push(cur);
      return out;
    };
    let fs = Math.min(h * 0.115, w * 0.05);
    let lines = wrap(fs);
    while (lines.length > 5 && fs > h * 0.045) { fs *= 0.92; lines = wrap(fs); }
    const lh = fs * 1.5;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.save();
    ctx.shadowColor = "rgba(0,0,0,0.6)";
    ctx.shadowBlur = fs * 0.3;
    ctx.fillStyle = "#f6f7fa";
    ctx.font = `400 ${fs}px ${font}`;
    lines.forEach((ln, i) => ctx.fillText(ln, cx, y + h * 0.5 - ((lines.length - 1) * lh) / 2 + i * lh));
    ctx.restore();
    if (titleLine) {
      ctx.fillStyle = "rgba(212,164,55,0.95)";
      ctx.font = `700 ${fs * 0.42}px ${font}`;
      ctx.fillText(titleLine.toUpperCase().split("").join(" "), cx, y + h * 0.5 + ((lines.length - 1) * lh) / 2 + lh * 0.9);
    }
    ctx.textAlign = "left";
    return;
  }

  /* lower-third strip (default) */
  const bg = s.color ?? "#123a7a";
  ctx.save();
  ctx.shadowColor = "rgba(0,0,0,0.5)";
  ctx.shadowBlur = h * 0.14;
  ctx.fillStyle = bg;
  rr(ctx, x, y, w, h, h * 0.12);
  ctx.fill();
  ctx.restore();
  ctx.fillStyle = "#ffb020";
  ctx.fillRect(x, y + h * 0.42, w * 0.012, h * 0.34);
  ctx.fillStyle = "rgba(255,255,255,0.9)";
  ctx.font = `${h * 0.4}px sans-serif`;
  ctx.textAlign = "left";
  ctx.textBaseline = "middle";
  ctx.fillText("♫", x + w * 0.028, y + h * 0.5);
  const shimmer = 0.5 + 0.5 * Math.sin(t * 1.8);
  ctx.fillStyle = `rgba(255,255,255,${0.85 + shimmer * 0.15})`;
  ctx.font = disp(h * 0.3);
  ctx.fillText(s.text ?? "WORSHIP", x + w * 0.075, y + h * 0.38);
  ctx.fillStyle = "rgba(255,255,255,0.75)";
  ctx.font = disp(h * 0.2, 500);
  ctx.fillText(titleLine || "with the artist", x + w * 0.075, y + h * 0.72);
}

/* Full-canvas, centred scripture card. Tahoma throughout. */
const TAHOMA = `Tahoma, "Segoe UI", Verdana, sans-serif`;

function drawBibleBg(ctx: Ctx, x: number, y: number, w: number, h: number, s: Src) {
  const mode = s.bibleBg ?? "default";
  if (mode === "transparent") return;

  if (mode === "solid") {
    ctx.fillStyle = s.bibleBgColor ?? "#10131c";
    ctx.fillRect(x, y, w, h);
    return;
  }

  if (mode === "image") {
    const a = assets.get(s.bibleBgAsset);
    if (a?.kind === "image" && a.ready) {
      coverDraw(ctx, a.img, a.img.naturalWidth, a.img.naturalHeight, x, y, w, h);
      /* gentle scrim so the text stays readable over any photo */
      ctx.fillStyle = "rgba(6,8,13,0.42)";
      ctx.fillRect(x, y, w, h);
      return;
    }
    /* fall through to default while the photo loads */
  }

  /* default art — four built-in variants keyed by bibleBgVariant */
  const variant = s.bibleBgVariant ?? 0;
  const g = ctx.createLinearGradient(0, y, 0, y + h);
  if (variant === 1) { g.addColorStop(0, "#04060c"); g.addColorStop(1, "#0b101c"); }
  else if (variant === 2) { g.addColorStop(0, "#2a1430"); g.addColorStop(0.6, "#4a2330"); g.addColorStop(1, "#7a3b28"); }
  else if (variant === 3) { g.addColorStop(0, "#16212b"); g.addColorStop(1, "#0d141b"); }
  else { g.addColorStop(0, "#0c1018"); g.addColorStop(0.55, "#10141f"); g.addColorStop(1, "#080b11"); }
  ctx.fillStyle = g;
  ctx.fillRect(x, y, w, h);

  if (variant === 1) {
    /* midnight — scattered stars */
    for (let i = 0; i < 60; i++) {
      const sx = x + rnd(s.seed + 3, i) * w;
      const sy = y + rnd(s.seed + 9, i) * h;
      ctx.fillStyle = `rgba(255,255,255,${0.12 + 0.3 * rnd(s.seed + 1, i)})`;
      ctx.fillRect(sx, sy, 2, 2);
    }
  } else if (variant === 2) {
    /* dawn — rising warm glow */
    const glow = ctx.createRadialGradient(x + w / 2, y + h, 0, x + w / 2, y + h, h * 0.9);
    glow.addColorStop(0, "rgba(255,180,90,0.28)");
    glow.addColorStop(1, "rgba(255,180,90,0)");
    ctx.fillStyle = glow;
    ctx.fillRect(x, y, w, h);
  } else if (variant === 3) {
    /* slate — soft diagonal light bands */
    ctx.save();
    ctx.globalAlpha = 0.05;
    ctx.fillStyle = "#ffffff";
    for (let i = -2; i < 8; i++) {
      ctx.save();
      ctx.translate(x + (w / 6) * i, y);
      ctx.rotate(-0.5);
      ctx.fillRect(0, -h, w * 0.05, h * 3);
      ctx.restore();
    }
    ctx.restore();
  } else {
    const halo = ctx.createRadialGradient(x + w / 2, y + h * 0.42, 0, x + w / 2, y + h * 0.42, Math.max(w, h) * 0.62);
    halo.addColorStop(0, "rgba(212,164,55,0.10)");
    halo.addColorStop(1, "rgba(212,164,55,0)");
    ctx.fillStyle = halo;
    ctx.fillRect(x, y, w, h);
  }
}

function drawBible(ctx: Ctx, x: number, y: number, w: number, h: number, s: Src, t: number) {
  const anyS = s as unknown as Record<string, unknown>;
  const text = s.text ?? "…";
  const ref = s.url ?? "";
  const accent = s.color ?? "#d4a437";

  /* entrance ease */
  const born = (anyS.bornAt as number) ?? 0;
  const p = born ? clamp((t - born) / 0.45, 0, 1) : 1;
  const ease = 1 - Math.pow(1 - p, 3);
  ctx.save();
  ctx.globalAlpha = ease;
  ctx.translate(0, (1 - ease) * h * 0.06);

  drawBibleBg(ctx, x, y, w, h, s);

  /* ---- centred, auto-fit Tahoma verse ---- */
  const cx = x + w / 2;
  const maxW = w * 0.84;
  const wrap = (fs: number) => {
    ctx.font = `400 ${fs}px ${TAHOMA}`;
    const out: string[] = [];
    let cur = "";
    for (const wd of text.split(/\s+/)) {
      const trial = cur ? cur + " " + wd : wd;
      if (ctx.measureText(trial).width > maxW && cur) { out.push(cur); cur = wd; }
      else cur = trial;
    }
    if (cur) out.push(cur);
    return out;
  };
  let fs = Math.min(h * 0.115, w * 0.05);
  let lines = wrap(fs);
  while (lines.length > 5 && fs > h * 0.045) { fs *= 0.92; lines = wrap(fs); }
  const lh = fs * 1.55;

  ctx.textAlign = "center";
  ctx.textBaseline = "middle";

  /* thin gold rule above */
  ctx.strokeStyle = accent;
  ctx.lineWidth = Math.max(2, h * 0.004);
  ctx.beginPath();
  ctx.moveTo(cx - w * 0.09, y + h * 0.5 - ((lines.length - 1) * lh) / 2 - lh * 0.85);
  ctx.lineTo(cx + w * 0.09, y + h * 0.5 - ((lines.length - 1) * lh) / 2 - lh * 0.85);
  ctx.stroke();

  ctx.save();
  ctx.shadowColor = "rgba(0,0,0,0.6)";
  ctx.shadowBlur = fs * 0.3;
  ctx.fillStyle = "#f6f7fa";
  ctx.font = `400 ${fs}px ${TAHOMA}`;
  lines.forEach((ln, i) => {
    ctx.fillText(ln, cx, y + h * 0.5 - ((lines.length - 1) * lh) / 2 + i * lh);
  });
  ctx.restore();

  /* reference + KJV, centred beneath */
  if (ref) {
    const ry = y + h * 0.5 + ((lines.length - 1) * lh) / 2 + lh * 0.95;
    ctx.fillStyle = accent;
    ctx.font = `700 ${fs * 0.52}px ${TAHOMA}`;
    const spaced = ref.toUpperCase().split("").join(" ");
    ctx.fillText(spaced, cx, ry);
    ctx.fillStyle = "rgba(212,164,55,0.85)";
    ctx.font = `400 ${fs * 0.34}px ${TAHOMA}`;
    ctx.fillText("K I N G   J A M E S   V E R S I O N", cx, ry + fs * 0.62);
    /* thin gold rule below */
    ctx.strokeStyle = accent;
    ctx.beginPath();
    ctx.moveTo(cx - w * 0.06, ry + fs * 1.05);
    ctx.lineTo(cx + w * 0.06, ry + fs * 1.05);
    ctx.stroke();
  }
  ctx.restore();
}

function drawColor(ctx: Ctx, x: number, y: number, w: number, h: number, s: Src, t: number) {
  ctx.fillStyle = s.color ?? "#0d0f13";
  ctx.fillRect(x, y, w, h);
  const sheen = ctx.createLinearGradient(x, y, x + w, y + h);
  const ph = (Math.sin(t * 0.5 + s.seed) + 1) / 2;
  sheen.addColorStop(clamp(ph - 0.25, 0, 1), "rgba(255,255,255,0)");
  sheen.addColorStop(clamp(ph, 0.02, 0.98), "rgba(255,255,255,0.05)");
  sheen.addColorStop(clamp(ph + 0.25, 0, 1), "rgba(255,255,255,0)");
  ctx.fillStyle = sheen;
  ctx.fillRect(x, y, w, h);
}

/* ------------------------------- scene compositing ------------------------------- */

/** letterboxed 16:9 content rect inside an arbitrary canvas */
/* Paint a single source's content (crop + angle + type dispatch) at its own rect. */
export function paintSource(ctx: Ctx, s: Src, time: number, participants: Participant[], connected: boolean) {
  const x = s.x, y = s.y, w = s.w, h = s.h;
  const cl = (s.cropL ?? 0) / 100, cr = (s.cropR ?? 0) / 100;
  const ct = (s.cropT ?? 0) / 100, cb = (s.cropB ?? 0) / 100;
  const ix = x + w * cl, iy = y + h * ct;
  const iw = Math.max(8, w * (1 - cl - cr)), ih = Math.max(8, h * (1 - ct - cb));
  const ax = (clamp(s.angleX ?? 0, -85, 85) * Math.PI) / 180;
  const ay = (clamp(s.angleY ?? 0, -85, 85) * Math.PI) / 180;
  ctx.save();
  rr(ctx, x, y, w, h, Math.min(8, w * 0.01));
  ctx.clip();
  ctx.translate(x + w / 2, y + h / 2);
  ctx.scale(Math.cos(ay), Math.cos(ax));
  ctx.translate(-(x + w / 2), -(y + h / 2));
  switch (s.type) {
    case "camera": drawCamera(ctx, ix, iy, iw, ih, s, time); break;
    case "live-cam": drawLiveCam(ctx, ix, iy, iw, ih, s, time); break;
    case "display": drawDisplay(ctx, ix, iy, iw, ih, s, time); break;
    case "browser": drawBrowser(ctx, ix, iy, iw, ih, s, time); break;
    case "image": drawImage(ctx, ix, iy, iw, ih, s, time); break;
    case "media": drawMedia(ctx, ix, iy, iw, ih, s, time); break;
    case "text": drawText(ctx, ix, iy, iw, ih, s, time); break;
    case "color": drawColor(ctx, ix, iy, iw, ih, s, time); break;
    case "zoom-guest": drawZoomGuest(ctx, ix, iy, iw, ih, participantOf(s, participants), connected, time); break;
    case "zoom-grid": drawZoomGrid(ctx, ix, iy, iw, ih, participants, connected, time); break;
    case "image-file":
    case "video-file": drawFileMedia(ctx, ix, iy, iw, ih, s, time); break;
    case "ndi": drawNdi(ctx, ix, iy, iw, ih, s, time); break;
    case "gt": drawGt(ctx, ix, iy, iw, ih, s, time); break;
    case "stinger": drawStinger(ctx, ix, iy, iw, ih, s, time); break;
    case "srt-listener":
    case "srt-caller":
    case "webrtc":
    case "rtmp": drawNetwork(ctx, ix, iy, iw, ih, s, time); break;
    case "worship": drawWorship(ctx, ix, iy, iw, ih, s, time); break;
    case "bible": drawBible(ctx, ix, iy, iw, ih, s, time); break;
  }
  ctx.restore();
}

export function viewRect(W: number, H: number) {
  const k = Math.min(W / CW, H / CH);
  return { k, ox: (W - CW * k) / 2, oy: (H - CH * k) / 2, cw: CW * k, chh: CH * k };
}

export function drawScene(
  ctx: Ctx,
  scene: SceneDef,
  W: number,
  H: number,
  time: number,
  participants: Participant[],
  connected: boolean,
  opts: { scale?: number; alpha?: number } = {},
) {
  const { scale = 1, alpha = 1 } = opts;
  const vr = viewRect(W, H);
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.fillStyle = "#05060a";
  ctx.fillRect(0, 0, W, H);
  const cx = vr.ox + vr.cw / 2, cy = vr.oy + vr.chh / 2;
  if (scale !== 1) {
    ctx.translate(cx, cy);
    ctx.scale(scale, scale);
    ctx.translate(-cx, -cy);
  }
  ctx.translate(vr.ox, vr.oy);
  ctx.scale(vr.k, vr.k);
  ctx.fillStyle = "#0b0d11";
  ctx.fillRect(0, 0, CW, CH);
  for (const s of scene.sources) {
    if (!s.visible) continue;
    paintSource(ctx, s, time, participants, connected);
    ctx.strokeStyle = "rgba(255,255,255,0.07)";
    ctx.lineWidth = 1 / vr.k;
    ctx.strokeRect(s.x + 0.5, s.y + 0.5, s.w - 1, s.h - 1);
  }

  /* blank bus — stays dark until an input is added */
  if (!scene.sources.some((s) => s.visible)) {
    ctx.strokeStyle = "rgba(233,237,243,0.10)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(CW / 2, CH / 2, CH * 0.07, 0, Math.PI * 2);
    ctx.moveTo(CW / 2 - CH * 0.14, CH / 2);
    ctx.lineTo(CW / 2 + CH * 0.14, CH / 2);
    ctx.moveTo(CW / 2, CH / 2 - CH * 0.14);
    ctx.lineTo(CW / 2, CH / 2 + CH * 0.14);
    ctx.stroke();
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillStyle = "rgba(233,237,243,0.16)";
    ctx.font = disp(CH * 0.045, 600);
    ctx.fillText("AWAITING INPUT", CW / 2, CH * 0.645);
    ctx.fillStyle = "rgba(139,149,166,0.4)";
    ctx.font = mono(CH * 0.02);
    ctx.fillText("open ADD INPUT to compose this scene", CW / 2, CH * 0.7);
    ctx.textAlign = "left";
  }
  ctx.restore();
}

export function drawSafeAreas(ctx: Ctx, W: number, H: number) {
  const vr = viewRect(W, H);
  const { ox, oy, cw, chh } = vr;
  ctx.save();
  ctx.strokeStyle = "rgba(255,176,32,0.4)";
  ctx.lineWidth = 1;
  ctx.setLineDash([6, 5]);
  ctx.strokeRect(ox + cw * 0.05, oy + chh * 0.05, cw * 0.9, chh * 0.9);
  ctx.strokeStyle = "rgba(233,237,243,0.16)";
  ctx.beginPath();
  for (let i = 1; i < 3; i++) {
    ctx.moveTo(ox + (cw / 3) * i, oy); ctx.lineTo(ox + (cw / 3) * i, oy + chh);
    ctx.moveTo(ox, oy + (chh / 3) * i); ctx.lineTo(ox + cw, oy + (chh / 3) * i);
  }
  ctx.stroke();
  ctx.restore();
}

export function drawSelection(ctx: Ctx, s: Src, W: number, H: number) {
  const vr = viewRect(W, H);
  const x = vr.ox + s.x * vr.k, y = vr.oy + s.y * vr.k, w = s.w * vr.k, h = s.h * vr.k;
  ctx.save();
  ctx.strokeStyle = "#2fd273";
  ctx.lineWidth = 2;
  ctx.setLineDash([]);
  ctx.strokeRect(x, y, w, h);
  ctx.fillStyle = "#2fd273";
  const hs = 9;
  const pts = [
    [x, y], [x + w / 2, y], [x + w, y],
    [x + w, y + h / 2], [x + w, y + h], [x + w / 2, y + h],
    [x, y + h], [x, y + h / 2],
  ];
  for (const [px, py] of pts) ctx.fillRect(px - hs / 2, py - hs / 2, hs, hs);
  ctx.fillStyle = "rgba(47,210,115,0.92)";
  ctx.font = mono(11);
  ctx.textAlign = "left";
  ctx.textBaseline = "alphabetic";
  const label = `${s.name}  •  ${Math.round((s.w / s.bw) * 100)}%`;
  const tw = ctx.measureText(label).width;
  const ly = Math.max(y - 20, 2);
  ctx.fillRect(x, ly, tw + 14, 18);
  ctx.fillStyle = "#06130b";
  ctx.fillText(label, x + 7, ly + 13);
  ctx.restore();
}

/* ------------------------------ program compositor ------------------------------ */

export function composeProgram(ctx: Ctx, m: StudioModel, W: number, H: number, time: number) {
  ctx.fillStyle = "#000";
  ctx.fillRect(0, 0, W, H);
  const from = m.scenes.find((s) => s.id === m.trans.from);
  const to = m.scenes.find((s) => s.id === m.trans.to);
  const pgm = m.scenes.find((s) => s.id === m.programId);
  const conn = m.zoom.phase === "connected";
  if (!pgm && !from && !to) return; // no scenes yet — leave black

  if (m.trans.active && from && to && m.trans.kind !== "cut") {
    const t = clamp(m.trans.t, 0, 1);
    switch (m.trans.kind) {
      case "fade":
        drawScene(ctx, from, W, H, time, m.zoom.participants, conn);
        drawScene(ctx, to, W, H, time, m.zoom.participants, conn, { alpha: t });
        break;
      case "wipe": {
        const vr = viewRect(W, H);
        drawScene(ctx, from, W, H, time, m.zoom.participants, conn);
        ctx.save();
        ctx.beginPath();
        ctx.rect(vr.ox, vr.oy, vr.cw * t, vr.chh);
        ctx.clip();
        drawScene(ctx, to, W, H, time, m.zoom.participants, conn);
        ctx.restore();
        ctx.fillStyle = "#e9edf3";
        ctx.fillRect(vr.ox + vr.cw * t - 1.5, vr.oy, 3, vr.chh);
        break;
      }
      case "zoom":
        drawScene(ctx, from, W, H, time, m.zoom.participants, conn, { scale: 1 + 0.35 * t, alpha: 1 - t });
        drawScene(ctx, to, W, H, time, m.zoom.participants, conn, { scale: 0.82 + 0.18 * t, alpha: t });
        break;
      case "dip":
        ctx.fillStyle = "#000";
        ctx.fillRect(0, 0, W, H);
        if (t < 0.5) drawScene(ctx, from, W, H, time, m.zoom.participants, conn, { alpha: 1 - t * 2 });
        else drawScene(ctx, to, W, H, time, m.zoom.participants, conn, { alpha: (t - 0.5) * 2 });
        break;
    }
  } else if (pgm) {
    drawScene(ctx, pgm, W, H, time, m.zoom.participants, conn);
  }

  /* vMix-style overlays: sources composited ON TOP of Program without replacing it */
  if (m.overlays?.length) {
    const vr = viewRect(W, H);
    ctx.save();
    ctx.translate(vr.ox, vr.oy);
    ctx.scale(vr.k, vr.k);
    for (const oid of m.overlays) {
      if (!oid) continue;
      const os = m.scenes.flatMap((sc) => sc.sources).find((s) => s.id === oid);
      if (os && os.visible) paintSource(ctx, os, time, m.zoom.participants, conn);
    }
    ctx.restore();
  }

  if (m.ftb.alpha > 0.002) {
    ctx.fillStyle = `rgba(0,0,0,${m.ftb.alpha})`;
    ctx.fillRect(0, 0, W, H);
    if (m.ftb.alpha > 0.5) {
      ctx.fillStyle = `rgba(255,68,56,${(m.ftb.alpha - 0.5) * 1.4})`;
      ctx.font = disp(H * 0.06, 600);
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText("F A D E D   T O   B L A C K", W / 2, H / 2);
      ctx.textAlign = "left";
    }
  }
  if (m.safeAreas) drawSafeAreas(ctx, W, H);
}
