export interface MeetingPeer {
  n: string;
  h: number;
}

export interface MeetingOptions {
  meetingId: string;
  user: string;
  deviceId: string;
  useVideo: boolean;
  useAudio: boolean;
  peers: MeetingPeer[];
  onClosed: () => void;
}

const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");

/**
 * Opens the live meeting room in its own browser window.
 * The room captures the operator's real camera / microphone / screen-share,
 * and renders remote participants exactly like a Zoom gallery view.
 */
export function openMeetingWindow(o: MeetingOptions): Window | null {
  const win = window.open(
    "",
    "sf_meeting",
    "width=1180,height=760,menubar=no,toolbar=no,location=no,status=no",
  );
  if (!win) return null;

  const payload = {
    user: esc(o.user || "Host"),
    meeting: esc(o.meetingId),
    video: !!o.useVideo,
    audio: !!o.useAudio,
    device: esc(o.deviceId || ""),
    peers: o.peers.map((p) => ({ n: esc(p.n), h: Math.round(p.h) })),
  };

  const html = `<!doctype html>
<html><head><meta charset="utf-8"><title>Meeting — ${payload.meeting}</title>
<style>
  *{box-sizing:border-box;margin:0}
  html,body{height:100%;font-family:"Segoe UI",system-ui,sans-serif;background:#141517;color:#e8e8e8;overflow:hidden}
  #top{height:46px;display:flex;align-items:center;gap:14px;padding:0 16px;background:#1d1e21;border-bottom:1px solid #2c2d31}
  #top .t{font-size:13px;font-weight:600}
  #top .sub{font-size:11px;color:#9aa0a6}
  #top .grow{flex:1}
  .pill{display:flex;align-items:center;gap:6px;font-size:11px;color:#c8ccd0;background:#2a2b2f;border-radius:14px;padding:5px 11px}
  .dot{width:7px;height:7px;border-radius:50%;background:#31c48d}
  #rec .dot{background:#e5484d;animation:bl 1.1s steps(1) infinite}
  @keyframes bl{50%{opacity:.15}}
  #stage{position:absolute;top:46px;bottom:78px;left:0;right:0;overflow:auto}
  #grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:10px;padding:14px;align-content:start}
  body.roster #grid{right:260px}
  #roster{position:absolute;top:46px;bottom:78px;right:0;width:260px;background:#1a1b1e;border-left:1px solid #2c2d31;padding:12px;overflow:auto;display:none}
  body.roster #roster{display:block}
  #roster h3{font-size:11px;letter-spacing:.12em;color:#8a9096;margin-bottom:10px}
  .rrow{display:flex;align-items:center;gap:9px;padding:7px 4px;font-size:12px}
  .rrow .av{width:26px;height:26px;border-radius:50%;display:grid;place-items:center;font-size:10px;font-weight:700;color:#0d0f12}
  .rrow .mic{margin-left:auto;font-size:11px}
  .tile{position:relative;aspect-ratio:16/9;background:#202124;border-radius:10px;overflow:hidden}
  .tile video,.tile canvas{width:100%;height:100%;object-fit:cover;display:block}
  .tile .name{position:absolute;left:8px;bottom:8px;background:rgba(0,0,0,.6);border-radius:5px;padding:3px 8px;font-size:11px;display:flex;gap:6px;align-items:center}
  .tile .camoff{position:absolute;inset:0;display:grid;place-items:center}
  .tile .camoff .big{width:74px;height:74px;border-radius:50%;display:grid;place-items:center;font-size:26px;font-weight:700;color:#0d0f12}
  .tile.talk{box-shadow:inset 0 0 0 3px #31c48d}
  .tile.me{outline:2px solid #3b6fd4}
  #shareV{position:absolute;inset:0;width:100%;height:100%;object-fit:contain;background:#000;display:none}
  #bar{position:absolute;left:0;right:0;bottom:0;height:78px;display:flex;align-items:center;justify-content:center;gap:10px;background:#1d1e21;border-top:1px solid #2c2d31}
  .ctl{width:46px;height:46px;border-radius:50%;border:0;background:#2a2b2f;color:#e8e8e8;font-size:17px;cursor:pointer;display:grid;place-items:center;transition:background .15s}
  .ctl:hover{background:#3a3b40}
  .ctl.off{background:#e5484d}
  .ctl.wide{width:auto;border-radius:23px;padding:0 18px;font-size:12px;font-weight:600}
  .ctl.leave{background:#e5484d;font-weight:700}
  .ctl.leave:hover{background:#f2555a}
  .hidden{display:none!important}
  #wait{grid-column:1/-1;display:grid;place-items:center;min-height:280px}
  .wcard{text-align:center;padding:34px 44px;background:#202124;border:1px solid #2c2d31;border-radius:12px}
  .wpulse{width:54px;height:54px;margin:0 auto 16px;border-radius:50%;background:radial-gradient(circle at 35% 30%,#3d8bfd,#1d4ed8);animation:wp 1.8s ease-in-out infinite}
  @keyframes wp{0%,100%{transform:scale(1);opacity:.9}50%{transform:scale(1.08);opacity:1}}
  .wtitle{font-size:17px;font-weight:600;color:#e8e8e8}
  .wsub{margin-top:6px;font-size:12px;color:#9aa0a6}
  .wid{margin-top:14px;font-size:11px;color:#6b7075;font-family:monospace}
</style></head>
<body>
<div id="top">
  <span class="t">StreamForge Meeting</span>
  <span class="sub" id="mid"></span>
  <span class="grow"></span>
  <span class="pill" id="clock">00:00:00</span>
  <span class="pill" id="rec"><i class="dot"></i>REC</span>
  <span class="pill"><i class="dot"></i><span id="count">1</span>&nbsp;in meeting</span>
</div>
<div id="stage"><div id="grid"></div></div>
<div id="roster"><h3>PARTICIPANTS (<span id="rcount">1</span>)</h3><div id="rlist"></div></div>
<div id="bar">
  <button class="ctl" id="bMic" title="Mute / unmute">&#127908;</button>
  <button class="ctl" id="bCam" title="Start / stop video">&#127909;</button>
  <button class="ctl wide" id="bShare" title="Share your screen">Share Screen</button>
  <button class="ctl wide" id="bRoster" title="Participants">&#128101; People</button>
  <button class="ctl leave wide" id="bLeave">Leave</button>
</div>
<video id="shareV" autoplay muted playsinline></video>
<script>
(function(){
  var P=${JSON.stringify(payload)};
  var grid=document.getElementById("grid"),
      count=document.getElementById("count"),
      rcount=document.getElementById("rcount"),
      rlist=document.getElementById("rlist"),
      clock=document.getElementById("clock"),
      mid=document.getElementById("mid"),
      shareV=document.getElementById("shareV");
  mid.textContent="ID "+P.meeting+"  •  "+P.user+" (Host)";
  var joined=[], micOn=P.audio, camOn=P.video, localStream=null, shareStream=null;
  var t0=Date.now();
  setInterval(function(){
    var s=Math.floor((Date.now()-t0)/1000),
        h=("0"+Math.floor(s/3600)).slice(-2),
        m=("0"+Math.floor(s%3600/60)).slice(-2),
        ss=("0"+s%60).slice(-2);
    clock.textContent=h+":"+m+":"+ss;
  },1000);

  function initials(n){var p=n.split(" ");return (p[0][0]+(p[1]?p[1][0]:"")).toUpperCase();}

  function avatarHTML(name,hue){
    return '<div class="camoff"><div class="big" style="background:hsl('+hue+' 65% 62%)">'+initials(name)+'</div></div>';
  }

  function drawPeer(cv,hue,seed){
    var cx=cv.getContext("2d"),t=seed;
    (function loop(){
      t+=0.016;
      var w=cv.width,h=cv.height;
      var g=cx.createLinearGradient(0,0,0,h);
      g.addColorStop(0,"hsl("+hue+" 30% 16%)");g.addColorStop(1,"hsl("+hue+" 36% 7%)");
      cx.fillStyle=g;cx.fillRect(0,0,w,h);
      var bob=Math.sin(t*1.1+seed)*h*0.006;
      var hx=w*0.5,hy=h*0.44+bob,hr=h*0.115;
      cx.fillStyle="hsl("+hue+" 22% 10%)";
      cx.beginPath();cx.ellipse(w*0.5,h*0.92,w*0.21,h*0.27,0,Math.PI,0);cx.fill();
      cx.beginPath();cx.arc(hx,hy,hr,0,Math.PI*2);cx.fill();
      cx.strokeStyle="hsla("+hue+" 80% 66% / .5)";cx.lineWidth=Math.max(1.5,w*0.004);
      cx.beginPath();cx.arc(hx,hy,hr,Math.PI*0.75,Math.PI*1.45);cx.stroke();
      requestAnimationFrame(loop);
    })();
  }

  function updateCount(){
    var n=1+joined.length;
    count.textContent=n; rcount.textContent=n;
  }

  function rosterRow(name,hue,host){
    var d=document.createElement("div");d.className="rrow";
    d.innerHTML='<span class="av" style="background:hsl('+hue+' 65% 62%)">'+initials(name)+'</span><span>'+name+(host?" (Host)":"")+'</span><span class="mic">'+(host?(micOn?"&#127908;":"&#128263;"):"&#127908;")+"</span>";
    rlist.appendChild(d);
  }

  /* ---- local tile ---- */
  var me=document.createElement("div");
  me.className="tile me";me.id="meTile";
  me.innerHTML='<video id="meV" autoplay muted playsinline></video>'+avatarHTML(P.user+" (You)",210)+'<div class="name">'+P.user+" (You, Host)"+'</div>';
  grid.appendChild(me);
  var meV=document.getElementById("meV");
  if(!camOn){meV.style.display="none";}
  rosterRow(P.user,210,true);

  function startCam(){
    var cons={video:camOn?(P.device?{deviceId:P.device}:true):false,audio:micOn};
    if(!cons.video&&!cons.audio)return;
    navigator.mediaDevices.getUserMedia(cons).then(function(st){
      localStream=st;
      meV.srcObject=st;
      meV.style.display=camOn?"block":"none";
    }).catch(function(){
      camOn=false;micOn=false;meV.style.display="none";
    });
  }
  startCam();

  /* ---- honest meeting: only the operator's real camera.
     When nobody else is connected we show exactly what the Zoom desktop
     client shows when you are alone in a meeting — a waiting banner. ---- */
  var wait=document.createElement("div");
  wait.id="wait";
  wait.innerHTML='<div class="wcard"><div class="wpulse"></div><div class="wtitle">You are the only one here</div><div class="wsub">Waiting for others to join…</div><div class="wid">Meeting ID: '+P.meeting+'</div></div>';
  grid.appendChild(wait);

  /* ---- controls ---- */
  var bMic=document.getElementById("bMic"),bCam=document.getElementById("bCam"),
      bShare=document.getElementById("bShare"),bRoster=document.getElementById("bRoster"),
      bLeave=document.getElementById("bLeave");
  if(!micOn)bMic.classList.add("off");
  if(!camOn)bCam.classList.add("off");
  bMic.onclick=function(){
    micOn=!micOn;
    if(localStream)localStream.getAudioTracks().forEach(function(t){t.enabled=micOn;});
    bMic.classList.toggle("off",!micOn);
  };
  bCam.onclick=function(){
    camOn=!camOn;
    if(camOn&&!localStream){startCam();}
    if(localStream)localStream.getVideoTracks().forEach(function(t){t.enabled=camOn;});
    meV.style.display=camOn?"block":"none";
    bCam.classList.toggle("off",!camOn);
  };
  bShare.onclick=function(){
    if(shareStream){
      shareStream.getTracks().forEach(function(t){t.stop();});
      shareStream=null;shareV.style.display="none";shareV.srcObject=null;
      bShare.textContent="Share Screen";return;
    }
    navigator.mediaDevices.getDisplayMedia({video:true}).then(function(st){
      shareStream=st;shareV.srcObject=st;shareV.style.display="block";
      bShare.textContent="Stop Sharing";
      st.getVideoTracks()[0].onended=function(){
        shareStream=null;shareV.style.display="none";shareV.srcObject=null;
        bShare.textContent="Share Screen";
      };
    }).catch(function(){});
  };
  bRoster.onclick=function(){document.body.classList.toggle("roster");};
  bLeave.onclick=function(){window.close();};
})();
<\/script>
</body></html>`;

  win.document.open();
  win.document.write(html);
  win.document.close();

  const poll = setInterval(() => {
    if (win.closed) {
      clearInterval(poll);
      o.onClosed();
    }
  }, 800);

  return win;
}
