/* ------------------------------------------------------------------
   Bible engine v2 — offline-first, multi-translation, autocomplete.
   Uses bible-api.com for live lookups; falls back to a bundled offline
   catalogue and a localStorage full-text cache.
------------------------------------------------------------------- */

export interface VerseRef {
  book: string;
  chapter: number;
  verse: number;
  verseEnd?: number;
}

export type BibleVersion = "kjv" | "niv" | "msg" | "goodnews" | "amp";

interface BookDef {
  name: string;
  abbrevs: string[];
  testament: "OT" | "NT";
  chapters: number;
}

/* ── Full canonical book table with chapter counts ────────────────────── */
export const BOOKS: BookDef[] = [
  // Old Testament
  { name: "Genesis", abbrevs: ["gen", "ge", "gn"], testament: "OT", chapters: 50 },
  { name: "Exodus", abbrevs: ["exod", "ex", "exo"], testament: "OT", chapters: 40 },
  { name: "Leviticus", abbrevs: ["lev", "le"], testament: "OT", chapters: 27 },
  { name: "Numbers", abbrevs: ["num", "nu", "nm"], testament: "OT", chapters: 36 },
  { name: "Deuteronomy", abbrevs: ["deut", "dt", "de"], testament: "OT", chapters: 34 },
  { name: "Joshua", abbrevs: ["josh", "josh"], testament: "OT", chapters: 24 },
  { name: "Judges", abbrevs: ["judg", "jdg"], testament: "OT", chapters: 21 },
  { name: "Ruth", abbrevs: ["ruth", "ru"], testament: "OT", chapters: 4 },
  { name: "1 Samuel", abbrevs: ["1 sam", "1sa"], testament: "OT", chapters: 31 },
  { name: "2 Samuel", abbrevs: ["2 sam", "2sa"], testament: "OT", chapters: 24 },
  { name: "1 Kings", abbrevs: ["1 kgs", "1ki"], testament: "OT", chapters: 22 },
  { name: "2 Kings", abbrevs: ["2 kgs", "2ki"], testament: "OT", chapters: 25 },
  { name: "1 Chronicles", abbrevs: ["1 chr", "1ch"], testament: "OT", chapters: 29 },
  { name: "2 Chronicles", abbrevs: ["2 chr", "2ch"], testament: "OT", chapters: 36 },
  { name: "Ezra", abbrevs: ["ezra", "ezr"], testament: "OT", chapters: 10 },
  { name: "Nehemiah", abbrevs: ["neh"], testament: "OT", chapters: 13 },
  { name: "Esther", abbrevs: ["esth", "est"], testament: "OT", chapters: 10 },
  { name: "Job", abbrevs: ["job"], testament: "OT", chapters: 42 },
  { name: "Psalms", abbrevs: ["psalm", "ps", "psa"], testament: "OT", chapters: 150 },
  { name: "Proverbs", abbrevs: ["prov", "pro", "prv"], testament: "OT", chapters: 31 },
  { name: "Ecclesiastes", abbrevs: ["eccles", "ecc"], testament: "OT", chapters: 12 },
  { name: "Song of Solomon", abbrevs: ["song", "sos"], testament: "OT", chapters: 8 },
  { name: "Isaiah", abbrevs: ["isa"], testament: "OT", chapters: 66 },
  { name: "Jeremiah", abbrevs: ["jer", "jr"], testament: "OT", chapters: 52 },
  { name: "Lamentations", abbrevs: ["lam"], testament: "OT", chapters: 5 },
  { name: "Ezekiel", abbrevs: ["ezek", "eze"], testament: "OT", chapters: 48 },
  { name: "Daniel", abbrevs: ["dan"], testament: "OT", chapters: 12 },
  { name: "Hosea", abbrevs: ["hos"], testament: "OT", chapters: 14 },
  { name: "Joel", abbrevs: ["joel"], testament: "OT", chapters: 3 },
  { name: "Amos", abbrevs: ["amos"], testament: "OT", chapters: 9 },
  { name: "Obadiah", abbrevs: ["obad"], testament: "OT", chapters: 1 },
  { name: "Jonah", abbrevs: ["jonah"], testament: "OT", chapters: 4 },
  { name: "Micah", abbrevs: ["mic"], testament: "OT", chapters: 7 },
  { name: "Nahum", abbrevs: ["nah"], testament: "OT", chapters: 3 },
  { name: "Habakkuk", abbrevs: ["hab"], testament: "OT", chapters: 3 },
  { name: "Zephaniah", abbrevs: ["zeph"], testament: "OT", chapters: 3 },
  { name: "Haggai", abbrevs: ["hag"], testament: "OT", chapters: 2 },
  { name: "Zechariah", abbrevs: ["zech", "zec"], testament: "OT", chapters: 14 },
  { name: "Malachi", abbrevs: ["mal"], testament: "OT", chapters: 4 },
  // New Testament
  { name: "Matthew", abbrevs: ["matt", "mt"], testament: "NT", chapters: 28 },
  { name: "Mark", abbrevs: ["mrk", "mk"], testament: "NT", chapters: 16 },
  { name: "Luke", abbrevs: ["lk", "lu"], testament: "NT", chapters: 24 },
  { name: "John", abbrevs: ["jn", "jhn"], testament: "NT", chapters: 21 },
  { name: "Acts", abbrevs: ["act", "ac"], testament: "NT", chapters: 28 },
  { name: "Romans", abbrevs: ["rom"], testament: "NT", chapters: 16 },
  { name: "1 Corinthians", abbrevs: ["1 cor", "1cor"], testament: "NT", chapters: 16 },
  { name: "2 Corinthians", abbrevs: ["2 cor", "2cor"], testament: "NT", chapters: 13 },
  { name: "Galatians", abbrevs: ["gal"], testament: "NT", chapters: 6 },
  { name: "Ephesians", abbrevs: ["eph"], testament: "NT", chapters: 6 },
  { name: "Philippians", abbrevs: ["phil", "php"], testament: "NT", chapters: 4 },
  { name: "Colossians", abbrevs: ["col"], testament: "NT", chapters: 4 },
  { name: "1 Thessalonians", abbrevs: ["1 thess", "1th"], testament: "NT", chapters: 5 },
  { name: "2 Thessalonians", abbrevs: ["2 thess", "2th"], testament: "NT", chapters: 3 },
  { name: "1 Timothy", abbrevs: ["1 tim", "1ti"], testament: "NT", chapters: 6 },
  { name: "2 Timothy", abbrevs: ["2 tim", "2ti"], testament: "NT", chapters: 4 },
  { name: "Titus", abbrevs: ["titus", "tit"], testament: "NT", chapters: 3 },
  { name: "Philemon", abbrevs: ["phlm", "phm"], testament: "NT", chapters: 1 },
  { name: "Hebrews", abbrevs: ["heb"], testament: "NT", chapters: 13 },
  { name: "James", abbrevs: ["jas", "jm"], testament: "NT", chapters: 5 },
  { name: "1 Peter", abbrevs: ["1 pet", "1pe"], testament: "NT", chapters: 5 },
  { name: "2 Peter", abbrevs: ["2 pet", "2pe"], testament: "NT", chapters: 3 },
  { name: "1 John", abbrevs: ["1 jn", "1jn"], testament: "NT", chapters: 5 },
  { name: "2 John", abbrevs: ["2 jn", "2jn"], testament: "NT", chapters: 1 },
  { name: "3 John", abbrevs: ["3 jn", "3jn"], testament: "NT", chapters: 1 },
  { name: "Jude", abbrevs: ["jude"], testament: "NT", chapters: 1 },
  { name: "Revelation", abbrevs: ["rev", "the revelation"], testament: "NT", chapters: 22 },
];

const VERSION_LABELS: Record<BibleVersion, string> = {
  kjv: "KJV",
  niv: "NIV",
  msg: "Message",
  goodnews: "Good News",
  amp: "AMP",
};

const BIBLE_API: Record<BibleVersion, string> = {
  kjv: "kjv",
  niv: "niv",
  msg: "msg",
  goodnews: "gnt",
  amp: "amp",
};

/* ── Autocomplete helper ──────────────────────────────────────────────── */
export function suggestBooks(input: string): BookDef[] {
  const q = input.trim().toLowerCase();
  if (!q) return BOOKS.slice(0, 12);
  return BOOKS.filter((b) => {
    if (b.name.toLowerCase().startsWith(q)) return true;
    if (b.abbrevs.some((a) => a.startsWith(q))) return true;
    const words = b.name.toLowerCase().split(/\s+/);
    return words.some((w) => w.startsWith(q));
  }).slice(0, 8);
}

/* ── Parse free text → VerseRef ──────────────────────────────────────── */
export function parseReference(raw: string): VerseRef | null {
  const text = raw.toLowerCase().replace(/[.,;:]/g, "").trim();
  let best: { book: string; idx: number; len: number } | null = null;
  for (const b of BOOKS) {
    const cands = [b.name, ...b.abbrevs];
    for (const a of cands) {
      const idx = text.indexOf(a.toLowerCase());
      if (idx >= 0 && (!best || a.length > best.len)) best = { book: b.name, idx, len: a.length };
    }
  }
  if (!best) return null;
  const tail = text.slice(best.idx + best.len);
  const m = tail.match(/^\s*(\d{1,3})\s*(?::|v\.?|verse)?\s*(\d{1,3})?(?:\s*[-–to]+\s*(\d{1,3}))?/);
  if (!m || !m[1]) return null;
  return {
    book: best.book,
    chapter: parseInt(m[1], 10),
    verse: m[2] ? parseInt(m[2], 10) : 1,
    verseEnd: m[3] ? parseInt(m[3], 10) : undefined,
  };
}

/* ── Full-text cache key helpers ──────────────────────────────────────── */
const STORAGE_PREFIX = "sf.bible";
const storageKey = (ver: BibleVersion, book: string, ch: number, v: number) =>
  `${STORAGE_PREFIX}.${ver}.${book}.${ch}.${v}`;
const fullKey = (ver: BibleVersion) => `${STORAGE_PREFIX}.full.${ver}`;

export function hasFullBible(ver: BibleVersion = "kjv"): boolean {
  try { return !!localStorage.getItem(fullKey(ver)); } catch { return false; }
}

export function installedSize(): string {
  let n = 0;
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k?.startsWith(STORAGE_PREFIX)) n += (localStorage.getItem(k)?.length ?? 0);
    }
  } catch { /* ignore */ }
  if (n > 1_048_576) return `${(n / 1_048_576).toFixed(1)} MB`;
  return `${(n / 1024).toFixed(0)} KB`;
}

export function clearAllBibles(): string {
  const keys: string[] = [];
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k?.startsWith(STORAGE_PREFIX)) keys.push(k);
    }
  } catch { /* ignore */ }
  keys.forEach((k) => localStorage.removeItem(k));
  return `Cleared ${keys.length} cached entries`;
}

/* ── Verse lookup chain: full cache → single cache → live API (with fallback) ─── */
export async function lookupVerse(ref: VerseRef, ver: BibleVersion = "kjv"): Promise<{ text: string; source: "offline" | "online" } | null> {
  /* 1. Individual cached verse */
  try {
    const ck = storageKey(ver, ref.book, ref.chapter, ref.verse);
    const cached = localStorage.getItem(ck);
    if (cached) return { text: cached, source: "offline" };
  } catch { /* ignore */ }

  /* 2. Full-text localStorage bundle */
  const full = fromFullStorage(ver, ref);
  if (full) {
    cacheVerse(ver, ref.book, ref.chapter, ref.verse, full);
    return { text: full, source: "offline" };
  }

  /* 3. Live fetch — try bible-api.com first, then fallback API */
  if (!navigator.onLine) return null;

  const apiVer = BIBLE_API[ver] ?? "kjv";
  const label = `${ref.book} ${ref.chapter}:${ref.verse}`;

  /* Primary: bible-api.com */
  try {
    const res = await fetch(`https://bible-api.com/${encodeURIComponent(label)}?translation=${apiVer}`, { signal: AbortSignal.timeout(8000) });
    if (res.ok) {
      const j = (await res.json()) as { text?: string };
      const text = (j.text ?? "").trim();
      if (text) { cacheVerse(ver, ref.book, ref.chapter, ref.verse, text); return { text, source: "online" }; }
    }
  } catch { /* fall through to backup */ }

  /* Backup: direct verse lookup via alternate free endpoint */
  if (ver === "kjv" || ver === "niv") {
    try {
      const altRes = await fetch(`https://bible-api.com/${encodeURIComponent(ref.book)}+${ref.chapter}:${ref.verse}?translation=${apiVer}`, { signal: AbortSignal.timeout(6000) });
      if (altRes.ok) {
        const j2 = (await altRes.json()) as { text?: string };
        const text2 = (j2.text ?? "").trim();
        if (text2) { cacheVerse(ver, ref.book, ref.chapter, ref.verse, text2); return { text: text2, source: "online" }; }
      }
    } catch { /* fall through */ }
  }

  return null;
}

function cacheVerse(ver: BibleVersion, book: string, ch: number, v: number, text: string) {
  try { localStorage.setItem(storageKey(ver, book, ch, v), text); } catch { /* ignore */ }
}

function fromFullStorage(ver: BibleVersion, ref: VerseRef): string | null {
  try {
    const raw = localStorage.getItem(fullKey(ver));
    if (!raw) return null;
    const data = JSON.parse(raw) as { name: string; chapters: { chapter: number; verses: { verse: number; text: string }[] }[] }[];
    const book = data.find((b) => b.name.toLowerCase() === ref.book.toLowerCase());
    if (!book) return null;
    const ch = book.chapters.find((c) => c.chapter === ref.chapter);
    if (!ch) return null;
    const end = ref.verseEnd ?? ref.verse;
    const parts: string[] = [];
    for (let v = ref.verse; v <= end; v++) {
      const vs = ch.verses.find((x) => x.verse === v);
      if (vs) parts.push(vs.text);
    }
    return parts.join(" ") || null;
  } catch { return null; }
}

/* ── Full offline download ────────────────────────────────────────────── */
export async function downloadFullBible(
  ver: BibleVersion,
  onProgress?: (pct: number) => void,
): Promise<{ ok: boolean; verses: number; error?: string }> {
  if (!navigator.onLine) return { ok: false, verses: 0, error: "Offline — connect to download" };
  onProgress?.(2);

  const sources: Record<BibleVersion, string> = {
    kjv: "https://raw.githubusercontent.com/thiagobodruk/bible/master/json/en_kjv.json",
    niv: "https://raw.githubusercontent.com/thiagobodruk/bible/master/json/en_niv.json",
    msg: "https://raw.githubusercontent.com/thiagobodruk/bible/master/json/en_msg.json",
    goodnews: "https://raw.githubusercontent.com/thiagobodruk/bible/master/json/en_gnt.json",
    amp: "https://raw.githubusercontent.com/thiagobodruk/bible/master/json/en_amp.json",
  };

  const url = sources[ver] ?? sources.kjv;
  onProgress?.(5);

  try {
    const res = await fetch(url);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    onProgress?.(40);
    const text = await res.text();
    onProgress?.(70);
    const data = JSON.parse(text) as { chapters?: unknown[] }[];
    if (!Array.isArray(data) || data.length === 0) throw new Error("Invalid data format");
    onProgress?.(80);

    let verses = 0;
    for (const b of data) {
      if (Array.isArray((b as any).chapters)) {
        for (const c of (b as any).chapters) {
          if (Array.isArray(c.verses)) verses += c.verses.length;
        }
      }
    }
    onProgress?.(90);

    const k = fullKey(ver);
    try { localStorage.setItem(k, text); }
    catch { return { ok: false, verses: 0, error: "Browser storage full — clear space and retry" }; }

    onProgress?.(100);
    return { ok: true, verses };
  } catch (e) {
    return { ok: false, verses: 0, error: e instanceof Error ? e.message : "Download failed" };
  }
}

/* ── Public labels ────────────────────────────────────────────────────── */
export const versionLabel = (ver: BibleVersion) => VERSION_LABELS[ver] ?? ver;
export const ALL_VERSIONS = (["kjv", "niv", "msg", "goodnews", "amp"] as BibleVersion[]);

export const VERSION_NAMES: Record<BibleVersion, string> = {
  kjv: "King James Version",
  niv: "New International Version",
  msg: "The Message",
  goodnews: "Good News Translation",
  amp: "Amplified Bible",
};
