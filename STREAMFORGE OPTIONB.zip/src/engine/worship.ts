export interface WorshipSong {
  title: string;
  artist: string;
  origin: string;
  full: boolean; // complete public-domain lyrics vs. short excerpt
  lyrics: string[];
}

/**
 * Global Praise & Worship catalogue.
 * Hymns marked `full` are public-domain works reproduced in complete form
 * (verses + refrain). Contemporary entries carry a short sung excerpt only.
 */
export const WORSHIP_CATALOGUE: WorshipSong[] = [
  /* ---------------- public-domain hymns — full lyrics ---------------- */
  {
    title: "Amazing Grace", artist: "John Newton", origin: "England · 1772", full: true,
    lyrics: [
      "Amazing grace, how sweet the sound, that saved a wretch like me",
      "I once was lost, but now am found, was blind but now I see",
      "’Twas grace that taught my heart to fear, and grace my fears relieved",
      "How precious did that grace appear, the hour I first believed",
      "Through many dangers, toils and snares, I have already come",
      "’Tis grace hath brought me safe thus far, and grace will lead me home",
      "The Lord has promised good to me, His Word my hope secures",
      "He will my Shield and Portion be, as long as life endures",
      "When we’ve been there ten thousand years, bright shining as the sun",
      "We’ve no less days to sing God’s praise, than when we’d first begun",
    ],
  },
  {
    title: "It Is Well With My Soul", artist: "Horatio Spafford", origin: "USA · 1873", full: true,
    lyrics: [
      "When peace like a river attendeth my way",
      "When sorrows like sea billows roll",
      "Whatever my lot, Thou hast taught me to say",
      "It is well, it is well with my soul",
      "It is well, it is well with my soul",
      "Though Satan should buffet, though trials should come",
      "Let this blest assurance control",
      "That Christ hath regarded my helpless estate",
      "And hath shed His own blood for my soul",
      "My sin — oh the bliss of this glorious thought —",
      "My sin, not in part but the whole",
      "Is nailed to the cross, and I bear it no more",
      "Praise the Lord, praise the Lord, O my soul",
    ],
  },
  {
    title: "How Great Thou Art", artist: "Carl Boberg", origin: "Sweden · 1885", full: false,
    lyrics: [
      "O Lord my God, when I in awesome wonder",
      "Consider all the worlds Thy hands have made",
      "Then sings my soul, my Saviour God, to Thee",
      "How great Thou art, how great Thou art",
    ],
  },
  {
    title: "Holy, Holy, Holy", artist: "Reginald Heber", origin: "England · 1826", full: true,
    lyrics: [
      "Holy, holy, holy, Lord God Almighty",
      "Early in the morning our song shall rise to Thee",
      "Holy, holy, holy, merciful and mighty",
      "God in three Persons, blessed Trinity",
      "Holy, holy, holy, all the saints adore Thee",
      "Casting down their golden crowns around the glassy sea",
      "Cherubim and seraphim falling down before Thee",
      "Who wert, and art, and evermore shalt be",
      "Holy, holy, holy, though the darkness hide Thee",
      "Though the eye of sinful man Thy glory may not see",
      "Only Thou art holy, there is none beside Thee",
      "Perfect in power, in love and purity",
    ],
  },
  {
    title: "Great Is Thy Faithfulness", artist: "Thomas Chisholm", origin: "USA · 1923", full: true,
    lyrics: [
      "Great is Thy faithfulness, O God my Father",
      "There is no shadow of turning with Thee",
      "Thou changest not, Thy compassions they fail not",
      "As Thou hast been, Thou forever wilt be",
      "Great is Thy faithfulness, great is Thy faithfulness",
      "Morning by morning new mercies I see",
      "All I have needed, Thy hand hath provided",
      "Great is Thy faithfulness, Lord, unto me",
      "Summer and winter, and springtime and harvest",
      "Sun, moon and stars in their courses above",
      "Join with all nature in manifold witness",
      "To Thy great faithfulness, mercy and love",
    ],
  },
  {
    title: "Blessed Assurance", artist: "Fanny Crosby", origin: "USA · 1873", full: true,
    lyrics: [
      "Blessed assurance, Jesus is mine",
      "O what a foretaste of glory divine",
      "Heir of salvation, purchase of God",
      "Born of His Spirit, washed in His blood",
      "This is my story, this is my song",
      "Praising my Saviour all the day long",
      "Perfect submission, perfect delight",
      "Visions of rapture now burst on my sight",
      "Angels descending bring from above",
      "Echoes of mercy, whispers of love",
      "Perfect submission, all is at rest",
      "I in my Saviour am happy and blest",
    ],
  },
  {
    title: "What A Friend We Have In Jesus", artist: "Joseph Scriven", origin: "Ireland/Canada · 1855", full: true,
    lyrics: [
      "What a friend we have in Jesus, all our sins and griefs to bear",
      "What a privilege to carry everything to God in prayer",
      "O what peace we often forfeit, O what needless pain we bear",
      "All because we do not carry everything to God in prayer",
      "Have we trials and temptations? Is there trouble anywhere?",
      "We should never be discouraged, take it to the Lord in prayer",
      "Can we find a friend so faithful, who will all our sorrows share?",
      "Jesus knows our every weakness, take it to the Lord in prayer",
    ],
  },
  {
    title: "Come, Thou Fount", artist: "Robert Robinson", origin: "England · 1758", full: true,
    lyrics: [
      "Come, Thou Fount of every blessing, tune my heart to sing Thy grace",
      "Streams of mercy, never ceasing, call for songs of loudest praise",
      "Jesus sought me when a stranger, wandering from the fold of God",
      "He, to rescue me from danger, interposed His precious blood",
      "O to grace how great a debtor, daily I’m constrained to be",
      "Let Thy goodness, like a fetter, bind my wandering heart to Thee",
      "Prone to wander, Lord, I feel it, prone to leave the God I love",
      "Here’s my heart, O take and seal it, seal it for Thy courts above",
    ],
  },
  {
    title: "A Mighty Fortress", artist: "Martin Luther", origin: "Germany · 1529", full: true,
    lyrics: [
      "A mighty fortress is our God, a bulwark never failing",
      "Our helper He amid the flood of mortal ills prevailing",
      "For still our ancient foe doth seek to work us woe",
      "His craft and power are great, and armed with cruel hate",
      "On earth is not his equal",
      "Did we in our own strength confide, our striving would be losing",
      "Were not the right Man on our side, the Man of God’s own choosing",
      "Dost ask who that may be? Christ Jesus, it is He",
      "Lord Sabaoth, His Name, from age to age the same",
      "And He must win the battle",
    ],
  },
  {
    title: "Be Thou My Vision", artist: "Irish Hymn (trans. Byrne)", origin: "Ireland · 8th c.", full: true,
    lyrics: [
      "Be Thou my Vision, O Lord of my heart",
      "Naught be all else to me, save that Thou art",
      "Thou my best thought, by day or by night",
      "Waking or sleeping, Thy presence my light",
      "Be Thou my Wisdom, and Thou my true Word",
      "I ever with Thee and Thou with me, Lord",
      "Thou my great Father, I Thy true son",
      "Thou in me dwelling, and I with Thee one",
      "Riches I heed not, nor man’s empty praise",
      "Thou mine inheritance, now and always",
      "Thou and Thou only, first in my heart",
      "High King of heaven, my treasure Thou art",
    ],
  },
  {
    title: "Abide With Me", artist: "Henry Francis Lyte", origin: "Scotland · 1847", full: true,
    lyrics: [
      "Abide with me; fast falls the eventide",
      "The darkness deepens; Lord, with me abide",
      "When other helpers fail and comforts flee",
      "Help of the helpless, O abide with me",
      "Swift to its close ebbs out life’s little day",
      "Earth’s joys grow dim, its glories pass away",
      "Change and decay in all around I see",
      "O Thou who changest not, abide with me",
      "Hold Thou Thy cross before my closing eyes",
      "Shine through the gloom and point me to the skies",
      "Heaven’s morning breaks, and earth’s vain shadows flee",
      "In life, in death, O Lord, abide with me",
    ],
  },
  {
    title: "All Creatures Of Our God And King", artist: "St. Francis (trans. Draper)", origin: "Italy · 1225", full: true,
    lyrics: [
      "All creatures of our God and King, lift up your voice and with us sing",
      "Alleluia, alleluia",
      "Thou burning sun with golden beam, thou silver moon with softer gleam",
      "O praise Him, O praise Him, alleluia, alleluia, alleluia",
      "Thou rushing wind that art so strong, ye clouds that sail in heaven along",
      "Thou rising morn, in praise rejoice, ye lights of evening, find a voice",
      "Thou flowing water, pure and clear, make music for thy Lord to hear",
      "Thou fire so masterful and bright, that givest man both warmth and light",
    ],
  },
  {
    title: "Crown Him With Many Crowns", artist: "Matthew Bridges", origin: "England · 1851", full: true,
    lyrics: [
      "Crown Him with many crowns, the Lamb upon His throne",
      "Hark, how the heavenly anthem drowns all music but its own",
      "Awake, my soul, and sing of Him who died for thee",
      "And hail Him as thy matchless King through all eternity",
      "Crown Him the Lord of love, behold His hands and side",
      "Those wounds, yet visible above, in beauty glorified",
      "No angel in the sky can fully bear that sight",
      "But downward bends his wondering eye at mysteries so bright",
    ],
  },
  {
    title: "O For A Thousand Tongues", artist: "Charles Wesley", origin: "England · 1739", full: true,
    lyrics: [
      "O for a thousand tongues to sing my great Redeemer’s praise",
      "The glories of my God and King, the triumphs of His grace",
      "My gracious Master and my God, assist me to proclaim",
      "To spread through all the earth abroad the honours of Thy name",
      "Jesus, the name that charms our fears, that bids our sorrows cease",
      "’Tis music in the sinner’s ears, ’tis life, and health, and peace",
      "He breaks the power of cancelled sin, He sets the prisoner free",
      "His blood can make the foulest clean, His blood availed for me",
    ],
  },
  {
    title: "Rock Of Ages", artist: "Augustus Toplady", origin: "England · 1776", full: true,
    lyrics: [
      "Rock of Ages, cleft for me, let me hide myself in Thee",
      "Let the water and the blood, from Thy wounded side which flowed",
      "Be of sin the double cure, save from wrath and make me pure",
      "Not the labours of my hands can fulfil Thy law’s demands",
      "Could my zeal no respite know, could my tears forever flow",
      "All for sin could not atone; Thou must save, and Thou alone",
      "While I draw this fleeting breath, when mine eyes shall close in death",
      "When I soar to worlds unknown, see Thee on Thy judgment throne",
      "Rock of Ages, cleft for me, let me hide myself in Thee",
    ],
  },
  {
    title: "And Can It Be", artist: "Charles Wesley", origin: "England · 1738", full: true,
    lyrics: [
      "And can it be that I should gain an interest in the Saviour’s blood?",
      "Died He for me, who caused His pain? For me, who Him to death pursued?",
      "Amazing love, how can it be that Thou, my God, shouldst die for me?",
      "’Tis mystery all: the Immortal dies! Who can explore His strange design?",
      "In vain the firstborn seraph tries to sound the depths of love divine",
      "No condemnation now I dread; Jesus, and all in Him, is mine",
      "Alive in Him, my living Head, and clothed in righteousness divine",
      "Bold I approach the eternal throne, and claim the crown, through Christ my own",
    ],
  },

  /* ---------------- Nigerian Praise & Worship — excerpts ---------------- */
  { title: "Imela", artist: "Nathaniel Bassey", origin: "Nigeria", full: false, lyrics: ["Imela, imela, imela o", "Thank you Jesus, thank you Jesus", "For the cross and for the blood", "For all you’ve done in my life, Imela"] },
  { title: "Chukwu Ebuka", artist: "Nathaniel Bassey", origin: "Nigeria", full: false, lyrics: ["Chukwu Ebuka, the great God", "You are the one that I serve", "Onyedikachi, there is none like you"] },
  { title: "Yahweh", artist: "Nathaniel Bassey", origin: "Nigeria", full: false, lyrics: ["Yahweh, Yahweh, the God who answers by fire", "You are the Lord my God", "I bow before Your majesty"] },
  { title: "Alagbara", artist: "Tope Alabi", origin: "Nigeria", full: false, lyrics: ["Alagbara o, the mighty one", "You are powerful, you are mighty", "Oba to lagbara"] },
  { title: "Ogidi Jesus", artist: "Tope Alabi", origin: "Nigeria", full: false, lyrics: ["Ogidi Jesus, the rock of ages", "You are the solid rock", "My foundation, my strength"] },
  { title: "Jireh Mi", artist: "Tope Alabi", origin: "Nigeria", full: false, lyrics: ["Jireh mi, Jehovah my provider", "You will supply all my needs", "According to Your riches in glory"] },
  { title: "Way Maker", artist: "Sinach", origin: "Nigeria", full: false, lyrics: ["Way maker, miracle worker, promise keeper", "Light in the darkness, my God", "That is who you are"] },
  { title: "I Know Who I Am", artist: "Sinach", origin: "Nigeria", full: false, lyrics: ["I know who I am, I know whose I am", "I am a child of God", "He has made me righteous"] },
  { title: "Excess Love", artist: "Mercy Chinwo", origin: "Nigeria", full: false, lyrics: ["Your excess love, your excess grace", "Has found me, has held me", "I am overwhelmed"] },
  { title: "Miracle No Dey Tire Jesus", artist: "Moses Bliss", origin: "Nigeria", full: false, lyrics: ["Miracle no dey tire Jesus", "Signs and wonders follow me", "Na you be God o"] },
  { title: "Kedike", artist: "Dunsin Oyekan", origin: "Nigeria", full: false, lyrics: ["Kedike, kedike, my heart is fixed", "I will trust and not be afraid"] },
  { title: "Na You", artist: "Dunsin Oyekan", origin: "Nigeria", full: false, lyrics: ["Na you, na you, na you be God", "I give you all the glory"] },
  { title: "Nara", artist: "Tim Godfrey", origin: "Nigeria", full: false, lyrics: ["Nara, nara, eze di ndu", "You are the king of life", "I praise you"] },
  { title: "Adom", artist: "Folabi Nuel", origin: "Nigeria", full: false, lyrics: ["Adom, adom, your grace is enough", "Your mercy follows me all my days"] },

  /* ---------------- Global contemporary worship — excerpts ---------------- */
  { title: "Oceans (Where Feet May Fail)", artist: "Hillsong UNITED", origin: "Australia", full: false, lyrics: ["Spirit lead me where my trust is without borders", "Let me walk upon the waters", "Wherever You would call me", "Take me deeper than my feet could ever wander"] },
  { title: "What A Beautiful Name", artist: "Hillsong Worship", origin: "Australia", full: false, lyrics: ["What a beautiful name it is", "The name of Jesus", "What a powerful name it is", "Nothing can stand against"] },
  { title: "Goodness Of God", artist: "Bethel Music", origin: "USA", full: false, lyrics: ["All my life You have been faithful", "All my life You have been so, so good", "With every breath that I am able", "I will sing of the goodness of God"] },
  { title: "Reckless Love", artist: "Cory Asbury", origin: "USA", full: false, lyrics: ["O the overwhelming, never-ending, reckless love of God", "O it chases me down, fights ’til I’m found, leaves the ninety-nine", "I couldn’t earn it, I don’t deserve it, still You give Yourself away"] },
  { title: "Living Hope", artist: "Phil Wickham", origin: "USA", full: false, lyrics: ["What a beautiful Name, my Saviour King", "How great is the love the Father has lavished on us", "Hallelujah, praise the One who set me free", "Hallelujah, death has lost its grip on me"] },
  { title: "King Of Kings", artist: "Hillsong Worship", origin: "Australia", full: false, lyrics: ["In the darkness we were waiting, without hope and without light", "Till from heaven You came running, there was mercy in Your eyes", "Hallelujah, praise the King of kings"] },
  { title: "Build My Life", artist: "Pat Barrett", origin: "USA", full: false, lyrics: ["I will build my life upon Your love", "It is a firm foundation", "I will put my trust in You alone", "And I will not be shaken"] },
  { title: "Jireh", artist: "Maverick City / Elevation", origin: "USA", full: false, lyrics: ["Jehovah Jireh, my Provider", "You’re enough, that’s my anthem", "My help comes from the Maker of Heaven"] },
  { title: "Promises", artist: "Maverick City Music", origin: "USA", full: false, lyrics: ["You never fail, God, You never fail me", "I’ll hold on to Your promises", "You never fail, God"] },
  { title: "Trust In God", artist: "Elevation Worship", origin: "USA", full: false, lyrics: ["I trust in God, I trust in God", "My help comes from the Maker of Heaven and Earth", "He’s worthy to be trusted"] },
  { title: "Praise", artist: "Elevation Worship", origin: "USA", full: false, lyrics: ["This is the sound of my praise", "I’ll shout it loud from the rooftops", "I’ll praise Him anyway"] },
  { title: "Believe For It", artist: "CeCe Winans", origin: "USA", full: false, lyrics: ["I believe for it, what You’ve promised", "You’ve never failed me, so I’ll trust You again", "I know You’ll do what You said You would"] },
  { title: "Graves Into Gardens", artist: "Elevation Worship", origin: "USA", full: false, lyrics: ["You turn mourning into dancing", "You give beauty for ashes", "You turn graves into gardens", "My bones will sing of all that You have done"] },
  { title: "House Of The Lord", artist: "Phil Wickham", origin: "USA", full: false, lyrics: ["I will sing in the house of the Lord", "I will dance in the house of the Lord", "I will lift my hands to the One who saved my soul"] },
  { title: "Too Good To Not Believe", artist: "Brandon Lake", origin: "USA", full: false, lyrics: ["God is good, He’s so good", "He split the sea, He calmed the storm", "You’re too good to not believe"] },
  { title: "Thank You Jesus", artist: "Cory Asbury", origin: "USA", full: false, lyrics: ["Thank You Jesus, thank You Jesus", "For Your blood, for Your cross", "For Your life poured out for me"] },
  { title: "Worthy Of It All", artist: "David Brymer", origin: "USA", full: false, lyrics: ["You’re worthy of it all", "Worthy of it all", "I’m gonna give You praise", "Hallelujah, You’re worthy"] },
  { title: "Firm Foundation (He Won’t)", artist: "Cody Carnes", origin: "USA", full: false, lyrics: ["He won’t, He won’t give up on me", "He won’t, He won’t ever let me fall", "My hope is built on a firm foundation"] },
];

export function searchWorship(query: string): WorshipSong[] {
  const q = query.trim().toLowerCase();
  if (!q) return [];
  const terms = q.split(/\s+/);
  return WORSHIP_CATALOGUE.filter((s) => {
    const hay = `${s.title} ${s.artist} ${s.origin} ${s.lyrics.join(" ")}`.toLowerCase();
    return terms.every((t) => hay.includes(t));
  }).slice(0, 8);
}
