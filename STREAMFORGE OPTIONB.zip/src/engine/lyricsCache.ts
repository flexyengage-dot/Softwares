/**
 * Lyrics cache — saves every successfully fetched or searched song
 * in localStorage, sorted alphabetically, with full-text search.
 */

export interface CachedLyric {
  id: string;
  title: string;
  artist: string;
  lyrics: string;
  source: string;
  version: string;
  cachedAt: number;
}

const CACHE_KEY = "sf.worship.lyrics";
let cached: CachedLyric[] | null = null;

function loadAll(): CachedLyric[] {
  if (cached) return cached;
  try {
    const raw = localStorage.getItem(CACHE_KEY);
    cached = raw ? JSON.parse(raw) : [];
    cached!.sort((a, b) => (a.artist + a.title).localeCompare(b.artist + b.title));
  } catch {
    cached = [];
  }
  return cached!;
}

function saveAll() {
  cached!.sort((a, b) => (a.artist + a.title).localeCompare(b.artist + b.title));
  try { localStorage.setItem(CACHE_KEY, JSON.stringify(cached)); } catch { /* storage full */ }
}

/** Save a lyric after a successful search/fetch. Deduplicates by title+artist. */
export function cacheLyric(title: string, artist: string, lyrics: string, source: string, version: string) {
  const arr = loadAll();
  const key = `${artist.toLowerCase()}|${title.toLowerCase()}`;
  const existing = arr.findIndex((l) => `${l.artist.toLowerCase()}|${l.title.toLowerCase()}` === key);
  const entry: CachedLyric = {
    id: existing >= 0 ? arr[existing].id : `lyr-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    title, artist, lyrics, source, version,
    cachedAt: Date.now(),
  };
  if (existing >= 0) arr[existing] = entry;
  else arr.push(entry);
  cached = arr;
  saveAll();
}

/** Search cached lyrics by title, artist, or lyric text. Returns sorted alphabetically. */
export function searchCached(query: string): CachedLyric[] {
  const arr = loadAll();
  if (!query.trim()) return arr;
  const terms = query.toLowerCase().split(/\s+/);
  return arr.filter((l) => {
    const hay = `${l.title} ${l.artist} ${l.lyrics}`.toLowerCase();
    return terms.every((t) => hay.includes(t));
  });
}

/** Get all cached lyrics. */
export function getAllCached(): CachedLyric[] {
  return loadAll();
}

/** Remove a cached lyric by id. */
export function removeCached(id: string) {
  const arr = loadAll().filter((l) => l.id !== id);
  cached = arr;
  saveAll();
}

/** Clear all cached lyrics. */
export function clearCached() {
  cached = null;
  try { localStorage.removeItem(CACHE_KEY); } catch { /* ignore */ }
}

/** Total count. */
export function cachedCount(): number {
  return loadAll().length;
}

/** Total size in bytes. */
export function cachedSize(): string {
  const arr = loadAll();
  const bytes = JSON.stringify(arr).length;
  if (bytes > 1_048_576) return `${(bytes / 1_048_576).toFixed(1)} MB`;
  if (bytes > 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${bytes} B`;
}
