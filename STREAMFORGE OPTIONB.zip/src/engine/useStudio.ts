import { useCallback, useEffect, useRef, type MutableRefObject } from "react";
import { clamp, type StudioModel } from "./types";
import { composeProgram, drawScene, drawSelection } from "./render";
import { capture } from "./capture";
import { assets } from "./assets";

interface Level { v: number; peak: number }

export function useStudio(modelRef: MutableRefObject<StudioModel>, bump: () => void) {
  const previewEl = useRef<HTMLCanvasElement | null>(null);
  const programEl = useRef<HTMLCanvasElement | null>(null);
  const sparkEl = useRef<HTMLCanvasElement | null>(null);
  const thumbs = useRef(new Map<string, HTMLCanvasElement>());
  const meters = useRef(new Map<string, HTMLCanvasElement>());
  const levels = useRef(new Map<string, Level>());
  const sparkBuf = useRef<number[]>([]);

  const registerPreview = useCallback((el: HTMLCanvasElement | null) => { previewEl.current = el; }, []);
  const registerProgram = useCallback((el: HTMLCanvasElement | null) => { programEl.current = el; }, []);
  const registerSpark = useCallback((el: HTMLCanvasElement | null) => { sparkEl.current = el; }, []);
  const registerThumb = useCallback((id: string, el: HTMLCanvasElement | null) => {
    if (el) thumbs.current.set(id, el);
    else thumbs.current.delete(id);
  }, []);
  const registerMeter = useCallback((id: string, el: HTMLCanvasElement | null) => {
    if (el) meters.current.set(id, el);
    else meters.current.delete(id);
  }, []);

  useEffect(() => {
    let raf = 0;
    let last = performance.now();
    let frame = 0;

    const fit = (c: HTMLCanvasElement) => {
      const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
      const w = Math.max(2, Math.round(c.clientWidth * dpr));
      const h = Math.max(2, Math.round(c.clientHeight * dpr));
      if (c.width !== w || c.height !== h) { c.width = w; c.height = h; }
      return c.getContext("2d");
    };

    const tick = (now: number) => {
      const m = modelRef.current;
      const dt = clamp((now - last) / 1000, 0.001, 0.05);
      last = now;
      frame++;
      const t = now / 1000;

      /* ---- transition state machine ---- */
      if (m.trans.active) {
        m.trans.t += (dt * 1000) / m.trans.dur;
        if (m.trans.t >= 1) {
          m.programId = m.trans.to;
          m.previewId = m.trans.from;
          m.trans.active = false;
          m.trans.t = 0;
          const name = m.scenes.find((s) => s.id === m.programId)?.name ?? "?";
          m.events.unshift({ t: Date.now(), msg: `PGM ⇒ ${name} (${m.trans.kind.toUpperCase()})`, kind: "ok" });
          if (m.events.length > 24) m.events.length = 24;
          bump();
        }
      }
      /* ---- FTB ease ---- */
      m.ftb.alpha += (m.ftb.target - m.ftb.alpha) * Math.min(1, dt * 7);
      if (Math.abs(m.ftb.target - m.ftb.alpha) < 0.004) m.ftb.alpha = m.ftb.target;

      /* ---- monitors ---- */
      const pv = previewEl.current;
      if (pv) {
        const ctx = fit(pv);
        if (ctx) {
          const scene = m.scenes.find((s) => s.id === m.previewId);
          if (scene) {
            drawScene(ctx, scene, pv.width, pv.height, t, m.zoom.participants, m.zoom.phase === "connected");
            const sel = scene.sources.find((s) => s.id === m.selectedId);
            if (sel) drawSelection(ctx, sel, pv.width, pv.height);
          }
        }
      }
      const pg = programEl.current;
      if (pg) {
        const ctx = fit(pg);
        if (ctx) composeProgram(ctx, m, pg.width, pg.height, t);
      }

      /* ---- multiview (every 5th frame) ---- */
      if (frame % 5 === 0) {
        for (const sc of m.scenes) {
          const c = thumbs.current.get(sc.id);
          if (c) {
            const ctx = c.getContext("2d");
            if (ctx) drawScene(ctx, sc, c.width, c.height, t, m.zoom.participants, m.zoom.phase === "connected");
          }
        }
      }

      /* ---- VU meters ---- */
      capture.tick();
      // sync media transport / audio for every video input
      for (const sc of m.scenes) {
        for (const s of sc.sources) {
          if (s.type === "video-file" || s.type === "media") {
            assets.applyState(s.assetId, {
              playing: s.playing,
              loop: s.loop,
              audioMuted: s.audioMuted,
              audioVol: s.audioVol,
            });
          }
        }
      }
      // Meters only move with real input — silence otherwise
      let masterIn = 0;
      for (const ch of m.audio) {
        if (ch.kind === "master") continue;
        let target = 0;
        if (!ch.muted && ch.kind === "mic" && capture.hasAudio()) {
          target = capture.level * (ch.volume / 100);
        }
        const lv = levels.current.get(ch.id) ?? { v: 0, peak: 0 };
        lv.v += (target - lv.v) * Math.min(1, dt * 14);
        lv.peak = Math.max(lv.peak - dt * 0.5, lv.v);
        levels.current.set(ch.id, lv);
        masterIn = Math.max(masterIn, lv.v);
        paintMeter(meters.current.get(ch.id), lv);
      }
      const master = m.audio.find((c) => c.kind === "master");
      if (master) {
        const target = master.muted ? 0 : masterIn * (master.volume / 100);
        const lv = levels.current.get(master.id) ?? { v: 0, peak: 0 };
        lv.v += (target - lv.v) * Math.min(1, dt * 14);
        lv.peak = Math.max(lv.peak - dt * 0.5, lv.v);
        levels.current.set(master.id, lv);
        paintMeter(meters.current.get(master.id), lv, true);
      }

      /* ---- stream sparkline ---- */
      const mt = m.metrics;
      mt.frameMs += (clamp(now - lastRaw.current, 0.1, 100) - mt.frameMs) * 0.08;
      lastRaw.current = now;
      mt.fps = Math.round(clamp(1000 / mt.frameMs, 1, 240));
      if (frame % 24 === 0) {
        mt.latency = Math.round(clamp(mt.latency + (Math.random() - 0.5) * 5, 7, 21));
        mt.cpu = Math.round(clamp(mt.cpu + (Math.random() - 0.5) * 4, 8, 42));
        mt.gpu = Math.round(clamp(mt.gpu + (Math.random() - 0.5) * 5, 12, 58));
      }
      if (m.live) {
        mt.bitrate = clamp(mt.bitrate + (Math.random() - 0.5) * 160, 5400, 6500);
        mt.buffer = Math.round(clamp(mt.buffer + (Math.random() - 0.5) * 14, 34, 140));
        mt.jitter = Math.round(clamp(mt.jitter + (Math.random() - 0.5) * 2, 1, 9));
        if (Math.random() < 0.004) mt.dropped += 1;
        if (frame % 24 === 0) {
          const elapsed = (now - m.liveStart) / 1000;
          const target = Math.min(elapsed * 2.6, 280);
          m.viewers = Math.round(clamp(m.viewers + (target - m.viewers) * 0.28 + (Math.random() - 0.32) * 7, 0, 4000));
        }
        if (frame % 4 === 0) {
          sparkBuf.current.push(mt.bitrate);
          if (sparkBuf.current.length > 110) sparkBuf.current.shift();
        }
      }
      const sp = sparkEl.current;
      if (sp) {
        const ctx = sp.getContext("2d");
        if (ctx) {
          const W = sp.width, H = sp.height;
          ctx.clearRect(0, 0, W, H);
          ctx.strokeStyle = "rgba(255,255,255,0.08)";
          ctx.lineWidth = 1;
          for (let i = 1; i < 4; i++) {
            ctx.beginPath();
            ctx.moveTo(0, (H / 4) * i);
            ctx.lineTo(W, (H / 4) * i);
            ctx.stroke();
          }
          const buf = sparkBuf.current;
          if (buf.length > 1) {
            ctx.beginPath();
            buf.forEach((v, i) => {
              const x = (i / (110 - 1)) * W;
              const y = H - ((v - 5000) / 1800) * H * 0.9 - 2;
              if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
            });
            ctx.strokeStyle = m.live ? "#ffb020" : "#303a4b";
            ctx.lineWidth = 1.6;
            ctx.stroke();
            ctx.lineTo((buf.length - 1) / 109 * W, H);
            ctx.lineTo(0, H);
            ctx.closePath();
            ctx.fillStyle = m.live ? "rgba(255,176,32,0.12)" : "rgba(48,58,75,0.1)";
            ctx.fill();
          }
        }
      }

      raf = requestAnimationFrame(tick);
    };

    const lastRaw = { current: performance.now() };
    raf = requestAnimationFrame(tick);

    /* ---- active-speaker rotation for the Zoom bridge ---- */
    const talk = setInterval(() => {
      const m = modelRef.current;
      if (m.zoom.phase !== "connected") return;
      const cands = m.zoom.participants.filter((p) => p.micOn);
      for (const p of m.zoom.participants) p.talking = false;
      const count = 1 + (Math.random() < 0.4 ? 1 : 0);
      for (let i = 0; i < count && cands.length; i++) {
        const idx = Math.floor(Math.random() * cands.length);
        cands[idx].talking = true;
        cands.splice(idx, 1);
      }
      bump();
    }, 1700);

    return () => { cancelAnimationFrame(raf); clearInterval(talk); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* ------------------------------ transport API ------------------------------ */

  const getT = useCallback(() => {
    const m = modelRef.current;
    return m.trans.active ? m.trans.t : 0;
  }, [modelRef]);

  const setTbar = useCallback((v: number) => {
    const m = modelRef.current;
    if (v <= 0.001) { m.trans.active = false; m.trans.t = 0; return; }
    if (!m.trans.active) {
      if (m.previewId === m.programId) return;
      m.trans = { active: true, kind: m.transKind, t: v, dur: m.transDur, from: m.programId, to: m.previewId };
    } else {
      m.trans.t = v;
    }
  }, [modelRef]);

  const releaseTbar = useCallback(() => {
    const m = modelRef.current;
    if (!m.trans.active) return;
    if (m.trans.t >= 0.5) m.trans.dur = Math.max(110, (1 - m.trans.t) * m.transDur);
    else { m.trans.active = false; m.trans.t = 0; }
  }, [modelRef]);

  const auto = useCallback(() => {
    const m = modelRef.current;
    if (m.trans.active) { m.trans.dur = 120; return; }
    if (m.previewId === m.programId) return;
    m.trans = { active: true, kind: m.transKind === "cut" ? "fade" : m.transKind, t: 0, dur: m.transDur, from: m.programId, to: m.previewId };
  }, [modelRef]);

  const cut = useCallback(() => {
    const m = modelRef.current;
    m.trans.active = false;
    m.trans.t = 0;
    if (m.programId !== m.previewId) { m.programId = m.previewId; bump(); }
  }, [modelRef, bump]);

  const ftbToggle = useCallback(() => {
    const m = modelRef.current;
    m.ftb.target = m.ftb.target === 0 ? 1 : 0;
    bump();
  }, [modelRef, bump]);

  /** grab the current program frame as a PNG download */
  const snapshot = useCallback((): boolean => {
    const c = programEl.current;
    if (!c) return false;
    try {
      c.toBlob((b) => {
        if (!b) return;
        const url = URL.createObjectURL(b);
        const a = document.createElement("a");
        a.href = url;
        a.download = `streamforge_pgm_${new Date().toISOString().replace(/[:.]/g, "-")}.png`;
        a.click();
        setTimeout(() => URL.revokeObjectURL(url), 1200);
      }, "image/png");
      return true;
    } catch {
      return false;
    }
  }, []);

  return { registerPreview, registerProgram, registerSpark, registerThumb, registerMeter, getT, setTbar, releaseTbar, auto, cut, ftbToggle, snapshot };
}

function paintMeter(c: HTMLCanvasElement | undefined, lv: Level, isMaster = false) {
  if (!c) return;
  const ctx = c.getContext("2d");
  if (!ctx) return;
  const W = c.width, H = c.height;
  ctx.clearRect(0, 0, W, H);
  const segs = 22;
  const gap = 2;
  const sh = (H - gap * (segs - 1)) / segs;
  const lit = Math.round(lv.v * segs);
  const peakIdx = Math.round(lv.peak * segs);
  for (let i = 0; i < segs; i++) {
    const f = i / segs;
    const y = H - (i + 1) * (sh + gap) + gap;
    if (i < lit) {
      ctx.fillStyle = f > 0.86 ? "#ff4438" : f > 0.62 ? "#ffb020" : isMaster ? "#5eead4" : "#2fd273";
    } else {
      ctx.fillStyle = "#1a2028";
    }
    ctx.fillRect(0, y, W, sh);
  }
  if (peakIdx > 0) {
    const y = H - peakIdx * (sh + gap) + gap;
    ctx.fillStyle = "rgba(233,237,243,0.75)";
    ctx.fillRect(0, y - 1, W, 1.6);
  }
}
