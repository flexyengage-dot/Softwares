export interface ImageAsset {
  kind: "image";
  img: HTMLImageElement;
  ready: boolean;
}
export interface VideoAsset {
  kind: "video";
  video: HTMLVideoElement;
  ready: boolean;
}
export type Asset = ImageAsset | VideoAsset;

const store = new Map<string, Asset>();

/**
 * User-supplied media (picture / video files) keyed by source id.
 * Object URLs live for the session; after a reload the source renders
 * an "offline" slate until the file is added again.
 */
export const assets = {
  setImage(id: string, url: string) {
    const img = new Image();
    img.crossOrigin = "anonymous";
    const a: ImageAsset = { kind: "image", img, ready: false };
    store.set(id, a);
    img.onload = () => {
      a.ready = true;
    };
    img.src = url;
  },

  setVideo(id: string, url: string) {
    const video = document.createElement("video");
    video.crossOrigin = "anonymous";
    const a: VideoAsset = { kind: "video", video, ready: false };
    store.set(id, a);
    video.loop = true;
    video.muted = true;
    video.playsInline = true;
    video.src = url;
    video.onloadeddata = () => {
      a.ready = true;
      video.play().catch(() => undefined);
    };
    video.play().catch(() => undefined);
  },

  get(id: string | undefined): Asset | undefined {
    return id ? store.get(id) : undefined;
  },

  /** apply transport / audio state coming from the source model */
  applyState(id: string | undefined, st: { playing?: boolean; loop?: boolean; audioMuted?: boolean; audioVol?: number }) {
    const a = id ? store.get(id) : undefined;
    if (!a || a.kind !== "video") return;
    const v = a.video;
    v.loop = st.loop ?? true;
    const wantMuted = st.audioMuted ?? true;
    v.muted = wantMuted;
    v.volume = Math.min(1, Math.max(0, (st.audioVol ?? 100) / 100));
    if (st.playing === false && !v.paused) v.pause();
    if (st.playing !== false && v.paused && a.ready) v.play().catch(() => undefined);
  },

  remove(id: string | undefined) {
    if (!id) return;
    const a = store.get(id);
    if (a?.kind === "video") {
      a.video.pause();
      a.video.removeAttribute("src");
      a.video.load();
    }
    store.delete(id);
  },
};
