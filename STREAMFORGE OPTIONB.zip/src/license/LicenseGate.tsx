import { useEffect, useMemo, useState } from "react";
import {
  clearLicense,
  getMachineId,
  readLicense,
  saveLicense,
  validateLicenseToken,
  type LicensePayload,
} from "./license";

function fmtDate(ms?: number) {
  return ms ? new Date(ms).toLocaleDateString() : "Never";
}

export default function LicenseGate({ children }: { children: React.ReactNode }) {
  const [machineId, setMachineId] = useState("");
  const [token, setToken] = useState(() => readLicense());
  const [state, setState] = useState<{ ready: boolean; ok: boolean; reason?: string; payload?: LicensePayload }>({ ready: false, ok: false });
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    let alive = true;
    getMachineId().then((id) => { if (alive) setMachineId(id); });
    return () => { alive = false; };
  }, []);

  useEffect(() => {
    if (!machineId) return;
    let alive = true;
    validateLicenseToken(token, machineId).then((res) => {
      if (!alive) return;
      setState({ ready: true, ok: res.ok, reason: res.reason, payload: res.payload });
    });
    return () => { alive = false; };
  }, [token, machineId]);

  const status = useMemo(() => {
    if (!state.ready) return "Checking license...";
    if (state.ok) return state.payload?.universal ? "Universal unlock active" : "Licensed computer";
    return state.reason ?? "License required";
  }, [state]);

  if (state.ok) {
    return (
      <>
        {children}
        <div className="fixed bottom-7 left-2 z-[80] rounded bg-black/55 px-2 py-1 font-mono text-[9px] text-[#8a8a8a]">
          Licensed to {state.payload?.user || "User"} · {state.payload?.universal ? "Universal" : machineId}
        </div>
      </>
    );
  }

  const activate = async () => {
    const res = await validateLicenseToken(token, machineId);
    if (res.ok) {
      saveLicense(token);
      setState({ ready: true, ok: true, payload: res.payload });
    } else {
      setState({ ready: true, ok: false, reason: res.reason });
    }
  };

  const copyMachine = async () => {
    await navigator.clipboard?.writeText(machineId).catch(() => undefined);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1200);
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-[#111] p-6 text-[#e8e8e8]">
      <div className="w-full max-w-[560px] overflow-hidden rounded-xl border border-[#2b2b2b] bg-[#1f1f1f] shadow-2xl">
        <div className="border-b border-[#2b2b2b] bg-[#2a2a2a] px-5 py-4">
          <div className="text-[18px] font-semibold text-[#f0f0f0]">StreamForge Studio Activation</div>
          <div className="mt-1.5 text-[11px] font-medium text-[#2fd273]">
            [Richard Lukeman | +2347030518468] designed this software for churches. Send a DM.
          </div>
        </div>

        <div className="space-y-4 px-5 py-5">
          <div className="rounded border border-[#332] bg-[#201a10] px-3 py-2 text-[12px] text-[#e0c27a]">
            {status}
          </div>

          <div>
            <label className="mb-1 block text-[11px] uppercase tracking-widest text-[#888]">This computer ID</label>
            <div className="flex gap-2">
              <input readOnly value={machineId || "Generating..."} className="min-w-0 flex-1 rounded border border-[#111] bg-[#2b2b2b] px-3 py-2 font-mono text-[12px] text-white" />
              <button onClick={copyMachine} className="rounded bg-[#3d6ea8] px-3 text-[12px] font-semibold text-white hover:bg-[#4a7bb8]">
                {copied ? "Copied" : "Copy"}
              </button>
            </div>
            <p className="mt-1 text-[10px] text-[#777]">Send this Computer ID to the administrator to receive a license key for this machine.</p>
          </div>

          <div>
            <label className="mb-1 block text-[11px] uppercase tracking-widest text-[#888]">License key</label>
            <textarea value={token} onChange={(e) => setToken(e.target.value)} rows={5} placeholder="Paste SFS license key here..." className="w-full rounded border border-[#111] bg-[#2b2b2b] px-3 py-2 font-mono text-[11px] text-white outline-none focus:border-[#3d6ea8]" />
          </div>

          {state.payload && (
            <div className="grid grid-cols-2 gap-2 rounded border border-[#2b2b2b] bg-[#181818] p-3 text-[11px] text-[#aaa]">
              <span>User</span><span>{state.payload.user}</span>
              <span>Expires</span><span>{fmtDate(state.payload.expiresAt)}</span>
            </div>
          )}
        </div>

        <div className="flex justify-between border-t border-[#2b2b2b] bg-[#242424] px-5 py-3">
          <button onClick={() => { clearLicense(); setToken(""); }} className="rounded bg-[#333] px-4 py-2 text-[12px] text-[#ccc] hover:bg-[#444]">Clear</button>
          <button onClick={activate} disabled={!machineId || !token.trim()} className="rounded bg-[#2f6b45] px-5 py-2 text-[12px] font-bold text-white hover:bg-[#378052] disabled:opacity-40">Activate</button>
        </div>
      </div>
    </div>
  );
}