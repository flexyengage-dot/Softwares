export interface LicensePayload {
  app: "streamforge-studio";
  user: string;
  machine: string;
  issuedAt: number;
  expiresAt?: number;
  universal?: boolean;
  notes?: string;
}

export interface LicenseState {
  ok: boolean;
  reason?: string;
  payload?: LicensePayload;
}

const LICENSE_STORAGE = "streamforge.license.token.v1";
const INSTALL_STORAGE = "streamforge.install.id.v1";

// This is an offline licensing guard, not unbreakable DRM. Keep the admin
// generator private and do not publish generated universal keys.
const LICENSE_SALT = "SF-RLL-2026-OFFLINE-LICENSE-V1-3C57F5E1";

function bytesToBase64Url(bytes: Uint8Array) {
  let str = "";
  for (const b of bytes) str += String.fromCharCode(b);
  return btoa(str).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

function base64UrlToString(value: string) {
  const pad = "=".repeat((4 - (value.length % 4)) % 4);
  return atob((value + pad).replace(/-/g, "+").replace(/_/g, "/"));
}

async function sha256(text: string) {
  const data = new TextEncoder().encode(text);
  const hash = await crypto.subtle.digest("SHA-256", data);
  return bytesToBase64Url(new Uint8Array(hash));
}

export function getInstallId() {
  let id = localStorage.getItem(INSTALL_STORAGE);
  if (!id) {
    const random = new Uint8Array(16);
    crypto.getRandomValues(random);
    id = bytesToBase64Url(random);
    localStorage.setItem(INSTALL_STORAGE, id);
  }
  return id;
}

export async function getMachineId() {
  const install = getInstallId();
  const fp = [
    install,
    navigator.userAgent,
    navigator.language,
    screen.width,
    screen.height,
    screen.colorDepth,
    Intl.DateTimeFormat().resolvedOptions().timeZone,
  ].join("|");
  return (await sha256(fp)).slice(0, 24).toUpperCase();
}

export async function createLicenseToken(payload: LicensePayload) {
  const body = bytesToBase64Url(new TextEncoder().encode(JSON.stringify(payload)));
  const sig = await sha256(`${body}.${LICENSE_SALT}`);
  return `SFS.${body}.${sig}`;
}

export async function validateLicenseToken(token: string, machineId: string): Promise<LicenseState> {
  try {
    const parts = token.trim().split(".");
    if (parts.length !== 3 || parts[0] !== "SFS") return { ok: false, reason: "Invalid license format." };
    const [, body, sig] = parts;
    const expected = await sha256(`${body}.${LICENSE_SALT}`);
    if (sig !== expected) return { ok: false, reason: "Invalid license signature." };
    const payload = JSON.parse(base64UrlToString(body)) as LicensePayload;
    if (payload.app !== "streamforge-studio") return { ok: false, reason: "License is for another app." };
    if (payload.expiresAt && Date.now() > payload.expiresAt) return { ok: false, reason: "License expired." };
    if (!payload.universal && payload.machine !== machineId) {
      return { ok: false, reason: "This license belongs to another computer." };
    }
    return { ok: true, payload };
  } catch {
    return { ok: false, reason: "Unable to read license." };
  }
}

export function saveLicense(token: string) {
  localStorage.setItem(LICENSE_STORAGE, token.trim());
}

export function readLicense() {
  return localStorage.getItem(LICENSE_STORAGE) ?? "";
}

export function clearLicense() {
  localStorage.removeItem(LICENSE_STORAGE);
}