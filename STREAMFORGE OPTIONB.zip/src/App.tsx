import { useCallback, useEffect, useRef, useState } from "react";
import { applySave, loadSave, makeModel, saveModel } from "./engine/types";
import { useStudio } from "./engine/useStudio";
import { sfx } from "./engine/sfx";
import Monitor from "./components/Monitor";
import TransformDialog from "./components/TransformDialog";
import ObsDock from "./components/ObsDock";
import AddSourceMenu from "./components/AddSourceMenu";
import SourceProperties from "./components/SourceProperties";
import SettingsDialog from "./components/SettingsDialog";
import ZoomDialog from "./components/ZoomDialog";
import HelpDialog from "./components/HelpDialog";
import AudioIODialog from "./components/AudioIODialog";
import ConfirmDialog from "./components/ConfirmDialog";
import { openMeetingWindow } from "./engine/meetingWindow";
import BibleVersePopup from "./components/BibleVersePopup";
import WorshipFinderPopup from "./components/WorshipFinderPopup";
import {
  parseReference, lookupVerse, downloadFullBible, clearAllBibles,
  hasFullBible, installedSize, type VerseRef, type BibleVersion,
} from "./engine/bible";
import { assets } from "./engine/assets";
import { CW, CH, SOURCE_META, NETWORK_TYPES, type SourceType, type StudioModel } from "./engine/types";
import { StatusBar, TopBar } from "./components/Chrome";

/* per-type placement defaults used when a source is created */
const SRC_DEFAULTS: Record<string, { w: number; h: number; hue: number }> = {
  "live-cam": { w: 1280, h: 720, hue: 205 },
  camera: { w: 1280, h: 720, hue: 205 },
  display: { w: 1600, h: 900, hue: 215 },
  browser: { w: 1280, h: 720, hue: 210 },
  media: { w: 1280, h: 720, hue: 265 },
  image: { w: 960, h: 540, hue: 20 },
  "image-file": { w: 1280, h: 720, hue: 200 },
  "video-file": { w: 1280, h: 720, hue: 260 },
  color: { w: CW, h: CH, hue: 0 },
  text: { w: 900, h: 120, hue: 0 },
  "zoom-grid": { w: 1400, h: 900, hue: 215 },
  "zoom-guest": { w: 960, h: 720, hue: 158 },
  ndi: { w: 1280, h: 720, hue: 160 },
  gt: { w: 1400, h: 800, hue: 0 },
  stinger: { w: 1300, h: 180, hue: 0 },
  "srt-listener": { w: 1280, h: 720, hue: 204 },
  "srt-caller": { w: 1280, h: 720, hue: 204 },
  webrtc: { w: 1280, h: 720, hue: 145 },
  rtmp: { w: 1280, h: 720, hue: 38 },
  worship: { w: 1300, h: 150, hue: 0 },
  bible: { w: CW, h: CH, hue: 0 },
};

export interface BibleBg {
  mode: "transparent" | "solid" | "default" | "image";
  color: string;
  variant: number;
  assetId?: string;
}

export default function App() {
  const modelRef = useRef(makeModel());
  const [, setTick] = useState(0);
  const bump = useCallback(() => setTick((t) => t + 1), []);
  const engine = useStudio(modelRef, bump);

  const [boot, setBoot] = useState(true);
  const [bootFade, setBootFade] = useState(false);
  const [savedAt, setSavedAt] = useState<Date | null>(null);
  const [transformOpen, setTransformOpen] = useState(false);
  const [isFs, setIsFs] = useState(false);
  const programScreenRef = useRef<HTMLDivElement | null>(null);
  const lastSnap = useRef("");

  useEffect(() => {
    const d = loadSave();
    if (d) applySave(modelRef.current, d);
    sfx.setEnabled(modelRef.current.sound);
    const t1 = setTimeout(() => setBootFade(true), 900);
    const t2 = setTimeout(() => setBoot(false), 1200);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, []);

  useEffect(() => {
    const iv = setInterval(() => {
      const m = modelRef.current;
      const snap = JSON.stringify([
        m.scenes, m.audio, m.encoder, m.outputRes, m.dest, m.streamKey, m.sound,
        m.transKind, m.transDur, m.safeAreas, m.showMultiview, m.previewId, m.programId, m.zoom.user,
        m.recFormat, m.recPath, m.audioMonitor,
      ]);
      if (snap !== lastSnap.current) {
        lastSnap.current = snap;
        if (saveModel(m)) setSavedAt(new Date());
      }
    }, 2000);
    return () => clearInterval(iv);
  }, []);

  useEffect(() => {
    const iv = setInterval(bump, 700);
    return () => clearInterval(iv);
  }, [bump]);

  useEffect(() => {
    const fn = () => setIsFs(!!document.fullscreenElement);
    document.addEventListener("fullscreenchange", fn);
    return () => document.removeEventListener("fullscreenchange", fn);
  }, []);

  const log = useCallback((msg: string, kind: "info" | "ok" | "warn" = "info") => {
    const m = modelRef.current;
    m.events.unshift({ t: Date.now(), msg, kind });
    if (m.events.length > 24) m.events.length = 24;
    bump();
  }, [bump]);

  const saveNow = useCallback(() => {
    if (saveModel(modelRef.current)) {
      setSavedAt(new Date());
      sfx.play("chime");
      log("Layout saved", "ok");
    } else log("Save failed", "warn");
  }, [log]);

  const importFile = useCallback((file: File) => {
    file.text().then((txt) => {
      const data = JSON.parse(txt) as { scenes?: unknown };
      const scenes = Array.isArray(data) ? data : data.scenes;
      if (!Array.isArray(scenes) || scenes.length === 0) throw new Error("bad");
      applySave(modelRef.current, { scenes });
      sfx.play("chime");
      log(`Imported ${modelRef.current.scenes.length} scenes`, "ok");
      bump();
    }).catch(() => {
      sfx.play("deny");
      log("Import failed", "warn");
    });
  }, [bump, log]);

  const setPreview = useCallback((id: string) => {
    const m = modelRef.current;
    if (m.trans.active && m.trans.to !== id) {
      m.trans.active = false;
      m.trans.t = 0;
    }
    if (m.previewId !== id) sfx.play("tick");
    m.previewId = id;
    m.selectedId = null;
    bump();
  }, [bump]);

  const onSelect = useCallback((id: string | null) => {
    if (id && modelRef.current.selectedId !== id) sfx.play("select");
    modelRef.current.selectedId = id;
    bump();
  }, [bump]);

  const toggleLive = useCallback(() => {
    const m = modelRef.current;
    m.live = !m.live;
    if (m.live) {
      m.liveStart = Date.now();
      m.metrics.dropped = 0;
      m.metrics.bitrate = 6000;
      m.viewers = 0;
      sfx.play("chime");
      log("Streaming started", "ok");
    } else {
      sfx.play("low");
      log("Streaming stopped", "info");
    }
    bump();
  }, [bump, log]);

  const toggleRec = useCallback(() => {
    const m = modelRef.current;
    m.recording = !m.recording;
    if (m.recording) {
      m.recStart = Date.now();
      sfx.play("thud");
      log(`Recording → take_001.${m.recFormat}`, "warn");
    } else {
      sfx.play("select");
      log("Recording stopped", "info");
    }
    bump();
  }, [bump, log]);

  const resetLayout = useCallback(() => {
    const connected = modelRef.current.zoom.phase === "connected";
    modelRef.current = makeModel();
    if (connected) modelRef.current.zoom.phase = "connected";
    sfx.play("thud");
    bump();
  }, [bump]);

  const autoFx = useCallback(() => {
    const m = modelRef.current;
    if (m.previewId !== m.programId || m.trans.active) sfx.play("whoosh", m.transDur);
    engine.auto();
  }, [engine]);

  const cutFx = useCallback(() => {
    const m = modelRef.current;
    if (m.previewId !== m.programId || m.trans.active) sfx.play("thud");
    engine.cut();
  }, [engine]);

  const ftbFx = useCallback(() => {
    sfx.play(modelRef.current.ftb.target === 0 ? "low" : "select");
    engine.ftbToggle();
  }, [engine]);

  const releaseFx = useCallback(() => {
    if (engine.getT() > 0.5) sfx.play("whoosh", 320);
    engine.releaseTbar();
  }, [engine]);

  const toggleProgramFs = useCallback(() => {
    if (document.fullscreenElement) {
      void document.exitFullscreen();
      log("Fullscreen closed", "info");
    } else if (programScreenRef.current) {
      void programScreenRef.current.requestFullscreen().catch(() => log("Fullscreen blocked", "warn"));
      sfx.play("whoosh", 280);
      log("Program fullscreen", "ok");
    }
  }, [log]);

  const snapshotFx = useCallback(() => {
    if (engine.snapshot()) {
      sfx.play("tick");
      log("Snapshot saved", "ok");
    } else {
      sfx.play("deny");
      log("Snapshot failed", "warn");
    }
  }, [engine, log]);

  /* --------- Add-Source flow: chooser → properties → create --------- */
  const [addPickerOpen, setAddPickerOpen] = useState(false);
  const [propType, setPropType] = useState<SourceType | null>(null);
  const [propEditing, setPropEditing] = useState<string | null>(null); // source id when editing existing
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [zoomOpen, setZoomOpen] = useState(false);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [confirmQuit, setConfirmQuit] = useState(false);
  const allowClose = useRef(false);

  // ALWAYS ask before leaving the app (tab close / navigate)
  useEffect(() => {
    const onBeforeUnload = (e: BeforeUnloadEvent) => {
      if (allowClose.current) return;
      e.preventDefault();
      e.returnValue = "";
      return "";
    };
    window.addEventListener("beforeunload", onBeforeUnload);
    return () => window.removeEventListener("beforeunload", onBeforeUnload);
  }, []);

  const doQuit = useCallback(() => {
    allowClose.current = true;
    sfx.play("low");
    window.close();
  }, []);

  const openAddSource = useCallback(() => {
    setPropEditing(null);
    setAddPickerOpen(true);
  }, []);

  const addScene = useCallback(() => {
    const m = modelRef.current;
    const sc = { id: `sc-${Date.now()}`, name: `Scene ${m.scenes.length + 1}`, sources: [] as StudioModel["scenes"][number]["sources"] };
    m.scenes.push(sc);
    m.previewId = sc.id;
    m.selectedId = null;
    sfx.play("tick");
    log(`Scene added — ${sc.name}`, "ok");
    bump();
  }, [log, bump]);

  const onPickSourceType = useCallback((t: SourceType) => {
    setAddPickerOpen(false);
    setPropType(t);
  }, []);

  const openProperties = useCallback((id: string) => {
    const m = modelRef.current;
    const scene = m.scenes.find((s) => s.id === m.previewId);
    const src = scene?.sources.find((s) => s.id === id);
    if (!src) return;
    setPropEditing(id);
    setPropType(src.type);
  }, []);

  const openZoom = useCallback(() => {
    setPropType(null);
    setPropEditing(null);
    setZoomOpen(true);
  }, []);

  /* ---- live meeting room in its own window ---- */
  const meetingWinRef = useRef<Window | null>(null);

  const joinMeeting = useCallback((p: { meetingId: string; user: string; deviceId: string; useVideo: boolean; useAudio: boolean }) => {
    const m = modelRef.current;
    setZoomOpen(false);
    const win = openMeetingWindow({
      meetingId: p.meetingId,
      user: p.user,
      deviceId: p.deviceId,
      useVideo: p.useVideo,
      useAudio: p.useAudio,
      peers: m.zoom.participants.map((pp) => ({ n: pp.name, h: pp.hue })),
      onClosed: () => {
        meetingWinRef.current = null;
        const mm = modelRef.current;
        if (mm.zoom.phase === "connected") {
          mm.zoom.phase = "idle";
          log("Meeting window closed — bridge ended", "info");
          bump();
        }
      },
    });
    if (!win) {
      sfx.play("deny");
      log("Pop-up blocked — allow pop-ups to open the meeting room", "warn");
      return;
    }
    meetingWinRef.current = win;
    m.zoom.meetingId = p.meetingId;
    m.zoom.user = p.user;
    m.zoom.phase = "connected";
    sfx.play("chime");
    log(`Joined meeting ${p.meetingId} — room opened in a new window`, "ok");
    bump();
  }, [log, bump]);

  const focusMeeting = useCallback(() => {
    const w = meetingWinRef.current;
    if (w && !w.closed) {
      w.focus();
    } else {
      setZoomOpen(true);
    }
  }, []);

  useEffect(() => () => { meetingWinRef.current?.close(); }, []);

  /* ---- live Bible verse listening (speech recognition) ---- */
  const [bibleListening, setBibleListening] = useState(false);
  const [bibleFinderOpen, setBibleFinderOpen] = useState(false);
  const [worshipFinderOpen, setWorshipFinderOpen] = useState(false);
  const [bibleInfoTick, setBibleInfoTick] = useState(0);
  const recogRef = useRef<{ stop: () => void } | null>(null);
  const lastRefAt = useRef(0);

  /* First scripture lands in Preview so the operator can check it; every verse
     after that goes straight to Program so the preacher's reading never stalls. */
  const placeBibleVerse = useCallback((ref: VerseRef, text: string, sourceLabel: string, bg?: BibleBg) => {
    const m = modelRef.current;
    const armed = m.bibleArmed;
    const targetId = armed ? m.programId : m.previewId;
    let scene = m.scenes.find((s) => s.id === targetId);
    if (!scene) {
      scene = { id: `sc-${Date.now()}`, name: armed ? "SCRIPTURE LIVE" : "SCRIPTURE", sources: [] };
      m.scenes.push(scene);
      if (armed) m.programId = scene.id; else m.previewId = scene.id;
    }
    let src = scene.sources.find((s) => s.type === "bible") as (typeof scene.sources)[number] | undefined;
    if (!src) {
      const d = SRC_DEFAULTS.bible;
      src = {
        id: `src-${Date.now()}-b`, name: "Bible Verse", type: "bible",
        x: 0, y: 0, w: d.w, h: d.h, bw: d.w, bh: d.h,
        visible: true, hue: 0, seed: 11, audioVol: 100,
      };
      scene.sources.push(src);
    }
    src.text = text;
    src.url = `${ref.book} ${ref.chapter}:${ref.verse}`;
    src.color = "#d4a437";
    if (bg) {
      src.bibleBg = bg.mode;
      src.bibleBgColor = bg.color;
      src.bibleBgVariant = bg.variant;
      if (bg.assetId) src.bibleBgAsset = bg.assetId;
    }
    (src as unknown as Record<string, unknown>).bornAt = performance.now() / 1000;
    src.visible = true;
    m.selectedId = src.id;
    if (!armed) m.bibleArmed = true;
    (window as unknown as { __sfT?: number }).__sfT = performance.now() / 1000;
    sfx.play("chime");
    log(`${ref.book} ${ref.chapter}:${ref.verse} → ${armed ? "Program (live)" : "Preview"} (${sourceLabel})`, "ok");
    bump();
  }, [log, bump]);

  const toggleBibleListen = useCallback(() => {
    const SR = (window as unknown as { SpeechRecognition?: new () => any; webkitSpeechRecognition?: new () => any });
    const Ctor = SR.SpeechRecognition ?? SR.webkitSpeechRecognition;
    if (!Ctor) { log("Speech recognition is not supported in this browser", "warn"); return; }
    if (bibleListening) {
      recogRef.current?.stop();
      recogRef.current = null;
      setBibleListening(false);
      log("Live Verse Listening stopped", "info");
      return;
    }
    const rec = new Ctor();
    rec.continuous = true;
    rec.interimResults = true;
    rec.lang = "en-US";
    rec.onresult = (e: { resultIndex: number; results: ArrayLike<{ isFinal: boolean; 0: { transcript: string } }> }) => {
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const r = e.results[i];
        const transcript = r[0]?.transcript ?? "";
        const ref = parseReference(transcript);
        if (ref && Date.now() - lastRefAt.current > 4000) {
          lastRefAt.current = Date.now();
          void lookupVerse(ref).then((res) => {
            if (res) placeBibleVerse(ref, res.text, res.source);
            else log(`${ref.book} ${ref.chapter}:${ref.verse} not available offline`, "warn");
          });
        }
      }
    };
    rec.onerror = () => { /* keep listening */ };
    rec.onend = () => { if (recogRef.current) { try { rec.start(); } catch { /* ignore */ } } };
    try {
      rec.start();
      recogRef.current = rec;
      setBibleListening(true);
      log("Live Verse Listening active — speak a reference like “John 3:16”", "ok");
    } catch { log("Could not start the microphone", "warn"); }
  }, [bibleListening, log, placeBibleVerse]);

  const [bibleVersion, setBibleVersion] = useState<BibleVersion>("kjv");

  const bibleDownload = useCallback((ver: BibleVersion = "kjv") => {
    setBibleVersion(ver);
    log(`Downloading ${ver.toUpperCase()} for offline use…`, "info");
    void downloadFullBible(ver, (pct) => { if (pct === 100) setBibleInfoTick((t) => t + 1); }).then((res) => {
      setBibleInfoTick((t) => t + 1);
      if (res.ok) { sfx.play("chime"); log(`${ver.toUpperCase()} installed offline — ${res.verses.toLocaleString()} verses`, "ok"); }
      else log(`Bible download failed: ${res.error}`, "warn");
    });
  }, [log]);

  const bibleClear = useCallback(() => {
    clearAllBibles();
    setBibleInfoTick((t) => t + 1);
    log("Offline Bible data cleared", "info");
  }, [log]);

  void bibleInfoTick;
  const bibleInfo = hasFullBible()
    ? `${bibleVersion.toUpperCase()} installed (${installedSize()}). All verses resolve offline.`
    : `Built-in seed + live cache. Download from Bible menu for full offline coverage.`;

  const openTransform = useCallback((id: string) => {
    modelRef.current.selectedId = id;
    setTransformOpen(true);
    bump();
  }, [bump]);

  const doDeleteSource = useCallback((id: string) => {
    const m = modelRef.current;
    const scene = m.scenes.find((s) => s.id === m.previewId);
    if (!scene) return;
    const src = scene.sources.find((s) => s.id === id);
    if (!src) return;
    if ((src as any).assetId) assets.remove((src as any).assetId);
    scene.sources = scene.sources.filter((s) => s.id !== id);
    m.selectedId = null;
    sfx.play("select");
    log(`Source removed — ${src.name}`, "info");
    bump();
  }, [log, bump]);

  const confirmProperties = useCallback((payload: { name: string; props: Record<string, unknown>; file?: { kind: "image" | "video"; file: File } }) => {
    const m = modelRef.current;
    const scene = m.scenes.find((s) => s.id === m.previewId);
    if (!scene || !propType) return;

    if (propEditing) {
      // update existing
      const src = scene.sources.find((s) => s.id === propEditing) as any;
      if (src) {
        src.name = payload.name;
        Object.assign(src, payload.props);
        // named props → canonical fields
        if (typeof (payload.props as any).text === "string") src.text = (payload.props as any).text;
        if (typeof (payload.props as any).color === "string") src.color = (payload.props as any).color;
        if (typeof (payload.props as any).url === "string") src.url = (payload.props as any).url;
        if (typeof (payload.props as any).participantId === "string") src.participantId = (payload.props as any).participantId;
        if (payload.file) {
          src.assetId = src.id;
          if (payload.file.kind === "image") assets.setImage(src.id, URL.createObjectURL(payload.file.file));
          else assets.setVideo(src.id, URL.createObjectURL(payload.file.file));
        }
        sfx.play("tick");
        log(`Source updated — ${src.name}`, "ok");
      }
    } else {
      // create new
      const isNetwork = NETWORK_TYPES.includes(propType);
      // Network inputs automatically get their own dedicated scene
      let targetScene = scene;
      if (isNetwork) {
        const label = SOURCE_META.find((x) => x.type === propType)?.label ?? propType;
        const ns = { id: `sc-${Date.now()}`, name: `${label.toUpperCase()} ${m.scenes.length + 1}`, sources: [] as StudioModel["scenes"][number]["sources"] };
        m.scenes.push(ns);
        targetScene = ns;
        m.previewId = ns.id;
        // Program is only reached via a transition — never auto-sent
        log(`Auto-created scene for ${label}`, "ok");
      }
      const d = SRC_DEFAULTS[propType] ?? SRC_DEFAULTS.camera;
      const off = (targetScene.sources.length % 4) * 36;
      const id = `src-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
      const src: any = {
        id,
        name: payload.name || SOURCE_META.find((x) => x.type === propType)?.label || propType,
        type: propType,
        x: Math.round((CW - d.w) / 2 + off),
        y: Math.round((CH - d.h) / 2 + off * 0.5),
        w: d.w,
        h: d.h,
        bw: d.w,
        bh: d.h,
        visible: true,
        hue: d.hue,
        seed: Math.floor(Math.random() * 9999),
        audioVol: 100,
        ...payload.props,
        text: (payload.props as any).text as string | undefined,
        color: (payload.props as any).color as string | undefined,
        url: (payload.props as any).url as string | undefined,
        participantId: (payload.props as any).participantId as string | undefined,
        playing: propType === "video-file" || propType === "media" ? true : undefined,
        loop: propType === "video-file" || propType === "media" ? true : undefined,
        audioMuted: propType === "video-file" ? false : propType === "media" ? true : undefined,
      };
      if (payload.file) {
        src.assetId = id;
        if (payload.file.kind === "image") assets.setImage(id, URL.createObjectURL(payload.file.file));
        else assets.setVideo(id, URL.createObjectURL(payload.file.file));
      }
      /* IP / network camera: attach the real stream asset */
      if (propType === "camera") {
        const url = (payload.props as { ipUrl?: string }).ipUrl;
        const kind = (payload.props as { ipKind?: string }).ipKind ?? "auto";
        if (url) {
          src.assetId = id;
          const isVideoKind = kind === "hls" || kind === "mp4" || /\.(mp4|webm|m3u8)(\?|$)/i.test(url);
          if (isVideoKind) assets.setVideo(id, url);
          else assets.setImage(id, url);
        }
      }
      targetScene.sources.push(src);
      m.selectedId = id;
      sfx.play("chime");
      log(`Source added — ${src.name}`, "ok");
    }

    setPropType(null);
    setPropEditing(null);
    bump();
  }, [propType, propEditing, log, bump]);

  const [helpOpen, setHelpOpen] = useState(false);
  const [audioIOId, setAudioIOId] = useState<string | null>(null);
  const openNetwork = useCallback((type: SourceType) => {
    setPropEditing(null);
    setPropType(type);
  }, []);

  const saveAudioIO = useCallback((patch: Record<string, unknown>) => {
    const m = modelRef.current;
    const ch = m.audio.find((c) => c.id === audioIOId);
    if (!ch) return;
    Object.assign(ch, patch);
    sfx.play("tick");
    log(`${ch.name} → ${patch.inputDevice ?? patch.outputDevice ?? "monitor " + (patch.monitorMode ?? "set")}`, "info");
    bump();
  }, [audioIOId, log, bump]);

  // Praise & Worship — place a lyric as lower-third OR centred full-screen.
  // `auto` mirrors the source onto Program immediately; otherwise Preview only.
  const placeWorshipLine = useCallback((
    song: { title: string; artist: string },
    lyric: string,
    opts: { mode: "lower" | "full"; font: string; auto: boolean; color: string },
  ) => {
    const m = modelRef.current;
    let pv = m.scenes.find((s) => s.id === m.previewId);
    if (!pv) { pv = { id: `sc-${Date.now()}`, name: "MAIN", sources: [] }; m.scenes.push(pv); m.previewId = pv.id; }
    let pg = m.scenes.find((s) => s.id === m.programId);
    if (!pg) { pg = { id: `sc-${Date.now()}-pgm`, name: "PROGRAM", sources: [] }; m.scenes.push(pg); m.programId = pg.id; }

    const full = opts.mode === "full";
    let src = pv.sources.find((s) => s.type === "worship") as (typeof pv.sources)[number] | undefined;
    if (!src) {
      const d = SRC_DEFAULTS.worship;
      src = {
        id: `src-${Date.now()}-w`,
        name: `${full ? "Lyric" : "Lower Third"} — ${song.title}`,
        type: "worship",
        x: full ? 0 : Math.round((CW - d.w) / 2),
        y: full ? 0 : CH - d.h - 90,
        w: full ? CW : d.w, h: full ? CH : d.h, bw: full ? CW : d.w, bh: full ? CH : d.h,
        visible: true, hue: 0, seed: 7, audioVol: 100,
      };
      pv.sources.push(src);
    }
    src.text = lyric;
    src.url = `${song.title} • ${song.artist}`;
    src.color = opts.color;
    src.worshipMode = opts.mode;
    src.worshipFont = opts.font;
    src.visible = true;
    if (opts.auto && !pg.sources.includes(src)) pg.sources.push(src);
    m.selectedId = src.id;
    sfx.play("chime");
    log(`${full ? "Full-screen lyric" : "Lower third"} — “${lyric.slice(0, 40)}” (${song.artist})${opts.auto ? " → Preview + Program" : ""}`, "ok");
    bump();
  }, [log, bump]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement | null;
      if (t && (t.tagName === "INPUT" || t.tagName === "SELECT" || t.tagName === "TEXTAREA")) return;
      const m = modelRef.current;
      const key = e.key.toLowerCase();
      if (key === "delete" || key === "backspace") {
        // Delete selected source — always ask for permission first
        if (m.selectedId && !zoomOpen && !settingsOpen && !transformOpen && !addPickerOpen && !propType) {
          setConfirmDeleteId(m.selectedId);
        }
        return;
      }
      if (key === "c") cutFx();
      else if (key === "a") autoFx();
      else if (key === "f") ftbFx();
      else if (key === "l") toggleLive();
      else if (key === "r") toggleRec();
      else if (key === "escape") onSelect(null);
      else {
        const n = Number(e.key);
        if (n >= 1 && n <= m.scenes.length) setPreview(m.scenes[n - 1].id);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [autoFx, cutFx, ftbFx, toggleLive, toggleRec, setPreview, onSelect, zoomOpen, settingsOpen, transformOpen, addPickerOpen, propType]);

  /* OBS-style vertical quick transitions between monitors */
  const m = modelRef.current;
  const [tbar, setTbarUi] = useState(0);
  useEffect(() => {
    const iv = setInterval(() => setTbarUi(Math.round(engine.getT() * 1000)), 80);
    return () => clearInterval(iv);
  }, [engine]);

  const previewName = m.scenes.find((s) => s.id === m.previewId)?.name ?? "(no scene)";
  const programName = m.scenes.find((s) => s.id === m.programId)?.name ?? "(no scene)";

  /* apply theme to the <html> element */
  useEffect(() => {
    document.documentElement.dataset.theme = m.theme;
  }, [m.theme]);

  const editingSource = propEditing
    ? m.scenes.find((s) => s.id === m.previewId)?.sources.find((s) => s.id === propEditing) ?? null
    : null;

  return (
    <div className="flex h-screen min-w-[1200px] select-none flex-col overflow-hidden bg-[#2f2f2f] text-[#e8e8e8]" style={{ fontFamily: "Segoe UI, system-ui, sans-serif" }}>
      <TopBar
        modelRef={modelRef}
        bump={bump}
        log={log}
        onResetLayout={resetLayout}
        onSaveNow={saveNow}
        onImportFile={importFile}
        onExit={() => setConfirmQuit(true)}
        onNetwork={openNetwork}
        onHelp={() => setHelpOpen(true)}
        bibleListening={bibleListening}
        onToggleBibleListen={toggleBibleListen}
        onBibleDownload={(v) => bibleDownload(v as BibleVersion)}
        onBibleClear={bibleClear}
        bibleInfo={bibleInfo}
      />

      {/* TOP: Preview | Transitions | Program  — big, like OBS */}
      <div className="flex min-h-0 flex-1 flex-col px-2 pt-2">
        {/* fullscreen bar — above & between the monitors */}
        <div className="mb-1 flex items-center gap-3 px-1">
          <div className="mb-0 text-[18px] font-normal text-[#f0f0f0]">Preview: {previewName}</div>
          <div className="flex-1" />
          <button
            onClick={toggleProgramFs}
            title={isFs ? "Exit fullscreen — return program to this window" : "Send Program to a fullscreen / second display"}
            className={`group flex items-center gap-2 rounded-md border px-4 py-1.5 text-[12px] font-bold uppercase tracking-widest transition-all ${
              isFs
                ? "border-[#31c48d] bg-[#123c26] text-[#31c48d] shadow-[0_0_14px_rgba(49,196,141,0.35)]"
                : "border-[#e5484d] bg-[#3a1517] text-[#ff8a8a] hover:bg-[#4a1a1c]"
            }`}
          >
            <span className={`h-2 w-2 rounded-full ${isFs ? "bg-[#31c48d]" : "bg-[#e5484d] group-hover:animate-pulse"}`} />
            {isFs ? "Fullscreen Active" : "Go Fullscreen"}
          </button>
          <div className="flex-1" />
          <div className="mb-0 text-[18px] font-normal text-[#f0f0f0]">Program: {programName}</div>
        </div>
        <div className="flex min-h-0 flex-1 gap-0">
        <div className="flex min-w-0 flex-1 flex-col">
          <div className="min-h-0 flex-1">
            <Monitor
              kind="preview"
              modelRef={modelRef}
              register={engine.registerPreview}
              onSelect={onSelect}
              onCommit={bump}
              onOpenTransform={() => setTransformOpen(true)}
            />
          </div>
        </div>

        {/* center transition strip — OBS Quick Transitions */}
        <div className="mx-2 flex w-[150px] flex-none flex-col items-stretch justify-center gap-2 py-8">
          <div className="rounded bg-[#3a3a3a] px-2 py-2 text-center text-[12px] text-[#ddd]">Transition</div>

          <div className="text-[11px] text-[#aaa]">Quick Transitions</div>
          <button onClick={cutFx} className="rounded bg-[#4a4a4a] px-2 py-2 text-[13px] text-white hover:bg-[#5a5a5a]">
            Cut
          </button>
          <button onClick={autoFx} className="rounded bg-[#4a4a4a] px-2 py-2 text-[13px] text-white hover:bg-[#5a5a5a]">
            Fade ({m.transDur}ms)
          </button>
          <button onClick={ftbFx} className="rounded bg-[#4a4a4a] px-2 py-2 text-[13px] text-white hover:bg-[#5a5a5a]">
            Fade to Black ({m.transDur}ms)
          </button>

          <div className="mt-2">
            <input
              type="range"
              min={0}
              max={1000}
              value={tbar}
              onChange={(e) => {
                const v = Number(e.target.value);
                setTbarUi(v);
                engine.setTbar(v / 1000);
              }}
              onPointerUp={releaseFx}
              className="w-full accent-[#d0d0d0]"
              aria-label="T-Bar"
            />
          </div>

        </div>

        <div className="flex min-w-0 flex-1 flex-col">
          <div className="min-h-0 flex-1">
            <Monitor
              kind="program"
              modelRef={modelRef}
              register={engine.registerProgram}
              onSnapshot={snapshotFx}
              registerScreen={(el) => {
                programScreenRef.current = el;
              }}
            />
          </div>
        </div>
        </div>
      </div>

      {/* BOTTOM DOCK — vMix layout */}
      <ObsDock
        modelRef={modelRef}
        bump={bump}
        log={log}
        setPreview={setPreview}
        onSelect={onSelect}
        auto={autoFx}
        cut={cutFx}
        ftbToggle={ftbFx}
        toggleLive={toggleLive}
        toggleRec={toggleRec}
        registerMeter={engine.registerMeter}
        openAddSource={openAddSource}
        openProperties={openProperties}
        openSettings={() => setSettingsOpen(true)}
        openZoom={openZoom}
        focusMeeting={focusMeeting}
        openTransform={openTransform}
        onOpenAudioIO={(id) => setAudioIOId(id)}
        onAddScene={addScene}
        onOpenBibleFinder={() => setBibleFinderOpen((v) => !v)}
        onOpenWorshipFinder={() => setWorshipFinderOpen((v) => !v)}
      />

      {bibleFinderOpen && (
        <BibleVersePopup
          armed={modelRef.current.bibleArmed}
          onClose={() => setBibleFinderOpen(false)}
          onPlace={(ref, text, sourceLabel, bg) => placeBibleVerse(ref, text, sourceLabel, bg)}
        />
      )}

      {worshipFinderOpen && (
        <WorshipFinderPopup
          onClose={() => setWorshipFinderOpen(false)}
          onPlace={(song, lyric, opts) => placeWorshipLine(song, lyric, opts)}
        />
      )}

      <StatusBar modelRef={modelRef} savedAt={savedAt} />

      {transformOpen && (
        <TransformDialog
          source={
            modelRef.current.scenes
              .find((s) => s.id === modelRef.current.previewId)
              ?.sources.find((s) => s.id === modelRef.current.selectedId) ?? null
          }
          onClose={() => setTransformOpen(false)}
          bump={bump}
        />
      )}

      {addPickerOpen && (
        <AddSourceMenu onPick={onPickSourceType} onClose={() => setAddPickerOpen(false)} />
      )}

      {propType && (
        <SourceProperties
          type={propType}
          existing={editingSource ?? undefined}
          participants={modelRef.current.zoom.participants.map((p) => ({ id: p.id, name: p.name }))}
          onCancel={() => { setPropType(null); setPropEditing(null); }}
          onConfirm={confirmProperties}
        />
      )}

      {settingsOpen && (
        <SettingsDialog modelRef={modelRef} bump={bump} onClose={() => setSettingsOpen(false)} />
      )}

      {zoomOpen && (
        <ZoomDialog
          initialUser={modelRef.current.zoom.user}
          initialMeeting={modelRef.current.zoom.meetingId}
          onJoin={joinMeeting}
          onClose={() => setZoomOpen(false)}
        />
      )}

      {confirmDeleteId && (
        <ConfirmDialog
          title="Remove Source"
          message={
            <>
              Delete source <span className="font-semibold text-white">
                {modelRef.current.scenes.find((s) => s.id === modelRef.current.previewId)?.sources.find((s) => s.id === confirmDeleteId)?.name ?? ""}
              </span> from the current scene? This cannot be undone.
            </>
          }
          confirmLabel="Delete"
          cancelLabel="Keep"
          onConfirm={() => { doDeleteSource(confirmDeleteId); setConfirmDeleteId(null); }}
          onCancel={() => setConfirmDeleteId(null)}
        />
      )}

      {confirmQuit && (
        <ConfirmDialog
          title="Exit StreamForge Studio"
          message="Are you sure you want to quit? Any active stream or recording will be stopped."
          confirmLabel="Exit"
          cancelLabel="Stay"
          onConfirm={() => { setConfirmQuit(false); doQuit(); }}
          onCancel={() => setConfirmQuit(false)}
        />
      )}

      {helpOpen && <HelpDialog onClose={() => setHelpOpen(false)} />}

      {audioIOId && (() => {
        const ch = modelRef.current.audio.find((c) => c.id === audioIOId);
        return ch ? (
          <AudioIODialog channel={ch} onSave={saveAudioIO} onClose={() => setAudioIOId(null)} />
        ) : null;
      })()}

      {boot && (
        <div
          onClick={() => setBoot(false)}
          className={`fixed inset-0 z-50 flex cursor-pointer flex-col items-center justify-center bg-[#1a1a1a] transition-opacity duration-300 ${
            bootFade ? "pointer-events-none opacity-0" : "opacity-100"
          }`}
        >
          <div className="text-[28px] font-semibold tracking-wide text-white">StreamForge Studio</div>
          <div className="mt-2 text-[12px] text-[#9a9a9a]">OBS-style broadcast console</div>
          <div className="mt-3 text-[11px] text-[#82aaff]">Developed by Richard Lanre Lukeman</div>
          <div className="mt-8 text-[11px] text-[#666]">Click to enter</div>
        </div>
      )}
    </div>
  );
}
