import { useState, type MutableRefObject } from "react";
import { CW, CH, clamp, SOURCE_META } from "../engine/types";
import { sfx } from "../engine/sfx";
import { assets } from "../engine/assets";

interface Props {
  modelRef: MutableRefObject<any>;
  bump: () => void;
  log: (msg: string, kind?: "info" | "ok" | "warn") => void;
  setPreview: (id: string) => void;
  onSelect: (id: string | null) => void;
}

/* Small inline icons */
function IconEye() { return <span>●</span>; }
function IconEyeOff() { return <span>○</span>; }
function IconTrash() { return <span>×</span>; }

/* Clean OBS-style source type icons */
const TypeDot: Record<string, string> = {
  "live-cam": "●",
  camera: "●",
  display: "■",
  browser: "◆",
  "image-file": "◌",
  "video-file": "▶",
  image: "◆",
  media: "▶",
  text: "T",
  color: "■",
  "zoom-grid": "◈",
  "zoom-guest": "◉",
};

export default function LeftColumn({ modelRef, bump, log, setPreview, onSelect }: Props) {
  const m = modelRef.current;
  const previewScene = m.scenes.find((s: any) => s.id === m.previewId)!;
  const selected = previewScene.sources.find((s: any) => s.id === m.selectedId) ?? null;
  const [addOpen, setAddOpen] = useState(false);

  /* Source actions */
  const addSource = (type: string) => {
    const sc = previewScene;
    const d: any = { "live-cam": { w: 848, h: 477, hue: 205 }, camera: { w: 800, h: 450, hue: 205 }, display: { w: 1280, h: 720, hue: 215 }, browser: { w: 900, h: 640, hue: 210 }, media: { w: 1024, h: 576, hue: 265 }, image: { w: 760, h: 500, hue: 20 }, "image-file": { w: 960, h: 540, hue: 200 }, "video-file": { w: 1280, h: 720, hue: 260 }, color: { w: 640, h: 360, hue: 0 }, text: { w: 720, h: 92, hue: 0 }, "zoom-grid": { w: 1120, h: 750, hue: 215 }, "zoom-guest": { w: 760, h: 500, hue: 158 } };
    const def = d[type] ?? d.camera;
    const off = (sc.sources.length % 5) * 40;
    const newS: any = {
      id: `src-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      name: `${SOURCE_META.find((x: any) => x.type === type)?.label || type} ${sc.sources.length + 1}`,
      type,
      x: Math.round((CW - def.w) / 2 + off),
      y: Math.round((CH - def.h) / 2 + off * 0.6),
      w: def.w, h: def.h, bw: def.w, bh: def.h,
      visible: true, hue: def.hue,
      seed: Math.floor(Math.random() * 10000),
      playing: type === "media" ? true : undefined,
      loop: type === "media" ? true : undefined,
      audioMuted: type === "media" ? true : undefined,
      audioVol: 100,
    };
    if (type === "text") newS.text = "NEW TEXT";
    if (type === "color") newS.color = "#223047";
    if (type === "zoom-guest") newS.participantId = m.zoom.participants[0]?.id;
    if (type === "browser") newS.url = "https://streamforge.app/live-dashboard";
    sc.sources.push(newS);
    m.selectedId = newS.id;
    setAddOpen(false);
    sfx.play("tick");
    bump();
  };

  const removeSelected = () => {
    const sc = previewScene;
    sc.sources = sc.sources.filter((s: any) => s.id !== m.selectedId);
    m.selectedId = null;
    sfx.play("select");
    bump();
  };

  const duplicateSelected = () => {
    const sc = previewScene;
    const s = sc.sources.find((x: any) => x.id === m.selectedId);
    if (!s) return;
    const cp = { ...s, id: `src-${Date.now()}-c`, name: s.name + " (copy)", x: s.x + 40, y: s.y + 30 };
    sc.sources.push(cp);
    m.selectedId = cp.id;
    sfx.play("tick");
    bump();
  };

  const togglePlaying = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!selected) return;
    selected.playing = selected.playing === false ? true : false;
    sfx.play("tick");
    bump();
  };
  const toggleLoop = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!selected) return;
    selected.loop = !selected.loop;
    sfx.play("tick");
    bump();
  };
  const toggleAudio = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!selected) return;
    selected.audioMuted = !selected.audioMuted;
    sfx.play(selected.audioMuted ? "select" : "tick");
    bump();
  };

  const setZoomPct = (pct: number) => {
    if (!selected) return;
    const cx = selected.x + selected.w / 2, cy = selected.y + selected.h / 2;
    const nw = clamp(Math.round((selected.bw * pct) / 100), 120, CW * 1.8);
    selected.w = nw;
    selected.h = Math.round((nw * selected.bh) / selected.bw);
    selected.x = Math.round(cx - selected.w / 2);
    selected.y = Math.round(cy - selected.h / 2);
    bump();
  };

  const moveUp = () => {
    const sc = previewScene;
    const i = sc.sources.findIndex((s: any) => s.id === m.selectedId);
    if (i > 0) { const tmp = sc.sources[i]; sc.sources[i] = sc.sources[i - 1]; sc.sources[i - 1] = tmp; bump(); }
  };
  const moveDown = () => {
    const sc = previewScene;
    const i = sc.sources.findIndex((s: any) => s.id === m.selectedId);
    if (i >= 0 && i < sc.sources.length - 1) { const tmp = sc.sources[i]; sc.sources[i] = sc.sources[i + 1]; sc.sources[i + 1] = tmp; bump(); }
  };

  const zoomPct = selected ? Math.round((selected.w / selected.bw) * 100) : 100;
  const isPlayer = selected?.type === "video-file" || selected?.type === "media";

  return (
    <div className="flex h-full flex-col gap-1 overflow-hidden">
      {/* === Scenes (OBS style) === */}
      <section className="flex-none rounded-md border border-ink-700 bg-ink-850">
        <header className="flex items-center justify-between border-b border-ink-700 px-2.5 py-1">
          <h2 className="panel-label text-[11px] tracking-[0.14em] text-fog-200">SCENES</h2>
          <button onClick={() => { const sc: any = { id: `sc-${Date.now()}`, name: "NEW SCENE", sources: [] }; m.scenes.push(sc); m.previewId = sc.id; sfx.play("tick"); bump(); }} className="btn rounded border border-ink-600 bg-ink-800 px-1.5 py-0.5 text-[9px] text-fog-300 hover:text-prv">+</button>
        </header>
        <div className="max-h-[72px] overflow-y-auto p-1">
          {m.scenes.map((sc: any) => (
            <button
              key={sc.id}
              onClick={() => setPreview(sc.id)}
              className={`btn mb-0.5 block w-full rounded border px-2 py-[3px] text-left ${m.previewId === sc.id ? "border-prv bg-prv-dim/30 text-prv shadow-[inset_2px_0_0_var(--color-prv)]" : "border-transparent text-fog-300 hover:bg-ink-800 hover:text-fog-100"}`}
            >
              <span className="font-mono text-[9px] text-fog-500">{m.previewId === sc.id ? "▶" : ""}</span>
              <span className="panel-label ml-1 text-[11px]">{sc.name}</span>
            </button>
          ))}
        </div>
      </section>

      {/* === Sources (OBS style — clean list) === */}
      <section className="flex-1 overflow-hidden rounded-md border border-ink-700 bg-ink-850">
        <header className="flex items-center justify-between border-b border-ink-700 px-2.5 py-1">
          <h2 className="panel-label text-[11px] tracking-[0.14em] text-fog-200">SOURCES</h2>
          <button onClick={() => setAddOpen((v: boolean) => !v)} className={`btn rounded border px-1.5 py-0.5 text-[9px] font-mono ${addOpen ? "border-prv bg-prv text-ink-950" : "border-ink-600 bg-ink-800 text-fog-300 hover:text-prv"}`}>
            + ADD SOURCE
          </button>
        </header>
        <div className="max-h-[128px] overflow-y-auto p-1">
          {previewScene.sources.length === 0 && (
            <p className="py-3 text-center font-mono text-[9px] text-fog-500">Empty — click + ADD SOURCE</p>
          )}
          {previewScene.sources.map((s: any) => (
            <button
              key={s.id}
              onClick={() => onSelect(s.id === m.selectedId ? null : s.id)}
              className={`mb-0.5 block w-full rounded border px-2 py-[3px] text-left ${m.selectedId === s.id ? "border-prv bg-prv-dim/25 shadow-[inset_2px_0_0_var(--color-prv)]" : "border-transparent hover:bg-ink-800 hover:text-fog-100"} ${!s.visible ? "opacity-45" : ""}`}
            >
              <div className="flex items-center gap-2">
                {/* visibility */}
                <button onClick={(e) => { e.stopPropagation(); s.visible = !s.visible; bump(); }} className="btn text-fog-400 hover:text-prv" aria-label="Toggle visibility">
                  {s.visible ? <IconEye /> : <IconEyeOff />}
                </button>
                {/* source name */}
                <span className="flex-1 truncate text-[11px] text-fog-200">{s.name}</span>
                {/* remove */}
                <button onClick={(e) => { e.stopPropagation(); sfx.play("select"); onSelect(null); previewScene.sources = previewScene.sources.filter((x: any) => x.id !== s.id); if (s.assetId) assets.remove(s.assetId); log(`Source removed — ${s.name}`, "info"); bump(); }} className="btn text-fog-500 hover:text-prg" aria-label="Remove source" title="Remove source">
                  <IconTrash />
                </button>
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* === Clean OBS-style source menu dropdown === */}
      {addOpen && (
        <div className="fixed inset-0 z-50 flex items-start justify-center bg-black/50 pt-[140px]" onClick={() => setAddOpen(false)}>
          <div onClick={(e) => e.stopPropagation()} className="w-[320px] overflow-hidden rounded-lg border border-ink-600 bg-ink-850 shadow-2xl">
            <div className="border-b border-ink-700 px-3 py-2">
              <h3 className="panel-label text-[13px] font-semibold tracking-[0.14em] text-fog-100">Add Source</h3>
              <p className="font-mono text-[9px] text-fog-500">Click any item — routes to current Preview scene</p>
            </div>
            <div className="max-h-[320px] overflow-y-auto p-1">
              {[
                { label: "Live Camera", type: "live-cam", desc: "Webcam via LIVE I/O" },
                { label: "Camera", type: "camera", desc: "Studio simulation" },
                { label: "Display Capture", type: "display", desc: "Screen / region" },
                { label: "Browser Source", type: "browser", desc: "Web URL" },
                { label: "Picture File", type: "image-file", desc: "JPG / PNG / WebP" },
                { label: "Video File", type: "video-file", desc: "MP4 / WebM / MOV" },
                { label: "Image", type: "image", desc: "Generated artwork" },
                { label: "Text / GFX", type: "text", desc: "Title / lower-third" },
                { label: "Color Fill", type: "color", desc: "Backdrop / solid" },
                { label: "Zoom Grid", type: "zoom-grid", desc: "Meeting gallery" },
                { label: "Zoom Guest", type: "zoom-guest", desc: "Single participant" },
              ].map((src) => (
                <button
                  key={src.label}
                  onClick={() => {
                    addSource(src.type as any);
                  }}
                  className="btn flex w-full items-center gap-3 rounded-md border border-transparent px-2.5 py-[7px] text-left hover:border-ink-600 hover:bg-ink-800"
                >
                  <span className="flex h-7 w-7 flex-none items-center justify-center rounded-md bg-ink-900 text-[11px] text-fog-300 border border-ink-600">{TypeDot[src.type as any] || "●"}</span>
                  <div>
                    <div className="text-[12px] font-medium text-fog-200">{src.label}</div>
                    <div className="font-mono text-[9px] text-fog-500">{src.desc}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* === Source Settings (only when selected) === */}
      {selected && (
        <div className="flex-none rounded-md border border-ink-700 bg-ink-850 p-2.5">
          <div className="mb-2 flex items-center gap-2">
            <span className="text-[12px] font-medium text-fog-200">{selected.name}</span>
            <button onClick={duplicateSelected} title="Duplicate" className="btn rounded border border-ink-600 bg-ink-800 px-1.5 py-0.5 text-[10px] text-fog-400 hover:text-amber-400">⧉</button>
            <button onClick={moveUp} title="Move up" className="btn rounded border border-ink-600 bg-ink-800 px-1.5 py-0.5 text-[10px] text-fog-400 hover:text-amber-400">▲</button>
            <button onClick={moveDown} title="Move down" className="btn rounded border border-ink-600 bg-ink-800 px-1.5 py-0.5 text-[10px] text-fog-400 hover:text-amber-400">▼</button>
            <button onClick={removeSelected} title="Remove" className="btn rounded border border-prg/40 bg-prg/15 px-1.5 py-0.5 text-[10px] text-prg hover:bg-prg hover:text-white">×</button>
          </div>

          {/* position */}
          <div className="mb-2 grid grid-cols-4 gap-1.5">
            {(["x","y","w","h"] as const).map((k) => (
              <label key={k} className="block">
                <span className="panel-label mb-0.5 block text-[9px] text-fog-500">{k.toUpperCase()}</span>
                <input type="number" className="w-full rounded border border-ink-600 bg-ink-900 px-1.5 py-1 text-[10px] text-fog-200 focus:border-prv focus:outline-none font-mono" value={Math.round(selected[k])} onChange={(e) => { const v = Number(e.target.value) || 0; if (k === "w" || k === "h") { const r = selected.bw / selected.bh; selected[k === "w" ? "w" : "h"] = v; if (k === "w") selected.h = Math.round(v / r); else selected.w = Math.round(v * r); } else { (selected as any)[k] = v; } bump(); }} />
              </label>
            ))}
          </div>

          {/* zoom slider stacked */}
          <div className="mb-1.5 flex items-center gap-2">
            <span className="w-10 text-[9px] font-mono text-fog-400">ZOOM</span>
            <input
              type="range"
              min={25}
              max={250}
              value={clamp(zoomPct, 25, 250)}
              onChange={(e) => setZoomPct(Number(e.target.value))}
              className="h-1.5 flex-1 cursor-pointer appearance-none rounded-full bg-ink-700 accent-emerald-400"
            />
            <span className="w-8 text-right font-mono text-[10px] text-emerald-400">{zoomPct}%</span>
          </div>

          {/* Action row based on source type */}
          <div className="mt-2 flex gap-1.5">
            <button onClick={() => { const cx = selected.x + selected.w / 2, cy = selected.y + selected.h / 2; selected.x = Math.round(cx - selected.bw / 2); selected.y = Math.round(cy - selected.bh / 2); selected.w = selected.bw; selected.h = selected.bh; bump(); }} className="btn flex-1 rounded border border-ink-600 bg-ink-750 py-1 text-[10px] text-fog-300 hover:text-amber-400">Reset 100%</button>
            {isPlayer && (
              <button onClick={togglePlaying} className="btn rounded border border-ink-600 bg-ink-750 px-2 py-1 text-[10px] text-fog-300 hover:text-amber-400">
                {selected.playing !== false ? "⏸ Pause" : "▶ Play"}
              </button>
            )}
            {isPlayer && (
              <button onClick={toggleLoop} className={`btn rounded border border-ink-600 px-2 py-1 text-[10px] ${selected.loop ? "text-amber-400 bg-amber-950/30" : "text-fog-300 hover:text-amber-400"}`}>
                {selected.loop ? "⟳ Loop ON" : "⟳ Loop"}
              </button>
            )}
            {isPlayer && (
              <button onClick={toggleAudio} className={`btn rounded border border-ink-600 px-2 py-1 text-[10px] ${selected.audioMuted ? "text-red-400 bg-red-950/25" : "text-emerald-400 bg-emerald-950/25"}`}>
                {selected.audioMuted ? "🔇 Mute ON" : "🔊 Audio"}
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}