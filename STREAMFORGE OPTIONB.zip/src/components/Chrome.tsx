import { useEffect, useRef, useState, type MutableRefObject } from "react";
import { Volume2, VolumeX } from "lucide-react";
import { destLabel, encLabel, type SourceType, type StudioModel } from "../engine/types";
import { sfx } from "../engine/sfx";

/* --------------------------------- top bar --------------------------------- */

interface TopProps {
  modelRef: MutableRefObject<StudioModel>;
  bump: () => void;
  log: (msg: string, kind?: "info" | "ok" | "warn") => void;
  onResetLayout: () => void;
  onSaveNow: () => void;
  onImportFile: (file: File) => void;
  onExit: () => void;
  onNetwork: (type: SourceType) => void;
  onHelp: () => void;
  bibleListening: boolean;
  onToggleBibleListen: () => void;
  onBibleDownload: (ver?: string) => void;
  onBibleClear: () => void;
  bibleInfo: string;
}

const PKG_LINES = [
  "npm create tauri-app@latest streamforge -- --template react-ts",
  "cd streamforge && npm i && npm i -D tailwindcss @tailwindcss/vite",
  "npm run tauri dev      # launches the Windows desktop shell",
  "npm run tauri build    # produces the .msi installer",
];

function Clock() {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const iv = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(iv);
  }, []);
  return (
    <span className="font-mono text-[11px] tracking-wider text-fog-300">
      {now.toLocaleTimeString([], { hour12: false })}
    </span>
  );
}

export function TopBar({ modelRef, bump, log, onResetLayout, onSaveNow, onImportFile, onExit, onNetwork, onHelp, bibleListening, onToggleBibleListen, onBibleDownload, onBibleClear, bibleInfo }: TopProps) {
  const m = modelRef.current;
  const [menu, setMenu] = useState<null | "file" | "view" | "network" | "bible" | "help">(null);
  const [pkgOpen, setPkgOpen] = useState(false);
  const [copied, setCopied] = useState<number | null>(null);
  const fileRef = useRef<HTMLInputElement | null>(null);

  const item = "btn block w-full rounded px-3 py-1.5 text-left text-[11px] text-fog-200 hover:bg-ink-700";

  const exportScenes = () => {
    try {
      const data = JSON.stringify(
        {
          app: "StreamForge Studio",
          version: "4.8",
          exportedAt: new Date().toISOString(),
          scenes: modelRef.current.scenes,
        },
        null,
        2,
      );
      const url = URL.createObjectURL(new Blob([data], { type: "application/json" }));
      const a = document.createElement("a");
      a.href = url;
      a.download = "streamforge-scenes.json";
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      sfx.play("chime");
      log("Scene collection exported → streamforge-scenes.json", "ok");
    } catch {
      log("Export failed — browser blocked the download", "warn");
    }
  };

  const copyLine = (i: number) => {
    const done = () => {
      setCopied(i);
      sfx.play("tick");
      setTimeout(() => setCopied((c) => (c === i ? null : c)), 1200);
    };
    try {
      void navigator.clipboard?.writeText(PKG_LINES[i]).then(done).catch(done);
    } catch {
      done();
    }
  };

  return (
    <header className="relative z-40 flex h-8 flex-none items-center gap-3 border-b border-[#1a1a1a] bg-[#2b2b2b] px-3 text-[12px]">
      {/* brand */}
      <div className="flex items-center gap-2.5">
        <svg width="22" height="22" viewBox="0 0 24 24" aria-hidden>
          <path d="M3 3h18v18H3z" fill="#131720" />
          <path d="M3 3h18L3 21z" fill="#2fd273" opacity="0.9" />
          <path d="M21 3v18H3z" fill="#ff4438" opacity="0.85" />
          <path d="M10 8.5l6 3.5-6 3.5z" fill="#e9edf3" />
        </svg>
        <div className="leading-none">
          <div className="panel-label text-[16px] font-bold tracking-[0.18em] text-fog-100">
            STREAM<span className="text-prv">FORGE</span>
          </div>
          <div className="font-mono text-[8px] tracking-[0.28em] text-fog-500">STUDIO 4.8 • LL-BUILD</div>
        </div>
      </div>

      {/* menus */}
      <nav className="ml-4 flex items-center gap-1">
        {(["file", "view", "network", "bible", "help"] as const).map((k) => (
          <div key={k} className="relative">
            <button
              onClick={() => setMenu(menu === k ? null : k)}
              className={`btn panel-label rounded px-2.5 py-1 text-[11px] capitalize ${
                menu === k ? "bg-ink-700 text-fog-100" : "text-fog-400 hover:bg-ink-800 hover:text-fog-200"
              }`}
            >
              {k}
            </button>
            {menu === k && (
              <div className="anim-rise absolute left-0 top-8 w-56 rounded-md border border-ink-600 bg-ink-800 p-1 shadow-2xl">
                {k === "file" && (
                  <>
                    <button className={item} onClick={() => { onSaveNow(); setMenu(null); }}>Save layout now</button>
                    <button className={item} onClick={() => { exportScenes(); setMenu(null); }}>Export scene collection…</button>
                    <button className={item} onClick={() => { setMenu(null); fileRef.current?.click(); }}>Import scene collection…</button>
                    <button className={item} onClick={() => { onResetLayout(); setMenu(null); }}>Reset layout to default</button>
                    <div className="my-1 border-t border-ink-700" />
                    <button className={item} onClick={() => { setPkgOpen(true); setMenu(null); }}>Package as desktop app (Tauri)…</button>
                    <div className="my-1 border-t border-ink-700" />
                    <button className={item} onClick={() => { setMenu(null); onExit(); }}>Exit StreamForge Studio</button>
                  </>
                )}
                {k === "view" && (
                  <>
                    <button className={item} onClick={() => { m.safeAreas = !m.safeAreas; bump(); }}>
                      <span className={m.safeAreas ? "text-prv" : "text-fog-500"}>{m.safeAreas ? "✓" : "○"}</span>{"  "}Safe areas / rule of thirds
                    </button>
                  </>
                )}
                {k === "network" && (
                  <>
                    <div className="px-3 py-1 text-[9px] uppercase tracking-widest text-fog-500">Network inputs (auto-create scene)</div>
                    <button className={item} onClick={() => { setMenu(null); onNetwork("srt-listener"); }}>SRT Listener…</button>
                    <button className={item} onClick={() => { setMenu(null); onNetwork("srt-caller"); }}>SRT Caller…</button>
                    <div className="my-1 border-t border-ink-700" />
                    <button className={item} onClick={() => { setMenu(null); onNetwork("webrtc"); }}>WebRTC Input…</button>
                    <div className="my-1 border-t border-ink-700" />
                    <button className={item} onClick={() => { setMenu(null); onNetwork("rtmp"); }}>RTMP Server…</button>
                  </>
                )}
                {k === "bible" && (
                  <>
                    <button className={item} onClick={() => { onToggleBibleListen(); setMenu(null); }}>
                      <span className={bibleListening ? "text-prv" : "text-fog-500"}>{bibleListening ? "●" : "○"}</span>{"  "}
                      {bibleListening ? "Stop Live Verse Listening" : "Start Live Verse Listening"}
                    </button>
                    <div className="my-1 border-t border-ink-700" />
                    <div className="px-3 py-1 text-[9px] uppercase tracking-widest text-fog-500">Download for offline</div>
                    {[
                      { v: "kjv", label: "KJV", desc: "King James Version" },
                      { v: "niv", label: "NIV", desc: "New International Version" },
                      { v: "msg", label: "Message", desc: "The Message (Paraphrase)" },
                      { v: "goodnews", label: "Good News", desc: "Good News Translation" },
                      { v: "amp", label: "AMP", desc: "Amplified Bible" },
                    ].map((bv) => (
                      <button key={bv.v} className={item} onClick={() => { setMenu(null); onBibleDownload(bv.v); }}>
                        {bv.label} — {bv.desc}
                      </button>
                    ))}
                    <div className="my-1 border-t border-ink-700" />
                    <button className={item} onClick={() => { setMenu(null); onBibleClear(); }}>Clear offline Bible data</button>
                    <div className="px-3 py-1.5 text-[9px] leading-relaxed text-fog-500">{bibleInfo}</div>
                  </>
                )}
                {k === "help" && (
                  <>
                    <button className={item} onClick={() => { setMenu(null); onHelp(); }}>User Guide, Standalone .exe & Setup…</button>
                    <div className="px-3 py-1.5 text-[9px] text-[#2fd273] font-medium">[Richard Lukeman | +2347030518468] designed this software for churches. Send a DM.</div>
                  </>
                )}
              </div>
            )}
          </div>
        ))}
      </nav>

      {menu && <div className="fixed inset-0 z-[-1]" onClick={() => setMenu(null)} />}

      <input
        ref={fileRef}
        type="file"
        accept="application/json,.json"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) onImportFile(f);
          e.target.value = "";
        }}
      />

      {/* on-air lamp */}
      <div className="mx-auto flex items-center gap-3">
        <div
          className={`panel-label flex items-center gap-2 rounded-md border px-3 py-0.5 text-[12px] font-bold tracking-[0.2em] transition-all duration-300 ${
            m.live
              ? "anim-lamp border-prg bg-prg-dim/60 text-prg shadow-[0_0_24px_rgba(255,68,56,0.45)]"
              : "border-ink-600 bg-ink-800 text-fog-500"
          }`}
        >
          <span className={`h-2 w-2 rounded-full ${m.live ? "anim-rec bg-prg" : "bg-ink-600"}`} />
          {m.live ? "ON AIR" : "STANDBY"}
        </div>
        <span className="hidden rounded border border-[#2a3a2a] bg-[#101e16] px-2.5 py-0.5 font-sans text-[10px] font-medium text-[#2fd273] 2xl:inline-block">
          [Richard Lukeman | +2347030518468] designed this software for churches. Send a DM.
        </span>
      </div>

      {/* system */}
      <div className="flex items-center gap-4">
        <button
          onClick={() => {
            m.sound = !m.sound;
            sfx.setEnabled(m.sound);
            if (m.sound) sfx.play("tick");
            bump();
          }}
          title={m.sound ? "Mute console audio" : "Unmute console audio"}
          className={`btn rounded-md border p-1.5 ${
            m.sound ? "border-ink-600 bg-ink-800 text-prv" : "border-prg/50 bg-prg-dim/30 text-prg"
          }`}
        >
          {m.sound ? <Volume2 className="h-3.5 w-3.5" /> : <VolumeX className="h-3.5 w-3.5" />}
        </button>
        {[
          ["CPU", m.metrics.cpu],
          ["GPU", m.metrics.gpu],
        ].map(([label, v]) => (
          <div key={label as string} className="flex items-center gap-1.5">
            <span className="font-mono text-[9px] text-fog-500">{label as string}</span>
            <div className="h-1.5 w-14 overflow-hidden rounded-full bg-ink-700">
              <div
                className="h-full rounded-full transition-all duration-500"
                style={{ width: `${v}%`, background: (v as number) > 70 ? "#ff4438" : (v as number) > 45 ? "#ffb020" : "#2fd273" }}
              />
            </div>
            <span className="w-7 font-mono text-[9px] text-fog-400">{v}%</span>
          </div>
        ))}
        <Clock />
      </div>

      {/* desktop packaging dialog */}
      {pkgOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-6" onClick={() => setPkgOpen(false)}>
          <div
            className="anim-rise w-[560px] rounded-lg border border-ink-600 bg-ink-850 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-ink-700 px-4 py-3">
              <div>
                <h3 className="panel-label text-[15px] font-semibold text-fog-100">Windows Desktop Build</h3>
                <p className="font-mono text-[9px] text-fog-500">This web console packages 1:1 via Tauri — native window, tray + hotkeys</p>
              </div>
              <button onClick={() => setPkgOpen(false)} className="btn rounded border border-ink-600 bg-ink-750 px-2 py-1 font-mono text-[10px] text-fog-300 hover:text-prg">
                ESC
              </button>
            </div>
            <div className="space-y-1.5 p-4">
              {PKG_LINES.map((line, i) => (
                <div key={line} className="group flex items-center gap-2 rounded-md border border-ink-700 bg-ink-950 px-3 py-2">
                  <span className="font-mono text-[9px] text-fog-500">{i + 1}</span>
                  <code className="min-w-0 flex-1 truncate font-mono text-[10.5px] text-fog-200">{line}</code>
                  <button
                    onClick={() => copyLine(i)}
                    className={`btn panel-label flex-none rounded border px-2 py-0.5 text-[9px] ${
                      copied === i
                        ? "border-prv bg-prv text-ink-950"
                        : "border-ink-600 bg-ink-750 text-fog-300 opacity-60 hover:border-prv hover:text-prv group-hover:opacity-100"
                    }`}
                  >
                    {copied === i ? "COPIED" : "COPY"}
                  </button>
                </div>
              ))}
              <p className="pt-1 font-mono text-[9px] leading-relaxed text-fog-500">
                The installer lands in <span className="text-fog-300">src-tauri/target/release/bundle/msi</span>. GPU compositing,
                LL-WEBRTC and the Zoom bridge run identically inside the native shell.
              </p>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}

/* -------------------------------- status bar -------------------------------- */

export function StatusBar({ modelRef, savedAt }: { modelRef: MutableRefObject<StudioModel>; savedAt: Date | null }) {
  const m = modelRef.current;
  const mt = m.metrics;
  return (
    <footer className="flex h-6 flex-none items-center gap-4 border-t border-[#1a1a1a] bg-[#1f1f1f] px-3 font-mono text-[10px] text-[#9a9a9a]">
      <span className="flex items-center gap-1.5">
        <i className={`h-1.5 w-1.5 rounded-full ${m.live ? "anim-rec bg-prg" : "bg-prv"}`} />
        {m.live ? "STREAMING" : m.recording ? "RECORDING" : "PIPELINE READY"}
      </span>
      <span>{m.outputRes}</span>
      <span className={mt.fps < 55 ? "text-amb" : "text-prv"}>{mt.fps} FPS</span>
      <span>{mt.frameMs.toFixed(1)}ms FRAME</span>
      <span className="text-prv">{mt.latency}ms E2E LATENCY</span>
      <span>{mt.dropped} DROPPED</span>
      <span className="hidden lg:inline">{encLabel(m.encoder)} • CBR {(mt.bitrate / 1000).toFixed(1)}M</span>
      {m.live && <span className="hidden text-prg md:inline">{destLabel(m.dest).toUpperCase()} UPLINK</span>}
      <span className="hidden text-fog-500 lg:inline" title="Layout autosaves to this browser">
        AUTOSAVE {savedAt ? savedAt.toLocaleTimeString([], { hour12: false }) : "—"}
      </span>

      <span className="ml-auto flex items-center gap-2">
        <span className="rounded border border-[#303a4b] bg-[#2a2b2f] px-2 py-0.5 font-sans text-[10px] font-medium text-[#2fd273]">
          [Richard Lukeman | +2347030518468] designed this software for churches. Send a DM.
        </span>
      </span>

      <span className="hidden items-center gap-2.5 xl:flex">
        {[["C", "CUT"], ["A", "AUTO"], ["F", "FTB"], ["L", "LIVE"], ["R", "REC"], ["1–6", "SCENES"]].map(([k, label]) => (
          <span key={k} className="flex items-center gap-1">
            <kbd className="hint">{k}</kbd>
            <span className="text-[9px] tracking-wider text-fog-500">{label}</span>
          </span>
        ))}
      </span>
    </footer>
  );
}
