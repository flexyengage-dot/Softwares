import { useEffect, useRef, useState, type MutableRefObject, type PointerEvent as RPtr } from "react";
import { type StudioModel, type TransitionKind } from "../engine/types";
import { sfx } from "../engine/sfx";

const KINDS: { v: TransitionKind; label: string }[] = [
  { v: "cut", label: "CUT" },
  { v: "fade", label: "FADE" },
  { v: "wipe", label: "WIPE" },
  { v: "zoom", label: "ZOOM" },
  { v: "dip", label: "DIP" },
];

const DURATIONS = [150, 300, 500, 800, 1200, 2000];

interface RailProps {
  modelRef: MutableRefObject<StudioModel>;
  getT: () => number;
  setTbar: (v: number) => void;
  releaseTbar: () => void;
  auto: () => void;
  cut: () => void;
  ftbToggle: () => void;
  onModelChange: () => void;
}

/* ------------------------- vertical T-bar (fader-style) ------------------------- */

function VerticalTBar({ value, onChange, onRelease }: {
  value: number;
  onChange: (v: number) => void;
  onRelease: () => void;
}) {
  const trackRef = useRef<HTMLDivElement | null>(null);
  const dragging = useRef(false);

  const fromPointer = (clientY: number) => {
    const t = trackRef.current;
    if (!t) return;
    const r = t.getBoundingClientRect();
    onChange(Math.min(1, Math.max(0, (clientY - r.top) / r.height)));
  };

  return (
    <div
      ref={trackRef}
      onPointerDown={(e: RPtr<HTMLDivElement>) => {
        dragging.current = true;
        (e.target as HTMLElement).setPointerCapture(e.pointerId);
        fromPointer(e.clientY);
      }}
      onPointerMove={(e: RPtr<HTMLDivElement>) => {
        if (dragging.current) fromPointer(e.clientY);
      }}
      onPointerUp={() => {
        if (dragging.current) {
          dragging.current = false;
          onRelease();
        }
      }}
      onPointerCancel={() => {
        dragging.current = false;
        onRelease();
      }}
      className="relative my-1.5 w-7 min-h-0 flex-1 cursor-ns-resize touch-none rounded-md border border-ink-600"
      style={{
        background:
          "linear-gradient(180deg, var(--color-prv-dim), var(--color-ink-800) 30%, var(--color-ink-800) 70%, var(--color-prg-dim))",
      }}
      aria-label="Transition bar"
    >
      <div
        className="absolute left-1/2 h-[22px] w-9 -translate-x-1/2 rounded-[4px] border border-ink-600 shadow-[0_2px_8px_rgba(0,0,0,0.55)]"
        style={{
          top: `calc(${value * 100}% - 11px)`,
          background:
            "repeating-linear-gradient(0deg,#4a5568 0 1px,transparent 1px 4px) center / 14px 12px no-repeat, linear-gradient(90deg,#3a4557,#242b39)",
        }}
      />
    </div>
  );
}

/* --------------------- vertical transition tower (PRV | PGM) --------------------- */

export function TransitionRail(p: RailProps) {
  const m = p.modelRef.current;
  const [tbar, setTbarUi] = useState(0);

  useEffect(() => {
    const iv = setInterval(() => setTbarUi(Math.round(p.getT() * 1000)), 70);
    return () => clearInterval(iv);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="flex min-h-0 flex-1 flex-col rounded-lg border border-ink-700 bg-ink-850">
      <div className="panel-label border-b border-ink-700 px-2 py-1.5 text-center text-[11px] text-fog-400">
        Transition
      </div>

      {/* stacked transition tabs */}
      <div className="flex flex-col gap-1 p-1.5">
        {KINDS.map((k) => (
          <button
            key={k.v}
            onClick={() => {
              m.transKind = k.v;
              sfx.play("tick");
              p.onModelChange();
            }}
            className={`btn panel-label rounded border py-[5px] text-[10px] font-semibold tracking-[0.14em] ${
              m.transKind === k.v
                ? "border-amb bg-amb/20 text-amb shadow-[0_0_12px_rgba(255,176,32,0.2)]"
                : "border-ink-600 bg-ink-800 text-fog-400 hover:border-amb/50 hover:text-amb"
            }`}
          >
            {k.label}
          </button>
        ))}
        <select
          className="sel mt-0.5 w-full"
          value={m.transDur}
          onChange={(e) => {
            m.transDur = Number(e.target.value);
            sfx.play("tick");
            p.onModelChange();
          }}
        >
          {DURATIONS.map((d) => (
            <option key={d} value={d}>{d}ms</option>
          ))}
        </select>
      </div>

      {/* vertical T-bar */}
      <div className="flex min-h-0 flex-1 flex-col items-center px-2.5">
        <span className="panel-label text-[9px] text-prv">PRV</span>
        <VerticalTBar
          value={tbar / 1000}
          onChange={(v) => {
            setTbarUi(Math.round(v * 1000));
            p.setTbar(v);
          }}
          onRelease={p.releaseTbar}
        />
        <span className="panel-label text-[9px] text-prg">PGM</span>
      </div>

      {/* stacked transport */}
      <div className="flex flex-col gap-1.5 p-2">
        <button
          onClick={p.auto}
          className="btn panel-label rounded-md border border-amb/50 bg-amb/15 py-2 text-[13px] font-semibold text-amb hover:bg-amb/25 hover:shadow-[0_0_16px_rgba(255,176,32,0.25)]"
        >
          Auto
        </button>
        <button
          onClick={p.cut}
          className="btn panel-label rounded-md border border-ink-600 bg-ink-750 py-2 text-[13px] font-semibold text-fog-200 hover:bg-ink-700"
        >
          Cut
        </button>
        <button
          onClick={p.ftbToggle}
          className={`btn panel-label rounded-md border py-2 text-[13px] font-semibold ${
            m.ftb.target === 1
              ? "border-amb bg-amb text-ink-950 shadow-[0_0_18px_rgba(255,176,32,0.4)]"
              : "border-ink-600 bg-ink-900 text-fog-300 hover:border-amb/60 hover:text-amb"
          }`}
        >
          FTB
        </button>
      </div>
    </div>
  );
}

/* ------------------------- stacked drop-down multiview ------------------------- */

interface MvProps {
  modelRef: MutableRefObject<StudioModel>;
  registerThumb: (id: string, el: HTMLCanvasElement | null) => void;
  setPreview: (id: string) => void;
  onModelChange: () => void;
}

export function MultiViewBar({ modelRef, registerThumb, setPreview, onModelChange }: MvProps) {
  const m = modelRef.current;
  const open = m.showMultiview;

  return (
    <div className="mt-2.5 flex-none rounded-lg border border-ink-700 bg-ink-850">
      <button
        onClick={() => {
          m.showMultiview = !m.showMultiview;
          sfx.play("tick");
          onModelChange();
        }}
        className="btn flex w-full items-center justify-between px-3 py-2"
      >
        <span className="panel-label text-[12px] text-fog-400">
          Multiview <span className="text-[10px] text-fog-500">— {m.scenes.length} scene buses</span>
        </span>
        <span className="flex items-center gap-3">
          <span className="flex items-center gap-3 font-mono text-[9px] tracking-wider text-fog-400">
            <span className="flex items-center gap-1"><i className="h-1.5 w-1.5 rounded-full bg-prv" /> PRV</span>
            <span className="flex items-center gap-1"><i className="h-1.5 w-1.5 rounded-full bg-prg" /> PGM</span>
          </span>
          <svg
            width="12"
            height="12"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.4"
            strokeLinecap="round"
            className={`text-fog-400 transition-transform duration-200 ${open ? "rotate-180" : ""}`}
          >
            <path d="M6 9l6 6 6-6" />
          </svg>
        </span>
      </button>

      {open && (
        <div className="anim-rise grid max-h-[228px] grid-cols-2 gap-1.5 overflow-y-auto border-t border-ink-700 p-2">
          {m.scenes.map((sc, i) => {
            const isPv = m.previewId === sc.id;
            const isPg = m.programId === sc.id;
            return (
              <button
                key={sc.id}
                onClick={() => setPreview(sc.id)}
                className={`btn group flex items-center gap-2.5 rounded-md border p-1.5 text-left transition ${
                  isPg
                    ? "border-prg bg-prg-dim/25 shadow-[0_0_14px_rgba(255,68,56,0.2)]"
                    : isPv
                      ? "border-prv bg-prv-dim/25 shadow-[0_0_14px_rgba(47,210,115,0.16)]"
                      : "border-ink-600 bg-ink-900/60 hover:border-fog-500"
                }`}
              >
                <span className="relative block w-32 flex-none overflow-hidden rounded-sm border border-ink-600">
                  <canvas
                    ref={(el) => registerThumb(sc.id, el)}
                    width={216}
                    height={122}
                    className="block aspect-video w-full bg-black"
                  />
                  <span className="absolute left-1 top-1 rounded-sm bg-black/65 px-1.5 py-px font-mono text-[9px] text-fog-200">
                    {i + 1}
                  </span>
                </span>
                <span className="min-w-0 flex-1">
                  <span className={`panel-label block truncate text-[13px] ${isPg ? "text-prg" : isPv ? "text-prv" : "text-fog-200"}`}>
                    {sc.name}
                  </span>
                  <span className="block font-mono text-[9px] text-fog-500">{sc.sources.length} inputs</span>
                  <span className="mt-1 flex gap-1">
                    {isPv && <span className="panel-label rounded-sm bg-prv px-1.5 text-[8px] font-semibold text-ink-950">PRV</span>}
                    {isPg && <span className="panel-label rounded-sm bg-prg px-1.5 text-[8px] font-semibold text-white">PGM</span>}
                    {!isPv && !isPg && <span className="panel-label rounded-sm bg-ink-700 px-1.5 text-[8px] text-fog-400">STBY</span>}
                  </span>
                </span>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
