import { useState } from "react";
import { BookOpen, Info, Package, HardDrive, MousePointerClick, PhoneCall, Code } from "lucide-react";

interface Props {
  onClose: () => void;
}

const TABS = [
  { v: "guide", label: "User Guide", icon: BookOpen },
  { v: "standalone", label: "Desktop & Portable (.exe)", icon: Package },
  { v: "about", label: "About & Developer", icon: Info },
] as const;

const GUIDE: { title: string; lines: string[] }[] = [
  {
    title: "Getting Started with StreamForge Studio",
    lines: [
      "Add a Scene from the Scenes panel (+), then add Sources (+) into it.",
      "The left monitor is Preview; the right is Program (what the audience sees live).",
      "Use Cut / Fade (or the vertical T-bar) in the center to send Preview to Program.",
    ],
  },
  {
    title: "Scenes & Sources",
    lines: [
      "Every input — USB Camera, Network IP Cam, Media File, Browser, NDI, Titles, Zoom — is a Source.",
      "Click + in Sources, pick a type, configure its properties, then press OK.",
      "Right-click a source for quick actions; double-click for full properties or crop/zoom.",
    ],
  },
  {
    title: "Going Live & Recording",
    lines: [
      "Set your stream service and key under File ▸ Settings ▸ Stream.",
      "Press Start Streaming in the Controls panel (turns red when on air).",
      "Start Recording writes directly to your chosen folder and format (MKV, MP4, MOV).",
    ],
  },
  {
    title: "Network Inputs (SRT / WebRTC / RTMP / NDI)",
    lines: [
      "Open the Network menu on the top bar to add SRT Listener, SRT Caller, WebRTC, or RTMP sources.",
      "Each network input automatically creates its own dedicated Scene and Source on init.",
      "Configure address, port, and passphrase in the properties dialog.",
    ],
  },
  {
    title: "Zoom Room & Remote Guests",
    lines: [
      "Press Connect Zoom in Controls and enter your meeting details.",
      "A dedicated, live meeting window opens with camera, microphone, and screen share controls.",
      "Select whether participants route to Preview or Program in the Zoom panel.",
    ],
  },
  {
    title: "Praise & Worship & Scripture",
    lines: [
      "Use Praise & Worship search to find songs by title, artist, or lyrics line.",
      "Open Verse Finder (Bible menu) for instant offline KJV scripture lookup with verse stepping.",
      "Enable Live Verse Listening for automatic speech-to-scripture lower thirds during sermon capture.",
    ],
  },
];

export default function HelpDialog({ onClose }: Props) {
  const [tab, setTab] = useState<(typeof TABS)[number]["v"]>("guide");

  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center bg-black/60 p-4"
      onClick={onClose}
      onContextMenu={(e) => e.preventDefault()}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="flex h-[600px] w-[780px] flex-col overflow-hidden rounded-lg border border-[#111] bg-[#252525] shadow-2xl"
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#1a1a1a] bg-[#2b2b2b] px-4 py-2.5">
          <div className="flex items-center gap-3">
            <div className="text-[14px] font-semibold text-[#f0f0f0]">
              StreamForge Studio — Help & Documentation
            </div>
            <span className="rounded border border-[#303a4b] bg-[#1a2332] px-2 py-0.5 text-[10px] font-medium text-[#2fd273]">
              [Richard Lukeman | +2347030518468] designed this software for churches. Send a DM.
            </span>
          </div>
          <button
            onClick={onClose}
            className="rounded border border-[#111] bg-[#3a3a3a] px-2.5 py-0.5 text-[11px] text-[#c8c8c8] hover:bg-[#4a4a4a]"
          >
            Close
          </button>
        </div>

        {/* Body with Sidebar */}
        <div className="flex min-h-0 flex-1">
          {/* Sidebar Tabs */}
          <div className="w-[180px] flex-none border-r border-[#1a1a1a] bg-[#1f1f1f] py-2">
            {TABS.map((t) => (
              <button
                key={t.v}
                onClick={() => setTab(t.v)}
                className={`flex w-full items-center gap-2 px-3.5 py-2.5 text-left text-[12px] font-medium transition-colors ${
                  tab === t.v
                    ? "border-l-2 border-[#3d6ea8] bg-[#3d6ea8]/20 text-white"
                    : "text-[#d0d0d0] hover:bg-[#2a2a2a]"
                }`}
              >
                <t.icon className="h-4 w-4 flex-none text-[#3d6ea8]" />
                {t.label}
              </button>
            ))}

            <div className="mx-3 my-4 border-t border-[#2a2a2a]" />

            <div className="px-3.5 py-1 text-[10px] leading-relaxed text-[#8a8a8a]">
              <div className="font-semibold text-[#b8b8b8]">Developer Contact:</div>
              <div className="mt-1 text-[#2fd273]">Richard Lukeman</div>
              <div className="font-mono text-[#a8b8c8]">+2347030518468</div>
              <div className="mt-1 text-[9px] text-[#7a7a7a]">Send a DM for church deployment & custom support.</div>
            </div>
          </div>

          {/* Tab Content */}
          <div className="min-w-0 flex-1 overflow-y-auto px-6 py-5 text-[12px] leading-relaxed text-[#ccc]">
            {tab === "guide" && (
              <div className="space-y-6">
                {GUIDE.map((g) => (
                  <div key={g.title}>
                    <div className="mb-2 text-[13px] font-semibold text-[#f0f0f0]">{g.title}</div>
                    <ul className="space-y-1.5">
                      {g.lines.map((l) => (
                        <li key={l} className="flex items-start gap-2 text-[#b8b8b8]">
                          <span className="mt-[7px] h-1.5 w-1.5 flex-none rounded-full bg-[#3d6ea8]" />
                          <span>{l}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            )}

            {tab === "standalone" && (
              <div className="space-y-6">
                <div>
                  <div className="flex items-center gap-2 text-[14px] font-semibold text-[#f0f0f0]">
                    <Package className="h-4 w-4 text-[#2fd273]" />
                    1. Building a Standalone Windows Executable (.exe)
                  </div>
                  <p className="mt-1 text-[11px] text-[#9a9a9a]">
                    You can package StreamForge Studio into a native Windows <code className="text-[#82aaff]">.exe</code> installer or portable binary.
                  </p>
                  <div className="mt-2.5 rounded-md border border-[#303a4b] bg-[#141822] p-3 font-mono text-[11px] text-[#2fd273]">
                    <div className="text-[10px] text-[#8a8a8a]">// Step 1: Build the web bundle</div>
                    <div>npm run build</div>
                    <div className="mt-2 text-[10px] text-[#8a8a8a]">// Step 2: Package into native Windows .exe via Electron</div>
                    <div>npx electron-builder --win nsis</div>
                    <div className="mt-2 text-[10px] text-[#8a8a8a]">// Step 3: Alternatively, package via Tauri .msi/.exe</div>
                    <div>npm run tauri build</div>
                  </div>
                  <p className="mt-2 text-[11px] text-[#a8b8c8]">
                    The output installer <code className="text-[#82aaff]">StreamForge_Studio_Setup.exe</code> will be generated in the <code className="text-[#82aaff]">release/</code> or <code className="text-[#82aaff]">src-tauri/target/release/bundle/msi/</code> folder.
                  </p>
                </div>

                <div className="border-t border-[#2a2a2a] pt-4">
                  <div className="flex items-center gap-2 text-[14px] font-semibold text-[#f0f0f0]">
                    <HardDrive className="h-4 w-4 text-[#ffb020]" />
                    2. Portable "Plug and Play" Folder (Run Without Installation)
                  </div>
                  <p className="mt-1 text-[11px] text-[#9a9a9a]">
                    To create a portable folder on a flash drive that runs instantly on any PC without installing:
                  </p>
                  <ol className="mt-2.5 space-y-2 text-[11px] text-[#b8b8b8]">
                    <li className="flex items-start gap-2">
                      <span className="flex h-4 w-4 flex-none items-center justify-center rounded-full bg-[#3d6ea8] text-[9px] font-bold text-white">1</span>
                      <span>Run <code className="text-[#82aaff]">npx electron-builder --win portable</code> to generate a portable single-file executable.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="flex h-4 w-4 flex-none items-center justify-center rounded-full bg-[#3d6ea8] text-[9px] font-bold text-white">2</span>
                      <span>
                        Place the <code className="text-[#2fd273]">StreamForge-Portable.exe</code> into a folder along with an icon file (<code className="text-[#82aaff]">app.ico</code>).
                      </span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="flex h-4 w-4 flex-none items-center justify-center rounded-full bg-[#3d6ea8] text-[9px] font-bold text-white">3</span>
                      <span>
                        <strong>Plug and Play:</strong> Copy this folder to any computer or USB drive. When opened on any machine, the app automatically recognizes that system&apos;s unique ID, initializes its offline Bible & local hardware cameras, and works immediately with zero setup!
                      </span>
                    </li>
                  </ol>
                </div>

                <div className="border-t border-[#2a2a2a] pt-4">
                  <div className="flex items-center gap-2 text-[14px] font-semibold text-[#f0f0f0]">
                    <MousePointerClick className="h-4 w-4 text-[#3d6ea8]" />
                    3. One-Click Desktop App (Zero Command Prompt / Non-Technical Users)
                  </div>
                  <p className="mt-1 text-[11px] text-[#9a9a9a]">
                    For non-technical operators who don&apos;t know how to use CMD or terminal windows:
                  </p>
                  <ul className="mt-2.5 space-y-2 text-[11px] text-[#b8b8b8]">
                    <li className="rounded border border-[#1a2a3a] bg-[#121926] p-2.5">
                      <div className="font-semibold text-[#e8e8e8]">Option A — Double-Click HTML File (No Server Needed):</div>
                      <div className="mt-1 text-[10.5px]">
                        Run <code className="text-[#82aaff]">npm run build</code> once. This compiles the entire app into a single, standalone HTML file at <code className="text-[#2fd273]">dist/index.html</code>. Any non-technical user can double-click this file directly to launch StreamForge Studio in Edge or Chrome with zero terminal usage!
                      </div>
                    </li>
                    <li className="rounded border border-[#1a2a3a] bg-[#121926] p-2.5">
                      <div className="font-semibold text-[#e8e8e8]">Option B — One-Click Windows Shortcut (.bat / .lnk):</div>
                      <div className="mt-1 text-[10.5px]">
                        Create a desktop shortcut or batch file named <code className="text-[#2fd273]">StreamForge Studio.bat</code> containing:
                        <div className="mt-1 font-mono text-[10px] text-[#2fd273]">start msedge --app="%CD%\dist\index.html" --start-fullscreen</div>
                        Double-clicking this icon opens StreamForge Studio in its own standalone, clean desktop app window with no address bars and no CMD windows.
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
            )}

            {tab === "about" && (
              <div className="space-y-5">
                <div className="rounded-lg border border-[#303a4b] bg-[#141a24] p-5">
                  <div className="text-[20px] font-bold text-[#ffffff]">StreamForge Studio</div>
                  <div className="text-[12px] text-[#8a9ab0]">Version 4.8 — Low-Latency Broadcast & Church Media Suite</div>

                  <div className="mt-4 flex items-start gap-3 rounded-md border border-[#1a2f23] bg-[#0d1f18] p-4 text-[#2fd273]">
                    <Code className="mt-0.5 h-5 w-5 flex-none" />
                    <div>
                      <div className="text-[14px] font-bold text-white">
                        [Richard Lukeman | +2347030518468] designed this software for churches. Send a DM.
                      </div>
                      <div className="mt-1 text-[11px] text-[#82e0aa]">
                        Designed specifically for Church media teams, live streaming, multi-camera broadcasting, lyrics projection, and scripture presentation.
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 grid grid-cols-2 gap-3 text-[11px]">
                    <div className="rounded border border-[#2a2a2a] bg-[#1c1c1c] p-3">
                      <div className="font-semibold text-[#f0f0f0]">Developer Name:</div>
                      <div className="mt-0.5 text-[#3d6ea8]">Richard Lukeman</div>
                      <div className="mt-2 font-semibold text-[#f0f0f0]">Contact Phone:</div>
                      <div className="mt-0.5 font-mono text-[#2fd273]">+2347030518468</div>
                    </div>
                    <div className="rounded border border-[#2a2a2a] bg-[#1c1c1c] p-3">
                      <div className="font-semibold text-[#f0f0f0]">Direct DM / Support:</div>
                      <div className="mt-0.5 text-[#a8b8c8]">Available for custom church media installs, training, and feature additions.</div>
                    </div>
                  </div>
                </div>

                <div className="space-y-2 text-[11px] text-[#8a8a8a]">
                  <div className="font-semibold text-[#d0d0d0]">Key Engine Capabilities:</div>
                  <p>
                    StreamForge Studio blends OBS Studio and vMix features into a unified broadcast console with GPU compositing,
                    vMix-style 4-channel overlays, offline KJV Bible with live speech recognition, praise & worship lyrics engine, NDI, WebRTC,
                    SRT, RTMP, and Zoom meeting bridge.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between border-t border-[#1a1a1a] bg-[#2b2b2b] px-4 py-2.5">
          <div className="flex items-center gap-2 text-[11px] text-[#2fd273]">
            <PhoneCall className="h-3.5 w-3.5" />
            <span>[Richard Lukeman | +2347030518468] designed this software for churches. Send a DM.</span>
          </div>
          <button
            onClick={onClose}
            className="rounded border border-[#111] bg-[#3d6ea8] px-4 py-1.5 text-[12px] font-medium text-white hover:bg-[#4a7bb8]"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
