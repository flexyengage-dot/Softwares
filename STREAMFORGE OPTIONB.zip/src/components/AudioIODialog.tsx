import { AudioLines } from "lucide-react";
import { AUDIO_INPUTS, AUDIO_OUTPUTS, type AudioChannel } from "../engine/types";

interface Props {
  channel: AudioChannel;
  onSave: (patch: Partial<AudioChannel>) => void;
  onClose: () => void;
}

export default function AudioIODialog({ channel, onSave, onClose }: Props) {
  const isOutputBus = channel.kind === "master";

  return (
    <div
      className="fixed inset-0 z-[65] flex items-center justify-center bg-black/60 p-4"
      onClick={onClose}
      onContextMenu={(e) => e.preventDefault()}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-[440px] overflow-hidden rounded-lg border border-[#111] bg-[#252525] shadow-2xl"
      >
        <div className="flex items-center gap-2.5 border-b border-[#1a1a1a] bg-[#2b2b2b] px-4 py-2.5">
          <AudioLines className="h-4 w-4 text-[#3d6ea8]" />
          <div>
            <div className="text-[13px] font-semibold text-[#f0f0f0]">Audio I/O — {channel.name}</div>
            <div className="text-[10px] uppercase tracking-widest text-[#8a8a8a]">{channel.kind} channel</div>
          </div>
          <button onClick={onClose} className="ml-auto rounded px-2 py-0.5 text-[11px] text-[#c8c8c8] hover:bg-[#3a3a3a]">
            Close
          </button>
        </div>

        <div className="space-y-4 px-5 py-4">
          {!isOutputBus && (
            <label className="block">
              <span className="mb-1 block text-[11px] text-[#c8c8c8]">Input device</span>
              <select
                defaultValue={channel.inputDevice ?? AUDIO_INPUTS[0]}
                onChange={(e) => onSave({ inputDevice: e.target.value })}
                className="w-full rounded border border-[#111] bg-[#2b2b2b] px-2 py-1.5 text-[12px] text-[#e8e8e8] focus:border-[#3d6ea8] focus:outline-none"
              >
                {AUDIO_INPUTS.map((d) => (
                  <option key={d}>{d}</option>
                ))}
              </select>
            </label>
          )}

          <label className="block">
            <span className="mb-1 block text-[11px] text-[#c8c8c8]">{isOutputBus ? "Output device" : "Output / monitor device"}</span>
            <select
              defaultValue={channel.outputDevice ?? AUDIO_OUTPUTS[0]}
              onChange={(e) => onSave({ outputDevice: e.target.value })}
              className="w-full rounded border border-[#111] bg-[#2b2b2b] px-2 py-1.5 text-[12px] text-[#e8e8e8] focus:border-[#3d6ea8] focus:outline-none"
            >
              {AUDIO_OUTPUTS.map((d) => (
                <option key={d}>{d}</option>
              ))}
            </select>
          </label>

          <div>
            <span className="mb-1.5 block text-[11px] text-[#c8c8c8]">Monitoring</span>
            <div className="grid grid-cols-3 gap-1.5">
              {([
                { v: "off", label: "Monitor Off", desc: "Stream only" },
                { v: "monitor", label: "Monitor Only", desc: "Headphones only" },
                { v: "both", label: "Monitor & Out", desc: "Hear + stream" },
              ] as const).map((o) => {
                const active = (channel.monitorMode ?? (isOutputBus ? "both" : "off")) === o.v;
                return (
                  <button
                    key={o.v}
                    onClick={() => onSave({ monitorMode: o.v })}
                    className={`rounded border px-2 py-2 text-left transition-colors ${
                      active ? "border-[#3d6ea8] bg-[#2a3a55]" : "border-[#1a1a1a] bg-[#2b2b2b] hover:border-[#444]"
                    }`}
                  >
                    <div className={`text-[11px] font-medium ${active ? "text-white" : "text-[#c8c8c8]"}`}>{o.label}</div>
                    <div className="text-[9px] text-[#8a8a8a]">{o.desc}</div>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="rounded border border-[#1a2a3a] bg-[#101a26] px-3 py-2 text-[10px] leading-relaxed text-[#82aaff]">
            Routing changes apply immediately and are saved with your layout. Double-click any mixer channel to reopen.
          </div>
        </div>

        <div className="flex items-center justify-end gap-2 border-t border-[#1a1a1a] bg-[#2b2b2b] px-4 py-2.5">
          <button onClick={onClose} className="rounded border border-[#111] bg-[#3a3a3a] px-4 py-1.5 text-[12px] text-white hover:bg-[#4a4a4a]">
            Done
          </button>
        </div>
      </div>
    </div>
  );
}
