import { useEffect, useRef, useState } from "react";
import { BookOpen, ChevronLeft, ChevronRight, GripVertical, Globe, Send, X, Wifi, WifiOff } from "lucide-react";
import { suggestBooks, lookupVerse, hasFullBible, ALL_VERSIONS, versionLabel, parseReference, type VerseRef, type BibleVersion } from "../engine/bible";
import type { BibleBg } from "../App";
import { useDraggable } from "./useDraggable";

interface Props {
  armed: boolean;
  onClose: () => void;
  onPlace: (ref: VerseRef, text: string, sourceLabel: string, bg: BibleBg) => void;
}

export default function BibleVersePopup({ armed, onClose, onPlace }: Props) {
  const drag = useDraggable({ x: window.innerWidth - 380, y: window.innerHeight - 500 });
  const [bookInput, setBookInput] = useState("John");
  const [bookSuggestions, setBookSuggestions] = useState(() => suggestBooks("John"));
  const [showBookList, setShowBookList] = useState(false);
  const [chapter, setChapter] = useState(3);
  const [verse, setVerse] = useState(16);
  const [text, setText] = useState("");
  const [status, setStatus] = useState("");
  const [loading, setLoading] = useState(false);
  const [version, setVersion] = useState<BibleVersion>("kjv");
  const [lastSource, setLastSource] = useState<string>("");

  const bookInputRef = useRef<HTMLInputElement>(null);

  /* autocomplete: update suggestions as user types */
  const onBookChange = (val: string) => {
    setBookInput(val);
    setBookSuggestions(suggestBooks(val));
    setShowBookList(true);
  };

  /* if the user finishes typing a full verse like "John 3 16", parse and load */
  const onBookKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      const ref = parseReference(bookInput);
      if (ref) {
        setBookInput(ref.book);
        setChapter(ref.chapter);
        setVerse(ref.verse);
        void load(ref.book, ref.chapter, ref.verse);
        setShowBookList(false);
        return;
      }
      /* try combining book + chapter + verse from inputs */
      void load(bookInput, chapter, verse);
      setShowBookList(false);
    }
  };

  const onBookBlur = () => {
    setTimeout(() => setShowBookList(false), 150);
  };

  const load = async (b: string, c: number, v: number, ver: BibleVersion = version) => {
    setLoading(true);
    setStatus("");
    const res = await lookupVerse({ book: b, chapter: c, verse: v }, ver);
    setLoading(false);
    if (res) {
      setText(res.text);
      const label = res.source === "online" ? `fetched online (${versionLabel(ver)})` : `${versionLabel(ver)} · offline`;
      setStatus(label);
      setLastSource(label);
      if (armed) onPlace({ book: b, chapter: c, verse: v }, res.text, label, { mode: "default", color: "#10131c", variant: 0 });
    } else {
      setText("");
      const offline = hasFullBible(ver);
      setStatus(offline
        ? `${versionLabel(ver)}: verse not found — check spelling, chapter and verse numbers`
        : navigator.onLine
          ? `Could not fetch "${bookInput} ${chapter}:${verse}" — check spelling, chapter, and verse numbers`
          : `Offline — no data for "${bookInput} ${chapter}:${verse}". Go online to fetch, or download ${versionLabel(ver)} from the Bible menu for offline use.`);
    }
  };

  const switchVersion = (newVer: BibleVersion) => {
    setVersion(newVer);
    setText("");
    setStatus("");
    void load(bookInput, chapter, verse, newVer);
  };

  useEffect(() => { void load(bookInput, chapter, verse); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const step = (d: number) => {
    const v = Math.max(1, verse + d);
    setVerse(v);
    void load(bookInput, chapter, v);
  };

  return (
    <div className="anim-rise fixed z-[60] w-[370px] overflow-hidden rounded-lg border border-[#2e2f33] bg-[#202124] shadow-2xl"
      style={drag.style} onContextMenu={(e) => e.preventDefault()}>
      {/* drag handle */}
      <div className="flex cursor-grab items-center gap-2 border-b border-[#26272b] bg-[#26272b] px-2 py-2 active:cursor-grabbing" {...drag.handleProps}>
        <GripVertical className="h-4 w-4 flex-none text-[#5c636a]" />
        <BookOpen className="h-4 w-4 text-[#d4a437]" />
        <span className="text-[12px] font-bold tracking-wide text-[#e8e8e8]">VERSE FINDER</span>
        <span className={`ml-auto rounded px-1.5 py-px text-[8px] font-bold uppercase tracking-widest ${armed ? "bg-[#2f6b45] text-white" : "bg-[#3a3b40] text-[#9aa0a6]"}`}>
          {armed ? "Live → Program" : "Preview"}
        </span>
        {navigator.onLine ? <Wifi className="h-3.5 w-3.5 text-[#31c48d]" /> : <WifiOff className="h-3.5 w-3.5 text-[#e5484d]" />}
        <button onClick={onClose} onPointerDown={(e) => e.stopPropagation()} className="rounded p-0.5 text-[#7d838a] hover:bg-[#3a3b40] hover:text-white"><X className="h-3.5 w-3.5" /></button>
      </div>

      <div className="max-h-[66vh] space-y-2 overflow-y-auto p-3">
        {/* version selector */}
        <div className="flex items-center gap-1.5">
          <Globe className="h-3.5 w-3.5 flex-none text-[#7d838a]" />
          <select value={version} onChange={(e) => switchVersion(e.target.value as BibleVersion)}
            className="min-w-0 flex-1 rounded border border-[#111] bg-[#2b2b2b] px-2 py-1.5 text-[11px] text-[#e8e8e8] focus:border-[#3d6ea8] focus:outline-none">
            {ALL_VERSIONS.map((v) => <option key={v} value={v}>{versionLabel(v)} — {v.toUpperCase()}</option>)}
          </select>
        </div>

        {/* book autocomplete */}
        <div className="relative">
          <div className="text-[9px] uppercase tracking-widest text-[#7d838a] mb-0.5">Book · Chapter : Verse</div>
          <div className="grid grid-cols-[1fr_64px_64px] gap-1.5">
            <input ref={bookInputRef} type="text" value={bookInput}
              onChange={(e) => onBookChange(e.target.value)}
              onKeyDown={onBookKeyDown}
              onFocus={() => { setBookSuggestions(suggestBooks(bookInput)); setShowBookList(true); }}
              onBlur={onBookBlur}
              placeholder="e.g. John 3:16"
              className="rounded border border-[#111] bg-[#2b2b2b] px-2 py-1.5 text-[11px] text-[#e8e8e8] placeholder:text-[#5c6b80] focus:border-[#3d6ea8] focus:outline-none" />
            <input type="number" min={1} value={chapter} aria-label="Chapter"
              onChange={(e) => setChapter(Number(e.target.value) || 1)}
              className="rounded border border-[#111] bg-[#2b2b2b] px-2 py-1.5 text-center text-[11px] text-[#e8e8e8] focus:border-[#3d6ea8] focus:outline-none" />
            <input type="number" min={1} value={verse} aria-label="Verse"
              onChange={(e) => setVerse(Number(e.target.value) || 1)}
              onKeyDown={(e) => { if (e.key === "Enter") void load(bookInput, chapter, verse); }}
              className="rounded border border-[#111] bg-[#2b2b2b] px-2 py-1.5 text-center text-[11px] text-[#e8e8e8] focus:border-[#3d6ea8] focus:outline-none" />
          </div>
          {/* autocomplete dropdown */}
          {showBookList && bookSuggestions.length > 0 && (
            <div className="absolute left-0 top-[calc(100%+2px)] z-10 w-full overflow-hidden rounded border border-[#111] bg-[#2b2b2b] shadow-lg">
              {bookSuggestions.map((b) => (
                <button key={b.name}
                  onMouseDown={(e) => { e.preventDefault(); setBookInput(b.name); setShowBookList(false); }}
                  className="flex w-full items-center justify-between rounded px-2.5 py-1 text-left text-[11px] hover:bg-[#3d6ea8] hover:text-white">
                  <span className="text-[#e8e8e8]">{b.name}</span>
                  <span className="text-[9px] text-[#7d838a]">{b.testament} · {b.chapters} ch</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* navigation */}
        <div className="flex items-center gap-1.5">
          <button onClick={() => step(-1)} title="Previous verse"
            className="flex h-7 w-7 flex-none items-center justify-center rounded bg-[#2a2b2f] text-[#c8c8c8] hover:bg-[#3a3b40]">
            <ChevronLeft className="h-4 w-4" />
          </button>
          <button onClick={() => void load(bookInput, chapter, verse)} disabled={loading}
            className="h-7 flex-1 rounded bg-[#3d6ea8] text-[11px] font-semibold text-white hover:bg-[#4a7bb8] disabled:opacity-50">
            {loading ? "Loading…" : "Load Verse"}
          </button>
          <button onClick={() => step(1)} title="Next verse"
            className="flex h-7 w-7 flex-none items-center justify-center rounded bg-[#2a2b2f] text-[#c8c8c8] hover:bg-[#3a3b40]">
            <ChevronRight className="h-4 w-4" />
          </button>
        </div>

        {/* verse text */}
        <div className="min-h-[56px] rounded border border-[#1a2a3a] bg-[#101a26] px-3 py-2">
          {text ? (
            <p className="text-center text-[12px] leading-relaxed text-[#e9edf3]" style={{ fontFamily: "Tahoma, Verdana, sans-serif" }}>"{text}"</p>
          ) : (
            <p className="text-center text-[11px] text-[#7d838a]">{loading ? "Looking up…" : "Type a reference and press Enter or Load Verse."}</p>
          )}
          <div className="mt-1 flex items-center justify-center gap-2">
            <span className="font-mono text-[10px] text-[#d4a437]">{bookInput} {chapter}:{verse}</span>
            <span className="text-[9px] text-[#7d838a]">· {lastSource || status || (navigator.onLine ? "ready" : "offline")}</span>
          </div>
        </div>

        <button
          onClick={() => { if (text) onPlace({ book: bookInput, chapter, verse }, text, lastSource || status, { mode: "default", color: "#10131c", variant: 0 }); }}
          disabled={!text}
          className={`flex w-full items-center justify-center gap-2 rounded py-1.5 text-[11px] font-bold disabled:cursor-not-allowed disabled:opacity-40 ${
            armed ? "bg-[#2f6b45] text-white hover:bg-[#37805a]" : "bg-[#d4a437] text-[#1a1206] hover:bg-[#e0b44a]"
          }`}>
          <Send className="h-3.5 w-3.5" /> {armed ? "Send Full Screen → Program" : "Send Full Screen → Preview"}
        </button>
      </div>
    </div>
  );
}
