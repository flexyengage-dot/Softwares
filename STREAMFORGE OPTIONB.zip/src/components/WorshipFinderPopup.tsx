import { useRef, useState } from "react";
import { ChevronDown, GripVertical, Library, Mic, MicOff, Music, Search, Send, X } from "lucide-react";
import { searchWorship, type WorshipSong } from "../engine/worship";
import { searchCached, cacheLyric, cachedCount, cachedSize, clearCached, getAllCached, removeCached } from "../engine/lyricsCache";
import { useDraggable } from "./useDraggable";

export interface WorshipOpts {
  mode: "lower" | "full";
  font: string;
  auto: boolean;
  color: string;
}

interface Props {
  onClose: () => void;
  onPlace: (song: { title: string; artist: string }, lyric: string, opts: WorshipOpts) => void;
}

interface OnlineHit { title: string; artist: string; }

/* ─── lyrics.ovh — suggestion endpoint ─── */
async function suggestOnline(q: string): Promise<OnlineHit[]> {
  if (!navigator.onLine) return [];
  try {
    const res = await fetch(`https://api.lyrics.ovh/suggest/${encodeURIComponent(q)}`, { signal: AbortSignal.timeout(7000) });
    if (!res.ok) return [];
    const j = (await res.json()) as { data?: { title?: string; artist?: { name?: string } }[] };
    return (j.data ?? []).slice(0, 8).map((d) => ({ title: d.title ?? "", artist: d.artist?.name ?? "" })).filter((h) => h.title && h.artist);
  } catch { return []; }
}

/* ─── lyrics.ovh — fetch full lyrics by artist + title ─── */
async function fetchLyric(artist: string, title: string): Promise<string | null> {
  if (!navigator.onLine) return null;
  try {
    const res = await fetch(`https://api.lyrics.ovh/v1/${encodeURIComponent(artist)}/${encodeURIComponent(title)}`, { signal: AbortSignal.timeout(8000) });
    if (!res.ok) return null;
    const j = (await res.json()) as { lyrics?: string };
    return (j.lyrics ?? "").trim() || null;
  } catch { return null; }
}

type Tab = "search" | "saved";

export default function WorshipFinderPopup({ onClose, onPlace }: Props) {
  const drag = useDraggable({ x: window.innerWidth - 420, y: window.innerHeight - 520 });
  const [tab, setTab] = useState<Tab>("search");

  /* search state */
  const [q, setQ] = useState("");
  const [localResults, setLocalResults] = useState<WorshipSong[]>([]);
  const [onlineResults, setOnlineResults] = useState<OnlineHit[]>([]);
  const [busy, setBusy] = useState(false);
  const searchInputRef = useRef<HTMLInputElement>(null);

  /* display options */
  const [mode, setMode] = useState<"lower" | "full">("lower");
  const [font, setFont] = useState<"roma" | "tahoma">("tahoma");
  const [auto, setAuto] = useState(false);
  const [color, setColor] = useState("#123a7a");
  const fontStack = font === "roma" ? `"Times New Roman", Georgia, serif` : `Tahoma, "Segoe UI", Verdana, sans-serif`;

  /* live verse preview */
  const [previewText, setPreviewText] = useState("");
  const [previewMeta, setPreviewMeta] = useState<{ title: string; artist: string } | null>(null);
  const [lyricLines, setLyricLines] = useState<string[]>([]);
  const [busyLyric, setBusyLyric] = useState(false);

  /* live listening */
  const [listening, setListening] = useState(false);
  const recogRef = useRef<{ stop: () => void } | null>(null);

  /* saved lyrics tab */
  const [savedQuery, setSavedQuery] = useState("");
  const [savedExpanded, setSavedExpanded] = useState<string | null>(null);
  const savedList = savedQuery.trim() ? searchCached(savedQuery) : getAllCached();

  const [searchStatus, setSearchStatus] = useState("");

  const doSearch = async () => {
    const query = q.trim();
    if (!query) return;
    setBusy(true);
    setSearchStatus("Searching…");

    /* 1. Local cache search */
    const local = searchWorship(query);
    setLocalResults(local);

    /* 2. Online API search */
    if (!navigator.onLine) {
      setSearchStatus(local.length > 0 ? `${local.length} result(s) found locally` : "Offline — no results");
      setBusy(false);
      return;
    }

    setSearchStatus("Searching online…");
    const hits = await suggestOnline(query);
    setOnlineResults(hits);

    if (local.length === 0 && hits.length === 0) {
      setSearchStatus(`No results for "${query}". Try the artist name or a lyric line.`);
    } else {
      setSearchStatus(`Found ${local.length + hits.length} result(s)`);
    }
    setBusy(false);
    searchInputRef.current?.focus();
  };

  const fetchAndPreview = async (title: string, artist: string) => {
    /* check cache first */
    const hit = searchCached(`${artist} ${title}`)[0];
    if (hit) {
      const lines = hit.lyrics.split("\n").map((l) => l.trim()).filter(Boolean);
      setLyricLines(lines);
      setPreviewMeta({ title: hit.title, artist: hit.artist });
      setPreviewText(lines[0] ?? "");
      return;
    }
    if (!navigator.onLine) {
      setLyricLines(["— Offline: no cached lyrics for this song —"]);
      setPreviewMeta({ title, artist });
      return;
    }
    setBusyLyric(true);
    const text = await fetchLyric(artist, title);
    setBusyLyric(false);
    if (text) {
      const lines = text.split("\n").map((l) => l.trim()).filter(Boolean);
      setLyricLines(lines);
      setPreviewMeta({ title, artist });
      cacheLyric(title, artist, text, "lyrics.ovh", "search");
    } else {
      setLyricLines(["— Could not fetch lyrics —"]);
      setPreviewMeta({ title, artist });
    }
  };

  const placeLine = (line: string) => {
    if (!previewMeta || !line || line.startsWith("—")) return;
    onPlace(previewMeta, line, { mode, font: fontStack, auto, color });
  };

  const toggleListen = () => {
    const SR = (window as unknown as { SpeechRecognition?: new () => any; webkitSpeechRecognition?: new () => any });
    const Ctor = SR.SpeechRecognition ?? SR.webkitSpeechRecognition;
    if (!Ctor) return;
    if (listening) { recogRef.current?.stop(); recogRef.current = null; setListening(false); return; }
    const rec = new Ctor();
    rec.continuous = true; rec.interimResults = true; rec.lang = "en-US";
    rec.onresult = (e: { resultIndex: number; results: ArrayLike<{ 0: { transcript: string } }> }) => {
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const t = e.results[i][0]?.transcript ?? "";
        const hit = searchWorship(t);
        if (hit[0]) { void fetchAndPreview(hit[0].title, hit[0].artist); return; }
      }
    };
    rec.onend = () => { if (recogRef.current) { try { rec.start(); } catch { /* ignore */ } } };
    try { rec.start(); recogRef.current = rec; setListening(true); } catch { /* ignore */ }
  };

  return (
    <div
      className="anim-rise fixed z-[60] w-[440px] overflow-hidden rounded-lg border border-[#2e2f33] bg-[#202124] shadow-2xl"
      style={drag.style} onContextMenu={(e) => e.preventDefault()}>
      {/* drag handle + header */}
      <div className="flex cursor-grab items-center gap-2 border-b border-[#26272b] bg-[#26272b] px-2 py-2 active:cursor-grabbing" {...drag.handleProps}>
        <GripVertical className="h-4 w-4 flex-none text-[#5c636a]" />
        <Music className="h-4 w-4 text-[#7fb2ff]" />
        <span className="text-[12px] font-bold tracking-wide text-[#e8e8e8]">PRAISE &amp; WORSHIP</span>
        <span className="text-[9px] text-[#7d838a]">· {cachedCount()} saved</span>
        <button onClick={toggleListen} onPointerDown={(e) => e.stopPropagation()}
          title={listening ? "Stop listening" : "Voice search"}
          className={`ml-auto flex h-6 w-6 items-center justify-center rounded ${listening ? "bg-[#e5484d] text-white animate-pulse" : "bg-[#2a2b2f] text-[#9aa0a6] hover:bg-[#3a3b40]"}`}>
          {listening ? <MicOff className="h-3.5 w-3.5" /> : <Mic className="h-3.5 w-3.5" />}
        </button>
        <button onClick={onClose} onPointerDown={(e) => e.stopPropagation()} className="rounded p-0.5 text-[#7d838a] hover:bg-[#3a3b40] hover:text-white"><X className="h-3.5 w-3.5" /></button>
      </div>

      {/* tabs */}
      <div className="flex border-b border-[#26272b] bg-[#1b1c20]">
        <button onClick={() => setTab("search")}
          className={`flex-1 py-1.5 text-[11px] font-semibold transition-colors ${tab === "search" ? "border-b-2 border-[#7fb2ff] text-[#e8e8e8]" : "text-[#7d838a] hover:text-[#b0b8be]"}`}>
          <Search className="mr-1 inline h-3.5 w-3.5" /> Search
        </button>
        <button onClick={() => setTab("saved")}
          className={`flex-1 py-1.5 text-[11px] font-semibold transition-colors ${tab === "saved" ? "border-b-2 border-[#7fb2ff] text-[#e8e8e8]" : "text-[#7d838a] hover:text-[#b0b8be]"}`}>
          <Library className="mr-1 inline h-3.5 w-3.5" /> Saved ({cachedCount()})
        </button>
      </div>

      <div className="max-h-[60vh] space-y-2 overflow-y-auto p-3">
        {/* ═══ SEARCH TAB ═══ */}
        {tab === "search" && (<>
          <div className="flex items-center gap-1.5">
            <div className="relative flex-1">
              <Search className="pointer-events-none absolute left-2 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-[#5c6b80]" />
              <input ref={searchInputRef} value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") void doSearch(); }}
                placeholder="Song, artist or lyric…"
                className="w-full rounded border border-[#111] bg-[#2b2b2b] py-1.5 pl-7 pr-2 text-[11px] text-[#e8e8e8] placeholder:text-[#5c6b80] focus:border-[#3d6ea8] focus:outline-none" />
            </div>
            <button onClick={() => void doSearch()} disabled={busy}
              className="h-7 flex-none rounded bg-[#3d6ea8] px-3 text-[11px] font-semibold text-white hover:bg-[#4a7bb8] disabled:opacity-50">
              {busy ? "…" : "Search"}
            </button>
          </div>

          {/* search status */}
          {searchStatus && (
            <div className="flex items-center gap-2 rounded border border-[#1a2a3a] bg-[#101a26] px-3 py-1.5">
              {busy ? (
                <><span className="inline-block h-2 w-2 animate-spin rounded-full border border-[#7fb2ff] border-t-transparent" />
                <span className="text-[10px] text-[#7fb2ff]">{searchStatus}</span></>
              ) : (
                <span className="text-[10px] text-[#9aa3a9]">{searchStatus}</span>
              )}
            </div>
          )}

          {/* display options */}
          <div className="flex items-center gap-2 rounded border border-[#26272b] bg-[#1b1c20] px-2 py-1.5">
            <div className="grid grid-cols-2 gap-1">
              <button onClick={() => setMode("lower")} className={`rounded px-1 py-1 text-[10px] font-semibold ${mode === "lower" ? "bg-[#3d6ea8] text-white" : "bg-[#2a2b2f] text-[#9aa0a6]"}`}>Lower Third</button>
              <button onClick={() => setMode("full")} className={`rounded px-1 py-1 text-[10px] font-semibold ${mode === "full" ? "bg-[#3d6ea8] text-white" : "bg-[#2a2b2f] text-[#9aa0a6]"}`}>Full Screen</button>
            </div>
            <select value={font} onChange={(e) => setFont(e.target.value as "roma" | "tahoma")} className="rounded border border-[#111] bg-[#2b2b2b] px-1 py-1 text-[10px] text-[#e8e8e8] focus:outline-none">
              <option value="roma">Roma</option>
              <option value="tahoma">Tahoma</option>
            </select>
            <input type="color" value={color} onChange={(e) => setColor(e.target.value)} className="h-6 w-8 cursor-pointer rounded border border-[#111]" />
            <label className="flex cursor-pointer items-center gap-1.5 text-[9px] text-[#9aa0a6]">
              <input type="checkbox" checked={auto} onChange={(e) => setAuto(e.target.checked)} className="accent-[#31c48d] scale-90" /> Auto-send
            </label>
          </div>

          <div className="space-y-1">
            {localResults.map((s) => (
              <button key={`l-${s.title}-${s.artist}`} onClick={() => void fetchAndPreview(s.title, s.artist)}
                className="flex w-full items-center gap-2 rounded border border-[#111] bg-[#2b2b2b] px-2.5 py-1.5 text-left transition-colors hover:bg-[#3d6ea8] hover:text-white">
                <Music className="h-3.5 w-3.5 flex-none text-[#7fb2ff]" />
                <div className="min-w-0"><span className="text-[11px]">{s.title}</span><span className="ml-1.5 text-[9px] text-[#9aa0a6]">{s.artist}</span></div>
                <span className="ml-auto flex-none text-[8px] text-[#31c48d]">OFFLINE</span>
              </button>
            ))}
            {onlineResults.filter((o) => !localResults.some((r) => r.title === o.title)).map((s) => (
              <button key={`o-${s.title}-${s.artist}`} onClick={() => void fetchAndPreview(s.title, s.artist)}
                className="flex w-full items-center gap-2 rounded border border-[#111] bg-[#232a33] px-2.5 py-1.5 text-left transition-colors hover:bg-[#3d6ea8] hover:text-white">
                <Music className="h-3.5 w-3.5 flex-none text-[#31c48d]" />
                <div className="min-w-0"><span className="text-[11px]">{s.title}</span><span className="ml-1.5 text-[9px] text-[#7fb2ff]">{s.artist}</span></div>
                <span className="ml-auto flex-none text-[8px] text-[#7fb2ff]">ONLINE</span>
              </button>
            ))}
            {q && !busy && localResults.length === 0 && onlineResults.length === 0 && (
              <div className="px-1 py-1 text-[10px] text-[#7d838a]">No matches. Try "artist - title" or a lyric line.</div>
            )}
          </div>

          {/* lyric preview */}
          {previewMeta && lyricLines.length > 0 && (
            <div className="rounded border border-[#1a2a3a] bg-[#101a26] px-3 py-2">
              <div className="mb-1 flex items-center justify-between">
                <div className="font-mono text-[10px] text-[#7fb2ff]">{previewMeta.title} · {previewMeta.artist}</div>
                <span className="text-[8px] text-[#7d838a]">{lyricLines.length} lines</span>
              </div>
              <div className="max-h-[120px] overflow-y-auto">
                {lyricLines.map((line, i) => (
                  <button key={i} onClick={() => placeLine(line)}
                    className="block w-full rounded px-2 py-[3px] text-left text-[11px] leading-relaxed text-[#e0e5e8] transition-colors hover:bg-[#1a2a44] hover:text-white"
                    style={{ fontFamily: fontStack }}>
                    {line}
                  </button>
                ))}
              </div>
            </div>
          )}

          {busyLyric && <div className="text-center text-[10px] text-[#7fb2ff]">Fetching lyrics…</div>}
        </>)}

        {/* ═══ SAVED TAB ═══ */}
        {tab === "saved" && (<>
          <div className="flex items-center gap-2">
            <div className="relative flex-1">
              <Search className="pointer-events-none absolute left-2 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-[#5c6b80]" />
              <input value={savedQuery} onChange={(e) => setSavedQuery(e.target.value)}
                placeholder="Search saved lyrics…"
                className="w-full rounded border border-[#111] bg-[#2b2b2b] py-1.5 pl-7 pr-2 text-[11px] text-[#e8e8e8] placeholder:text-[#5c6b80] focus:border-[#3d6ea8] focus:outline-none" />
            </div>
            <button onClick={clearCached} className="flex h-7 items-center gap-1 rounded bg-[#4a2a2a] px-2 text-[10px] text-[#e08080] hover:bg-[#5a3030]" title="Clear all saved lyrics">
              <X className="h-3 w-3" /> Clear
            </button>
          </div>

          <div className="text-[9px] text-[#7d838a]">{savedList.length} saved · {cachedSize()}</div>

          {savedList.length === 0 ? (
            <div className="py-4 text-center text-[10px] text-[#7d838a]">
              {savedQuery ? "No saved lyrics match your search." : "No saved lyrics yet. Search and send a lyric to save it here."}
            </div>
          ) : (
            <div className="space-y-1">
              {savedList.map((l) => {
                const isExp = savedExpanded === l.id;
                const lines = l.lyrics.split("\n").map((x: string) => x.trim()).filter(Boolean);
                return (
                  <div key={l.id} className={`rounded border ${isExp ? "border-[#3d6ea8]" : "border-[#111]"} bg-[#2b2b2b]`}>
                    <button onClick={() => setSavedExpanded(isExp ? null : l.id)}
                      className="flex w-full items-center gap-2 px-2.5 py-1.5 text-left transition-colors hover:bg-[#323a44]">
                      <Music className="h-3.5 w-3.5 flex-none text-[#7fb2ff]" />
                      <span className="flex-1 truncate text-[11px]">{l.title}</span>
                      <span className="text-[9px] text-[#7d838a]">{l.artist}</span>
                      <ChevronDown className={`h-3.5 w-3.5 flex-none text-[#7d838a] transition-transform ${isExp ? "rotate-180" : ""}`} />
                    </button>
                    {isExp && (
                      <div className="border-t border-[#1a2a3a] px-2.5 py-2">
                        <div className="mb-1 flex items-center justify-between text-[9px] text-[#7d838a]">
                          <span>{lines.length} lines · {l.source} · {l.version.toUpperCase()}</span>
                          <button onClick={(e) => { e.stopPropagation(); removeCached(l.id); }} className="text-[#e08080] hover:text-[#ff8a8a]">Remove</button>
                        </div>
                        {lines.map((line: string, i: number) => (
                          <button key={i} onClick={() => { onPlace({ title: l.title, artist: l.artist }, line, { mode, font: fontStack, auto, color }); }}
                            className="block w-full rounded px-2 py-[3px] text-left text-[11px] leading-relaxed text-[#e0e5e8] transition-colors hover:bg-[#1a2a44] hover:text-white"
                            style={{ fontFamily: fontStack }}>
                            {line}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </>)}

        {/* send button */}
        {previewMeta && previewText && (
          <button
            onClick={() => placeLine(previewText)}
            className="flex w-full items-center justify-center gap-2 rounded bg-[#7fb2ff] py-1.5 text-[11px] font-bold text-[#0a1420] hover:bg-[#9cc4ff]">
            <Send className="h-3.5 w-3.5" /> Send Full Screen → Preview
          </button>
        )}
      </div>
    </div>
  );
}
