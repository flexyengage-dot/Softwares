import { useEffect, useRef, useState, type MutableRefObject, type PointerEvent as RPtr } from "react";
import { clamp, DESTS, ENCODERS, REC_FORMATS, RESOLUTIONS, destLabel, encLabel, type StudioModel, type AudioChannel } from "../engine/types";
import { sfx } from "../engine/sfx";

interface Props {
  modelRef: MutableRefObject<StudioModel>;
  bump: () => void;
  log: (msg: string, kind?: "info" | "ok" | "warn") => void;
  registerMeter: (id: string, el: HTMLCanvasElement | null) => void;
  registerSpark: (el: HTMLCanvasElement | null) => void;
  toggleLive: () => void;
  toggleRec: () => void;
}

/* ------------------------------ fader strip ------------------------------ */

function Strip({ ch, bump, registerMeter }: {
  ch: AudioChannel;
  bump: () => void;
  registerMeter: (id: string, el: HTMLCanvasElement | null) => void;
}) {
  const [uiVol, setUiVol] = useState(ch.volume);
  const trackRef = useRef<HTMLDivElement>(null);
  const dragging = useRef(false);
  const isMaster = ch.kind === "master";

  const setFromPointer = (clientY: number) => {
    const t = trackRef.current;
    if (!t) return;
    const r = t.getBoundingClientRect();
    const v = Math.round(clamp(1 - (clientY - r.top) / r.height, 0, 1) * 100);
    ch.volume = v;
    setUiVol(v);
  };

  const onDown = (e: RPtr<HTMLDivElement>) => {
    dragging.current = true;
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
    setFromPointer(e.clientY);
  };
  const onMove = (e: RPtr<HTMLDivElement>) => { if (dragging.current) setFromPointer(e.clientY); };
  const onUp = () => { if (dragging.current) { dragging.current = false; bump(); } };

  return (
    <div className={`flex flex-col items-center gap-1 rounded-md border px-1.5 pb-2 pt-1.5 ${
      isMaster ? "border-amb/35 bg-amb-dim/20" : "border-ink-700 bg-ink-900/50"
    }`}>
      <canvas ref={(el) => registerMeter(ch.id, el)} width={12} height={132} className="h-[86px] w-3 rounded-sm" />
      <div
        ref={trackRef}
        onPointerDown={onDown}
        onPointerMove={onMove}
        onPointerUp={onUp}
        onPointerCancel={onUp}
        className="relative h-[86px] w-4 cursor-ns-resize touch-none rounded-full border border-ink-600 bg-ink-950"
      >
        <div
          className="absolute inset-x-[3px] bottom-0 rounded-full"
          style={{
            height: `${uiVol}%`,
            background: ch.muted
              ? "#303a4b"
              : isMaster
                ? "linear-gradient(180deg,#ffb020,#b45309)"
                : "linear-gradient(180deg,#2fd273,#0f7a43)",
          }}
        />
        <div
          className="absolute left-1/2 h-3.5 w-6 -translate-x-1/2 rounded-[3px] border border-ink-600 shadow-md"
          style={{
            bottom: `calc(${uiVol}% - 7px)`,
            background: "repeating-linear-gradient(90deg,#4a5568 0 1px,transparent 1px 3px), linear-gradient(180deg,#3a4557,#242b39)",
          }}
        />
      </div>
      <span className={`font-mono text-[9px] ${ch.muted ? "text-fog-500" : isMaster ? "text-amb" : "text-prv"}`}>
        {ch.muted ? "-∞" : `${uiVol}`}
      </span>
      <button
        onClick={() => { ch.muted = !ch.muted; bump(); }}
        className={`btn panel-label w-full rounded-sm border py-0.5 text-[9px] font-semibold ${
          ch.muted
            ? "border-prg bg-prg text-white shadow-[0_0_10px_rgba(255,68,56,0.4)]"
            : "border-ink-600 bg-ink-750 text-fog-300 hover:border-fog-500"
        }`}
      >
        {ch.muted ? "MUTED" : "MUTE"}
      </button>
      <span className={`panel-label max-w-full truncate text-[9px] ${isMaster ? "text-amb" : "text-fog-400"}`}>{ch.name}</span>
    </div>
  );
}

/* ------------------------------ stream panel ------------------------------ */

function fmtClock(ms: number) {
  const s = Math.floor(ms / 1000);
  const h = Math.floor(s / 3600), mn = Math.floor((s % 3600) / 60), ss = s % 60;
  return `${String(h).padStart(2, "0")}:${String(mn).padStart(2, "0")}:${String(ss).padStart(2, "0")}`;
}

export default function RightColumn({ modelRef, bump, log, registerMeter, registerSpark, toggleLive, toggleRec }: Props) {
  const m = modelRef.current;
  const [clock, setClock] = useState("00:00:00");
  const [recClock, setRecClock] = useState("00:00:00");

  useEffect(() => {
    const iv = setInterval(() => {
      const mm = modelRef.current;
      setClock(mm.live ? fmtClock(Date.now() - mm.liveStart) : "00:00:00");
      setRecClock(mm.recording ? fmtClock(Date.now() - mm.recStart) : "00:00:00");
    }, 500);
    return () => clearInterval(iv);
  }, [modelRef]);

  const mt = m.metrics;
  const gb = m.recording ? ((Date.now() - m.recStart) / 1000) * 0.72 / 1000 : 0;

  return (
    <div className="flex h-full flex-col gap-2.5 overflow-hidden">
      {/* ------------------------------- mixer ------------------------------- */}
      <section className="flex min-h-0 flex-1 flex-col rounded-lg border border-ink-700 bg-ink-850">
        <header className="flex items-center justify-between border-b border-ink-700 px-3 py-2">
          <h2 className="panel-label text-[13px] font-semibold text-fog-200">Audio Mixer</h2>
          <span className="font-mono text-[9px] text-fog-500">48kHz • 24-BIT</span>
        </header>
        <div className="flex min-h-0 flex-1 items-stretch gap-1.5 overflow-x-auto p-2">
          {m.audio.map((ch) => (
            <Strip key={ch.id} ch={ch} bump={bump} registerMeter={registerMeter} />
          ))}
        </div>

        {/* audio settings — monitor source select + master actions */}
        <div className="flex items-center gap-1.5 border-t border-ink-700 px-2 py-1.5">
          <span className="panel-label flex-none text-[9px] text-fog-500">Monitor</span>
          <select
            className="sel min-w-0 flex-1"
            value={m.audioMonitor}
            onChange={(e) => {
              m.audioMonitor = e.target.value;
              sfx.play("tick");
              log(`Audio monitor → ${m.audio.find((c) => c.id === e.target.value)?.name ?? e.target.value}`, "info");
              bump();
            }}
          >
            {m.audio.map((c) => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
          <button
            onClick={() => {
              const master = m.audio.find((c) => c.kind === "master");
              if (master) {
                master.muted = !master.muted;
                sfx.play(master.muted ? "select" : "tick");
                log(master.muted ? "Master output muted" : "Master output live", master.muted ? "warn" : "ok");
                bump();
              }
            }}
            title="Mute / un-mute master bus"
            className={`btn panel-label flex-none rounded border px-2 py-1 text-[9px] font-semibold ${
              m.audio.find((c) => c.kind === "master")?.muted
                ? "border-prg bg-prg text-white"
                : "border-ink-600 bg-ink-800 text-fog-300 hover:border-amb hover:text-amb"
            }`}
          >
            MASTER
          </button>
        </div>
      </section>

      {/* ------------------------------- stream ------------------------------- */}
      <section className="flex flex-none flex-col rounded-lg border border-ink-700 bg-ink-850">
        <header className="flex items-center justify-between border-b border-ink-700 px-3 py-2">
          <h2 className="panel-label text-[13px] font-semibold text-fog-200">Stream Control</h2>
          <div className="flex items-center gap-1.5">
            {m.live && (
              <span
                className="flex items-center gap-1 rounded-sm bg-ink-700 px-1.5 py-0.5 font-mono text-[9px] text-fog-200"
                title="Concurrent viewers"
              >
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
                  <path d="M2 12s3.5-6.5 10-6.5S22 12 22 12s-3.5 6.5-10 6.5S2 12 2 12z" />
                  <circle cx="12" cy="12" r="2.4" fill="currentColor" stroke="none" />
                </svg>
                {m.viewers}
              </span>
            )}
            <span className={`panel-label rounded-sm px-1.5 py-0.5 text-[9px] font-semibold ${
              m.live ? "anim-lamp bg-prg text-white" : "bg-ink-700 text-fog-400"
            }`}>
              {m.live ? "LIVE" : "IDLE"}
            </span>
          </div>
        </header>

        <div className="space-y-2.5 p-2.5">
          <div className="flex items-center gap-2">
            <button
              onClick={toggleLive}
              className={`btn panel-label flex-1 rounded-md py-2.5 text-[15px] font-bold tracking-wide ${
                m.live
                  ? "bg-prg text-white shadow-[0_0_22px_rgba(255,68,56,0.45)] hover:bg-prg-soft"
                  : "border border-prg/60 bg-prg-dim/40 text-prg hover:bg-prg hover:text-white hover:shadow-[0_0_22px_rgba(255,68,56,0.4)]"
              }`}
            >
              {m.live ? `■ END STREAM ${clock}` : "● GO LIVE"}
            </button>
            <button
              onClick={toggleRec}
              className={`btn panel-label rounded-md border px-3 py-2.5 text-[12px] font-semibold ${
                m.recording
                  ? "border-amb bg-amb text-ink-950 shadow-[0_0_16px_rgba(255,176,32,0.35)]"
                  : "border-ink-600 bg-ink-750 text-fog-200 hover:border-amb hover:text-amb"
              }`}
            >
              {m.recording ? `■ ${recClock}` : "● REC"}
            </button>
          </div>

          {m.recording && (
            <div className="rounded border border-amb/30 bg-amb-dim/25 px-2 py-1.5 font-mono text-[10px] text-amb">
              <div className="flex items-center justify-between">
                <span className="anim-rec">● WRITING</span>
                <span>take_001.{m.recFormat} • {gb.toFixed(2)} GB</span>
              </div>
              <div className="mt-1 truncate text-[9px] text-amb/75" title={`${m.recPath}\\take_001.${m.recFormat}`}>
                → {m.recPath}\take_001.{m.recFormat}
              </div>
            </div>
          )}

          {/* recording output settings */}
          <div className="space-y-1.5 rounded-md border border-ink-700 bg-ink-900/50 p-2">
            <div className="flex items-center gap-1.5">
              <span className="panel-label w-14 flex-none text-[9px] text-fog-500">REC FMT</span>
              <div className="grid flex-1 grid-cols-4 gap-1">
                {REC_FORMATS.map((f) => (
                  <button
                    key={f.v}
                    onClick={() => {
                      m.recFormat = f.v;
                      sfx.play("tick");
                      log(`REC format → ${f.label}`, "info");
                      bump();
                    }}
                    className={`btn panel-label rounded border py-1 text-[10px] ${
                      m.recFormat === f.v
                        ? "border-amb bg-amb/20 text-amb shadow-[0_0_10px_rgba(255,176,32,0.15)]"
                        : "border-ink-600 bg-ink-800 text-fog-400 hover:border-amb/50 hover:text-amb"
                    }`}
                  >
                    {f.label}
                  </button>
                ))}
              </div>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="panel-label w-14 flex-none text-[9px] text-fog-500">Save to</span>
              <input
                defaultValue={m.recPath}
                onChange={(e) => {
                  m.recPath = e.target.value;
                }}
                onBlur={() => log(`REC storage → ${m.recPath}`, "info")}
                spellCheck={false}
                className="min-w-0 flex-1 rounded border border-ink-600 bg-ink-900 px-2 py-1 font-mono text-[9.5px] text-fog-200 focus:border-amb focus:outline-none"
              />
            </div>
          </div>

          <div>
            <div className="mb-1 flex items-baseline justify-between">
              <span className="panel-label text-[10px] text-fog-400">Bitrate</span>
              <span className="font-mono text-[12px] text-amb">
                {(mt.bitrate / 1000).toFixed(2)} <span className="text-[9px] text-fog-500">Mb/s</span>
              </span>
            </div>
            <canvas ref={registerSpark} width={280} height={46} className="h-[46px] w-full rounded border border-ink-700 bg-ink-950" />
          </div>

          <div className="grid grid-cols-3 gap-1.5">
            {[
              ["BUFFER", `${mt.buffer}ms`, mt.buffer > 110 ? "text-amb" : "text-fog-200"],
              ["DROPPED", `${mt.dropped}`, mt.dropped > 0 ? "text-amb" : "text-fog-200"],
              ["JITTER", `${mt.jitter}ms`, "text-fog-200"],
            ].map(([k, v, c]) => (
              <div key={k} className="rounded border border-ink-700 bg-ink-900/60 px-2 py-1.5">
                <div className="panel-label text-[8px] text-fog-500">{k}</div>
                <div className={`font-mono text-[12px] ${c}`}>{v}</div>
              </div>
            ))}
          </div>

          <div className="flex items-center gap-1.5">
            <select
              className="sel flex-1"
              value={m.encoder}
              onChange={(e) => {
                m.encoder = e.target.value;
                sfx.play("tick");
                log(`Encoder → ${encLabel(m.encoder)}`, "info");
                bump();
              }}
            >
              {ENCODERS.map((o) => (
                <option key={o.v} value={o.v}>{o.label}</option>
              ))}
            </select>
            <select
              className="sel flex-1"
              value={m.outputRes}
              onChange={(e) => {
                m.outputRes = e.target.value;
                sfx.play("tick");
                log(`Output format → ${m.outputRes}`, "info");
                bump();
              }}
            >
              {RESOLUTIONS.map((o) => (
                <option key={o.v} value={o.v}>{o.label}</option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-1.5">
            <select
              className="sel w-[46%] flex-none"
              value={m.dest}
              onChange={(e) => {
                m.dest = e.target.value;
                sfx.play("tick");
                log(`Uplink destination → ${destLabel(m.dest)}`, "info");
                bump();
              }}
            >
              {DESTS.map((o) => (
                <option key={o.v} value={o.v}>{o.label}</option>
              ))}
            </select>
            <input
              type="password"
              placeholder="stream key / rtmp url"
              defaultValue={m.streamKey}
              onChange={(e) => {
                m.streamKey = e.target.value;
              }}
              onBlur={() => {
                if (m.streamKey) log("Stream key updated (masked)", "info");
              }}
              className="min-w-0 flex-1 rounded border border-ink-600 bg-ink-900 px-2 py-1 font-mono text-[10px] text-fog-200 placeholder:text-fog-500 focus:border-amb focus:outline-none"
            />
          </div>

          <div className="flex flex-wrap items-center gap-1">
            {["LL-WEBRTC", "GPU COMPOSITE", "ZERO-COPY", "PACING ON"].map((b) => (
              <span key={b} className="rounded-sm border border-ink-600 bg-ink-800 px-1.5 py-0.5 font-mono text-[8px] tracking-wider text-fog-400">
                {b}
              </span>
            ))}
            <span className="ml-auto font-mono text-[8px] text-prv">ANTI-LAG PIPELINE ACTIVE</span>
          </div>
        </div>
      </section>

      {/* ------------------------------- event log ------------------------------- */}
      <section className="flex h-[136px] flex-none flex-col rounded-lg border border-ink-700 bg-ink-850">
        <header className="flex items-center justify-between border-b border-ink-700 px-3 py-1.5">
          <h2 className="panel-label text-[12px] font-semibold text-fog-200">Event Log</h2>
          <span className="font-mono text-[9px] text-fog-500">{m.events.length} MSG</span>
        </header>
        <div className="min-h-0 flex-1 overflow-y-auto p-1">
          {m.events.map((e, i) => (
            <div key={`${e.t}-${i}`} className="flex items-start gap-1.5 rounded px-1.5 py-[3px] font-mono text-[9.5px] transition-colors hover:bg-ink-800">
              <span className="flex-none text-fog-500">{new Date(e.t).toLocaleTimeString([], { hour12: false })}</span>
              <span
                className={`mt-[3px] h-1.5 w-1.5 flex-none rounded-full ${
                  e.kind === "ok" ? "bg-prv" : e.kind === "warn" ? "bg-amb" : "bg-zm"
                }`}
              />
              <span className="min-w-0 flex-1 truncate text-fog-300">{e.msg}</span>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
