import { useEffect, useRef, type MutableRefObject, type PointerEvent as RPointerEvent } from "react";
import { CW, CH, clamp, type StudioModel, type Src } from "../engine/types";
import { viewRect } from "../engine/render";

type DragState =
  | { mode: "move"; id: string; dx: number; dy: number }
  | { mode: "resize"; id: string; handle: "tl" | "t" | "tr" | "r" | "br" | "b" | "bl" | "l" }
  | null;

interface Props {
  kind: "preview" | "program";
  modelRef: MutableRefObject<StudioModel>;
  register: (el: HTMLCanvasElement | null) => void;
  onSelect?: (id: string | null) => void;
  onCommit?: () => void;
  onSnapshot?: () => void;
  onOpenTransform?: () => void;
  registerScreen?: (el: HTMLDivElement | null) => void;
}

export default function Monitor({ kind, modelRef, register, onSelect, onCommit, onSnapshot, onOpenTransform, registerScreen }: Props) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const screenRef = useRef<HTMLDivElement | null>(null);
  const drag = useRef<DragState>(null);
  const isPreview = kind === "preview";

  const toggleFullscreen = () => {
    const el = screenRef.current;
    if (!el) return;
    if (document.fullscreenElement) void document.exitFullscreen();
    else void el.requestFullscreen().catch(() => undefined);
  };

  const toScene = (e: { clientX: number; clientY: number }) => {
    const c = canvasRef.current!;
    const r = c.getBoundingClientRect();
    const fx = c.width / r.width;
    const vr = viewRect(c.width, c.height);
    return {
      x: ((e.clientX - r.left) * fx - vr.ox) / vr.k,
      y: ((e.clientY - r.top) * fx - vr.oy) / vr.k,
    };
  };

  const hitTest = (sx: number, sy: number) => {
    const m = modelRef.current;
    const scene = m.scenes.find((s) => s.id === m.previewId);
    if (!scene) return null;
    for (let i = scene.sources.length - 1; i >= 0; i--) {
      const s = scene.sources[i];
      if (sx >= s.x && sx <= s.x + s.w && sy >= s.y && sy <= s.y + s.h) return s;
    }
    return null;
  };

  const handleAt = (sx: number, sy: number, s: Src): DragState => {
    const c = canvasRef.current;
    const k = c ? viewRect(c.width, c.height).k : 1;
    const tol = 18 / Math.max(k, 0.001);
    const pts: [number, number, "tl" | "t" | "tr" | "r" | "br" | "b" | "bl" | "l"][] = [
      [s.x, s.y, "tl"], [s.x + s.w / 2, s.y, "t"], [s.x + s.w, s.y, "tr"],
      [s.x + s.w, s.y + s.h / 2, "r"], [s.x + s.w, s.y + s.h, "br"],
      [s.x + s.w / 2, s.y + s.h, "b"], [s.x, s.y + s.h, "bl"], [s.x, s.y + s.h / 2, "l"],
    ];
    for (const [px, py, handle] of pts) {
      if (Math.abs(sx - px) < tol && Math.abs(sy - py) < tol) return { mode: "resize", id: s.id, handle };
    }
    return null;
  };

  const onDown = (e: RPointerEvent<HTMLCanvasElement>) => {
    if (!isPreview) return;
    const p = toScene(e);
    const m = modelRef.current;
    const sel = m.selectedId
      ? m.scenes.find((s) => s.id === m.previewId)?.sources.find((s) => s.id === m.selectedId)
      : undefined;
    if (sel) {
      const c = handleAt(p.x, p.y, sel);
      if (c) {
        drag.current = c;
        (e.target as HTMLElement).setPointerCapture(e.pointerId);
        return;
      }
    }
    const hit = hitTest(p.x, p.y);
    if (hit) {
      drag.current = { mode: "move", id: hit.id, dx: p.x - hit.x, dy: p.y - hit.y };
      onSelect?.(hit.id);
    } else {
      onSelect?.(null);
    }
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  };

  const onMove = (e: RPointerEvent<HTMLCanvasElement>) => {
    if (!isPreview) return;
    const p = toScene(e);
    const d = drag.current;
    const c = canvasRef.current;
    if (!d) {
      // hover cursor
      const m = modelRef.current;
      const sel = m.selectedId
        ? m.scenes.find((s) => s.id === m.previewId)?.sources.find((s) => s.id === m.selectedId)
        : undefined;
      let cursor = "default";
      const h = sel && handleAt(p.x, p.y, sel);
      if (h?.mode === "resize") {
        cursor = h.handle === "l" || h.handle === "r" ? "ew-resize"
          : h.handle === "t" || h.handle === "b" ? "ns-resize"
          : h.handle === "tl" || h.handle === "br" ? "nwse-resize" : "nesw-resize";
      }
      else if (hitTest(p.x, p.y)) cursor = "move";
      if (c) c.style.cursor = cursor;
      return;
    }
    const scene = modelRef.current.scenes.find((s) => s.id === modelRef.current.previewId);
    const s = scene?.sources.find((s) => s.id === d.id);
    if (!s) return;
    const ratio = s.bw / s.bh;
    if (d.mode === "move") {
      s.x = Math.round(clamp(p.x - d.dx, -s.w + 80, CW - 80));
      s.y = Math.round(clamp(p.y - d.dy, -s.h + 60, CH - 60));
    } else {
      const minW = 120;
      const minH = 80;
      const right = s.x + s.w;
      const bottom = s.y + s.h;
      if (d.handle === "br") {
        s.w = Math.round(clamp(p.x - s.x, 120, CW * 1.6));
        s.h = Math.round(s.w / ratio);
      } else if (d.handle === "tl") {
        s.w = Math.round(clamp(right - p.x, 120, CW * 1.6));
        s.h = Math.round(s.w / ratio);
        s.x = Math.round(right - s.w);
        s.y = Math.round(bottom - s.h);
      } else if (d.handle === "tr") {
        s.w = Math.round(clamp(p.x - s.x, 120, CW * 1.6));
        s.h = Math.round(s.w / ratio);
        s.y = Math.round(bottom - s.h);
      } else if (d.handle === "bl") {
        s.w = Math.round(clamp(right - p.x, 120, CW * 1.6));
        s.h = Math.round(s.w / ratio);
        s.x = Math.round(right - s.w);
      } else if (d.handle === "r") {
        s.w = Math.round(clamp(p.x - s.x, minW, CW * 1.8));
      } else if (d.handle === "l") {
        s.w = Math.round(clamp(right - p.x, minW, CW * 1.8));
        s.x = Math.round(right - s.w);
      } else if (d.handle === "b") {
        s.h = Math.round(clamp(p.y - s.y, minH, CH * 1.8));
      } else if (d.handle === "t") {
        s.h = Math.round(clamp(bottom - p.y, minH, CH * 1.8));
        s.y = Math.round(bottom - s.h);
      }
    }
  };

  const onUp = () => {
    if (drag.current) {
      drag.current = null;
      onCommit?.();
    }
  };

  // wheel = digital zoom on the selected source (non-passive)
  useEffect(() => {
    const c = canvasRef.current;
    if (!c || !isPreview) return;
    const onWheel = (e: WheelEvent) => {
      const m = modelRef.current;
      const scene = m.scenes.find((s) => s.id === m.previewId);
      const s = scene?.sources.find((s) => s.id === m.selectedId);
      if (!s) return;
      e.preventDefault();
      const f = e.deltaY < 0 ? 1.07 : 0.935;
      const nw = clamp(s.w * f, 120, CW * 1.8);
      const ratio = s.bw / s.bh;
      const cx = s.x + s.w / 2, cy = s.y + s.h / 2;
      s.w = Math.round(nw);
      s.h = Math.round(nw / ratio);
      s.x = Math.round(cx - s.w / 2);
      s.y = Math.round(cy - s.h / 2);
      onCommit?.();
    };
    c.addEventListener("wheel", onWheel, { passive: false });
    return () => c.removeEventListener("wheel", onWheel);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isPreview]);

  return (
    <div className="flex h-full min-w-0 flex-1 flex-col">
      <div
        ref={(el) => {
          screenRef.current = el;
          registerScreen?.(el);
        }}
        onDoubleClick={() => (isPreview ? onOpenTransform?.() : toggleFullscreen())}
        onContextMenu={(e) => e.preventDefault()}
        title={isPreview ? "Double-click source transform" : "Double-click fullscreen"}
        className="relative min-h-0 flex-1 overflow-hidden border border-[#555] bg-black"
      >
        <canvas
          ref={(el) => {
            canvasRef.current = el;
            register(el);
          }}
          className={`h-full w-full ${isPreview ? "touch-none" : ""}`}
          onPointerDown={onDown}
          onPointerMove={onMove}
          onPointerUp={onUp}
          onPointerCancel={onUp}
        />
        {isPreview && (
          <div className="pointer-events-none absolute bottom-1 left-2 text-[10px] text-[#777]">
            drag · resize · wheel zoom · dbl-click properties
          </div>
        )}
        {!isPreview && onSnapshot && (
          <button
            onClick={onSnapshot}
            className="absolute right-2 top-2 rounded bg-black/60 px-2 py-0.5 text-[10px] text-[#ccc] hover:bg-black/80"
          >
            Snap
          </button>
        )}
      </div>
    </div>
  );
}
