import { useEffect, useRef, useState, type MutableRefObject } from "react";
import { AudioLines, BookOpen, Music, Pause, Play, Plus, Settings, Users, Video, X } from "lucide-react";
import { type StudioModel, type Src } from "../engine/types";
import { drawScene } from "../engine/render";
import { sfx } from "../engine/sfx";
import { assets } from "../engine/assets";

interface Props {
  modelRef: MutableRefObject<StudioModel>;
  bump: () => void;
  log: (msg: string, kind?: "info" | "ok" | "warn") => void;
  setPreview: (id: string) => void;
  onSelect: (id: string | null) => void;
  auto: () => void;
  cut: () => void;
  ftbToggle: () => void;
  toggleLive: () => void;
  toggleRec: () => void;
  registerMeter: (id: string, el: HTMLCanvasElement | null) => void;
  openAddSource: () => void;
  openProperties: (id: string) => void;
  openSettings: () => void;
  openZoom: () => void;
  focusMeeting: () => void;
  openTransform: (id: string) => void;
  onOpenAudioIO: (channelId: string) => void;
  onAddScene: () => void;
  onOpenBibleFinder: () => void;
  onOpenWorshipFinder: () => void;
}

function Fader({ ch, registerMeter, bump, onOpenIO }: {
  ch: StudioModel["audio"][number];
  registerMeter: (id: string, el: HTMLCanvasElement | null) => void;
  bump: () => void;
  onOpenIO: (id: string) => void;
}) {
  const trackRef = useRef<HTMLDivElement | null>(null);
  const dragging = useRef(false);
  const [vol, setVol] = useState(ch.volume);
  useEffect(() => setVol(ch.volume), [ch.volume]);
  const setFromY = (clientY: number) => {
    const t = trackRef.current; if (!t) return;
    const r = t.getBoundingClientRect();
    const v = Math.round(Math.min(1, Math.max(0, 1 - (clientY - r.top) / r.height)) * 100);
    ch.volume = v; setVol(v);
  };
  return (
    <div onDoubleClick={() => onOpenIO(ch.id)} title={`${ch.name} — double-click for I/O`}
      className="flex w-[72px] flex-none cursor-pointer flex-col items-center gap-1 rounded border border-[#26272b] bg-[#202124] px-1.5 py-1.5">
      <div className="w-full truncate text-center text-[10px] text-[#c8c8c8]">{ch.name}</div>
      <div className="flex items-end gap-1">
        <canvas ref={(el) => registerMeter(ch.id, el)} width={10} height={86} className="h-[86px] w-2.5 rounded-sm bg-[#121212]" />
        <div ref={trackRef}
          onPointerDown={(e) => { dragging.current = true; (e.target as HTMLElement).setPointerCapture(e.pointerId); setFromY(e.clientY); }}
          onPointerMove={(e) => { if (dragging.current) setFromY(e.clientY); }}
          onPointerUp={() => { if (dragging.current) { dragging.current = false; bump(); } }}
          className="relative h-[86px] w-3 cursor-ns-resize rounded-sm bg-[#121212]">
          <div className="absolute inset-x-0 bottom-0 bg-[#3d8bfd]" style={{ height: `${vol}%` }} />
          <div className="absolute left-1/2 h-2.5 w-4 -translate-x-1/2 rounded-sm bg-[#d0d0d0]" style={{ bottom: `calc(${vol}% - 5px)` }} />
        </div>
      </div>
      <button onClick={() => { ch.muted = !ch.muted; bump(); }}
        className={`rounded px-2 py-0.5 text-[9px] ${ch.muted ? "bg-[#e5484d] text-white" : "bg-[#2a2b2f] text-[#c8c8c8]"}`}>
        {ch.muted ? "MUTE" : "LIVE"}
      </button>
    </div>
  );
}

export default function ObsDock(p: Props) {
  const { modelRef, bump, log, setPreview, auto, cut, ftbToggle, toggleLive, toggleRec, registerMeter, openAddSource, openProperties, openSettings, openZoom, focusMeeting, openTransform, onOpenAudioIO, onAddScene, onOpenBibleFinder, onOpenWorshipFinder } = p;
  const m = modelRef.current;
  const scene = m.scenes.find((s) => s.id === m.previewId);
  const sources = scene?.sources ?? [];

  /* overlay slots */
  const toggleOverlay = (slot: number, id: string) => {
    m.overlays[slot] = m.overlays[slot] === id ? null : id;
    sfx.play("tick");
    const src = sources.find((s) => s.id === id);
    if (m.overlays[slot]) log(`Overlay ${slot + 1} ON — ${src?.name ?? ""} added over Program`, "ok");
    else log(`Overlay ${slot + 1} OFF`, "info");
    bump();
  };

  /* live input thumbnails */
  const thumbRefs = useRef(new Map<string, HTMLCanvasElement | null>());
  useEffect(() => {
    let raf = 0;
    const loop = () => {
      const mm = modelRef.current;
      const t = performance.now() / 1000;
      const conn = mm.zoom.phase === "connected";
      for (const sc of mm.scenes) {
        for (const s of sc.sources) {
          const cv = thumbRefs.current.get(s.id);
          if (!cv) continue;
          const ctx = cv.getContext("2d");
          if (!ctx) continue;
          drawScene(ctx, { id: "thumb", name: "", sources: [s] }, cv.width, cv.height, t, mm.zoom.participants, conn);
        }
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [modelRef]);

  const audioChannels = m.audio.slice(0, 2);

  return (
    <div className="flex flex-none flex-col gap-1 border-t border-[#1a1a1a] bg-[#1d1e21] p-1.5">
      {/* ── upper band: scenes · sources · audio · transitions · controls ── */}
      <div className="flex gap-1.5" style={{ height: 168 }}>
        {/* SCENES — big boxes */}
        <div className="flex min-w-0 flex-1 flex-col rounded border border-[#26272b] bg-[#202124]">
          <div className="flex items-center justify-between border-b border-[#26272b] px-2 py-1">
            <span className="text-[11px] font-semibold tracking-wide text-[#c8c8c8]">SCENES</span>
            <div className="flex items-center gap-1.5">
              <span className="text-[9px] text-[#7d838a]">click = preview · dbl-click = program</span>
              <button onClick={onAddScene} title="Add a new scene"
                className="flex h-5 w-5 items-center justify-center rounded bg-[#2a2b2f] text-[#9fc0ea] hover:bg-[#3d6ea8] hover:text-white">
                <Plus className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
          <div className="flex min-h-0 flex-1 gap-1.5 overflow-x-auto p-1.5">
            {m.scenes.map((sc) => {
              const isPv = m.previewId === sc.id;
              const isPg = m.programId === sc.id;
              return (
                <button key={sc.id}
                  onClick={() => setPreview(sc.id)}
                  onDoubleClick={() => { setPreview(sc.id); cut(); }}
                  className={`relative flex w-[150px] flex-none flex-col justify-end overflow-hidden rounded border p-2 text-left transition-colors ${
                    isPg ? "border-[#e5484d]" : isPv ? "border-[#31c48d]" : "border-[#2e2f33] hover:border-[#4a4b50]"
                  }`}
                  style={{ background: "linear-gradient(150deg,#2a2b30,#1b1c20)" }}>
                  <span className="panel-label pointer-events-none absolute left-2 top-1.5 text-[16px] font-bold text-white/10">
                    {String(m.scenes.indexOf(sc) + 1).padStart(2, "0")}
                  </span>
                  {isPg && <span className="absolute right-1.5 top-1.5 rounded bg-[#e5484d] px-1.5 py-px text-[8px] font-bold text-white">PGM</span>}
                  {isPv && !isPg && <span className="absolute right-1.5 top-1.5 rounded bg-[#31c48d] px-1.5 py-px text-[8px] font-bold text-[#06130b]">PRV</span>}
                  <span className="truncate text-[12px] font-semibold text-[#e8e8e8]">{sc.name}</span>
                  <span className="text-[9px] text-[#7d838a]">{sc.sources.length} source{sc.sources.length === 1 ? "" : "s"}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* AUDIO — two faders */}
        <div className="flex flex-none flex-col rounded border border-[#26272b] bg-[#202124]">
          <div className="flex items-center justify-between border-b border-[#26272b] px-2 py-1">
            <span className="flex items-center gap-1 text-[11px] font-semibold text-[#c8c8c8]"><AudioLines className="h-3 w-3" /> AUDIO</span>
          </div>
          <div className="flex min-h-0 flex-1 items-stretch gap-1.5 p-1.5">
            {audioChannels.map((ch) => (
              <Fader key={ch.id} ch={ch} registerMeter={registerMeter} bump={bump} onOpenIO={onOpenAudioIO} />
            ))}
          </div>
        </div>

        {/* TRANSITIONS */}
        <div className="flex w-[118px] flex-none flex-col rounded border border-[#26272b] bg-[#202124]">
          <div className="border-b border-[#26272b] px-2 py-1 text-[11px] font-semibold text-[#c8c8c8]">TRANSITION</div>
          <div className="flex min-h-0 flex-1 flex-col gap-1 p-1.5">
            <button onClick={cut} className="rounded bg-[#2a2b2f] py-1.5 text-[11px] text-[#e8e8e8] hover:bg-[#3a3b40]">Cut</button>
            <button onClick={auto} className="rounded bg-[#2a2b2f] py-1.5 text-[11px] text-[#e8e8e8] hover:bg-[#3a3b40]">Auto ({m.transDur}ms)</button>
            <button onClick={ftbToggle} className={`rounded py-1.5 text-[11px] ${m.ftb.target === 1 ? "bg-[#ffb020] text-[#1a1206]" : "bg-[#2a2b2f] text-[#e8e8e8] hover:bg-[#3a3b40]"}`}>FTB</button>
            <div className="mt-auto text-center text-[9px] text-[#7d838a]">T-bar on Program monitor</div>
          </div>
        </div>

        {/* CONTROLS */}
        <div className="flex w-[172px] flex-none flex-col rounded border border-[#26272b] bg-[#202124]">
          <div className="border-b border-[#26272b] px-2 py-1 text-[11px] font-semibold text-[#c8c8c8]">CONTROLS</div>
          <div className="flex min-h-0 flex-1 flex-col gap-1.5 p-1.5">
            <button onClick={toggleLive} className={`flex items-center justify-center gap-2 rounded py-2 text-[12px] font-medium ${m.live ? "bg-[#e5484d] text-white" : "bg-[#2a2b2f] text-[#e8e8e8] hover:bg-[#3a3b40]"}`}>
              {m.live ? "Stop Streaming" : "Start Streaming"}
            </button>
            <button onClick={toggleRec} className={`flex items-center justify-center gap-2 rounded py-2 text-[12px] font-medium ${m.recording ? "bg-[#ffb020] text-[#1a1206]" : "bg-[#2a2b2f] text-[#e8e8e8] hover:bg-[#3a3b40]"}`}>
              {m.recording ? "Stop Recording" : "Start Recording"}
            </button>
            <button onClick={() => (m.zoom.phase === "connected" ? focusMeeting() : openZoom())}
              className={`flex items-center justify-center gap-2 rounded py-2 text-[12px] font-medium ${m.zoom.phase === "connected" ? "bg-[#2f6b45] text-white" : "bg-[#2a2b2f] text-[#e8e8e8] hover:bg-[#3a3b40]"}`}>
              {m.zoom.phase === "connected" ? <Users className="h-3.5 w-3.5" /> : <Video className="h-3.5 w-3.5" />}
              {m.zoom.phase === "connected" ? "Open Meeting" : "Connect Zoom"}
            </button>
            <button onClick={openSettings} className="flex items-center justify-center gap-2 rounded bg-[#2a2b2f] py-2 text-[12px] font-medium text-[#e8e8e8] hover:bg-[#3a3b40]">
              <Settings className="h-3.5 w-3.5" /> Settings
            </button>
          </div>
        </div>
      </div>

      {/* ── vMix input strip — big live boxes with overlays ── */}
      <div className="flex gap-1.5 overflow-x-auto" style={{ height: 150 }}>
        <button onClick={openAddSource}
          className="flex w-[92px] flex-none flex-col items-center justify-center gap-1.5 rounded border border-dashed border-[#3a3b40] text-[#7d838a] transition-colors hover:border-[#3d6ea8] hover:text-[#9fc0ea]">
          <Plus className="h-5 w-5" />
          <span className="text-[10px] font-medium">Add Input</span>
        </button>

        {sources.map((s) => (
          <InputBox key={s.id} s={s} overlays={m.overlays} onOverlay={toggleOverlay}
            registerThumb={(el) => { thumbRefs.current.set(s.id, el); }}
            onOpenProps={() => openProperties(s.id)}
            onTransform={() => openTransform(s.id)}
            onPlay={() => { s.playing = s.playing === false ? true : false; bump(); }}
            onClose={() => {
              if (s.assetId) assets.remove(s.assetId);
              if (scene) scene.sources = scene.sources.filter((x) => x.id !== s.id);
              m.overlays = m.overlays.map((o) => (o === s.id ? null : o));
              if (m.selectedId === s.id) m.selectedId = null;
              sfx.play("select");
              log(`Input removed — ${s.name}`, "info");
              bump();
            }}
          />
        ))}
      </div>

      <div className="flex items-stretch gap-1.5">
        <button onClick={onOpenBibleFinder} title="Open Verse Finder — type a reference manually, step verse by verse"
          className="flex flex-1 items-center justify-center gap-1.5 rounded border border-[#26272b] bg-[#202124] px-3 py-1.5 text-[11px] font-semibold text-[#d4a437] transition-colors hover:border-[#d4a437] hover:bg-[#2a2415]">
          <BookOpen className="h-3.5 w-3.5" /> Verse Finder
        </button>
        <button onClick={onOpenWorshipFinder} title="Open Praise & Worship finder — search lyrics, lower-third or full-screen"
          className="flex flex-1 items-center justify-center gap-1.5 rounded border border-[#26272b] bg-[#202124] px-3 py-1.5 text-[11px] font-semibold text-[#7fb2ff] transition-colors hover:border-[#7fb2ff] hover:bg-[#16202b]">
          <Music className="h-3.5 w-3.5" /> Praise & Worship
        </button>
      </div>
    </div>
  );
}

function InputBox({ s, overlays, onOverlay, registerThumb, onOpenProps, onTransform, onPlay, onClose }: {
  s: Src;
  overlays: (string | null)[];
  onOverlay: (slot: number, id: string) => void;
  registerThumb: (el: HTMLCanvasElement | null) => void;
  onOpenProps: () => void;
  onTransform: () => void;
  onPlay: () => void;
  onClose: () => void;
}) {
  return (
    <div className="group relative flex w-[236px] flex-none flex-col overflow-hidden rounded border border-[#2e2f33] bg-[#17181b] transition-colors hover:border-[#4a4b50]">
      <div className="relative min-h-0 flex-1 cursor-pointer" onDoubleClick={onOpenProps} title="Double-click for properties">
        <canvas ref={registerThumb} width={320} height={180} className="h-full w-full object-cover" />
        {!s.visible && <div className="absolute inset-0 grid place-items-center bg-black/60 text-[10px] tracking-widest text-[#7d838a]">HIDDEN</div>}
        <span className="absolute left-1 top-1 max-w-[70%] truncate rounded bg-black/60 px-1.5 py-px text-[9px] text-[#e8e8e8]">{s.name}</span>
      </div>
      <div className="flex items-center gap-1 border-t border-[#26272b] bg-[#202124] px-1.5 py-1">
        {[0, 1, 2, 3].map((i) => (
          <button key={i} onClick={() => onOverlay(i, s.id)}
            title={`Overlay ${i + 1}: ${overlays[i] === s.id ? "remove from Program" : "add over Program"}`}
            className={`h-5 w-5 rounded text-[10px] font-bold transition-colors ${
              overlays[i] === s.id ? "bg-[#31c48d] text-[#06130b]" : "bg-[#2a2b2f] text-[#9aa0a6] hover:bg-[#3a3b40]"
            }`}>
            {i + 1}
          </button>
        ))}
        <span className="flex-1" />
        <button onClick={onTransform} title="Crop / zoom / angle" className="rounded px-1 py-0.5 text-[9px] text-[#9aa0a6] hover:bg-[#3a3b40] hover:text-white">Xform</button>
        <button onClick={onPlay} title={s.playing === false ? "Play" : "Pause"} className="rounded p-0.5 text-[#9aa0a6] hover:bg-[#3a3b40] hover:text-white">
          {s.playing === false ? <Play className="h-3.5 w-3.5" /> : <Pause className="h-3.5 w-3.5" />}
        </button>
        <button onClick={onClose} title="Remove input" className="rounded p-0.5 text-[#9aa0a6] hover:bg-[#4a2a2a] hover:text-[#ff8a8a]">
          <X className="h-3.5 w-3.5" />
        </button>
      </div>
    </div>
  );
}


