import { SOURCE_META, type SourceType } from "../engine/types";

interface Props {
  onPick: (type: SourceType) => void;
  onClose: () => void;
}

const GROUPS: { title: string; items: SourceType[] }[] = [
  { title: "Capture", items: ["live-cam", "camera", "display", "browser", "ndi"] },
  { title: "Media", items: ["image-file", "video-file", "media", "image"] },
  { title: "Graphics", items: ["text", "gt", "stinger", "color"] },
  { title: "Scripture", items: ["bible"] },
  { title: "Zoom", items: ["zoom-grid", "zoom-guest"] },
];

const HINTS: Partial<Record<SourceType, string>> = {
  "live-cam": "Real webcams & capture cards on this PC",
  camera: "Network camera on your WiFi/LAN (MJPEG / HLS / MP4)",
  display: "Monitor or specific window",
  browser: "Load a web page (URL, custom CSS)",
  "image-file": "Browse a JPG / PNG / WebP file",
  "video-file": "Browse a MP4 / WebM / MOV file",
  media: "Generated media placeholder",
  image: "Generated broadcast still",
  text: "Font, size, colour, drop shadow",
  color: "Solid colour backdrop",
  "zoom-grid": "Gallery of all participants",
  "zoom-guest": "Single Zoom participant tile",
  ndi: "Receive an NDI feed over the network",
  gt: "Broadcast graphics title template",
  stinger: "Animated text transition overlay",
  bible: "Scripture lower-third (offline KJV)",
};

export default function AddSourceMenu({ onPick, onClose }: Props) {
  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/60 p-4" onClick={onClose} onContextMenu={(e) => e.preventDefault()}>
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-[480px] max-h-[80vh] overflow-hidden rounded-lg border border-[#111] bg-[#252525] shadow-2xl"
      >
        <div className="flex items-center justify-between border-b border-[#1a1a1a] bg-[#2b2b2b] px-4 py-2.5">
          <div className="text-[14px] font-semibold text-[#f0f0f0]">Add Source</div>
          <button onClick={onClose} className="rounded px-2 py-0.5 text-[11px] text-[#c8c8c8] hover:bg-[#3a3a3a]">ESC</button>
        </div>

        <div className="max-h-[62vh] overflow-y-auto p-3">
          {GROUPS.map((g) => (
            <div key={g.title} className="mb-3 last:mb-0">
              <div className="mb-1.5 text-[10px] uppercase tracking-widest text-[#8a8a8a]">{g.title}</div>
              <div className="space-y-1">
                {g.items.map((t) => {
                  const meta = SOURCE_META.find((x) => x.type === t);
                  return (
                    <button
                      key={t}
                      onClick={() => onPick(t)}
                      className="flex w-full items-center justify-between rounded border border-[#111] bg-[#2b2b2b] px-3 py-2 text-left hover:border-[#3d6ea8] hover:bg-[#2a3a55]"
                    >
                      <div className="min-w-0">
                        <div className="text-[12px] font-medium text-[#e8e8e8]">{meta?.label ?? t}</div>
                        <div className="truncate text-[10px] text-[#9a9a9a]">{HINTS[t]}</div>
                      </div>
                      <span className="text-[12px] text-[#3d6ea8]">▸</span>
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
