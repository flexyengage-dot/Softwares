import { useEffect, useRef, useState } from "react";
import { KeyRound, Mic, MicOff, Video, VideoOff, Users } from "lucide-react";

interface Props {
  initialUser: string;
  initialMeeting: string;
  onJoin: (p: { meetingId: string; user: string; deviceId: string; useVideo: boolean; useAudio: boolean }) => void;
  onClose: () => void;
}

const STEPS = ["Meeting", "Your name", "Passcode", "Preview"];

export default function ZoomDialog({ initialUser, initialMeeting, onJoin, onClose }: Props) {
  const [step, setStep] = useState(0);
  const [meetingId, setMeetingId] = useState(initialMeeting || "");
  const [user, setUser] = useState(initialUser || "");
  const [pass, setPass] = useState("");
  const [useVideo, setUseVideo] = useState(true);
  const [useAudio, setUseAudio] = useState(true);
  const [devices, setDevices] = useState<MediaDeviceInfo[]>([]);
  const [deviceId, setDeviceId] = useState("");
  const [camError, setCamError] = useState("");
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const stopPreview = () => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    if (videoRef.current) videoRef.current.srcObject = null;
  };

  const startPreview = async (id?: string) => {
    stopPreview();
    setCamError("");
    if (!navigator.mediaDevices?.getUserMedia) {
      setCamError("Camera API unavailable in this browser.");
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: id ? { deviceId: id } : true,
        audio: false,
      });
      streamRef.current = stream;
      if (videoRef.current) videoRef.current.srcObject = stream;
    } catch {
      setErrorSafe();
    }
  };

  const setErrorSafe = () => {
    setCamError("Camera unavailable or permission denied — you can still join without video.");
    setUseVideo(false);
  };

  /* enter preview step: enumerate cameras + start feed */
  useEffect(() => {
    if (step !== 3) {
      stopPreview();
      return;
    }
    let alive = true;
    navigator.mediaDevices
      ?.enumerateDevices()
      .then((all) => {
        if (!alive) return;
        const cams = all.filter((d) => d.kind === "videoinput");
        setDevices(cams);
        const first = cams[0]?.deviceId ?? "";
        if (!deviceId && first) setDeviceId(first);
        void startPreview(deviceId || first || undefined);
      })
      .catch(() => setErrorSafe());
    return () => {
      alive = false;
      stopPreview();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [step]);

  useEffect(() => () => stopPreview(), []);

  const digits = meetingId.replace(/\D/g, "");
  const canNext =
    step === 0 ? digits.length >= 6 : step === 1 ? user.trim().length >= 2 : step === 2 ? pass.trim().length >= 1 : true;

  const next = () => {
    if (!canNext) return;
    setStep((s) => Math.min(3, s + 1));
  };

  const changeDevice = (id: string) => {
    setDeviceId(id);
    void startPreview(id);
  };

  const join = () => {
    stopPreview();
    onJoin({ meetingId: digits, user: user.trim(), deviceId, useVideo, useAudio });
  };

  const input =
    "w-full rounded border border-[#111] bg-[#2b2b2b] px-3 py-2 text-[13px] text-[#e8e8e8] placeholder:text-[#5c6b80] focus:border-[#2d8cff] focus:outline-none";

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/65 p-4" onClick={onClose} onContextMenu={(e) => e.preventDefault()}>
      <div onClick={(e) => e.stopPropagation()} className="w-[480px] overflow-hidden rounded-lg border border-[#111] bg-[#252525] shadow-2xl">
        {/* header */}
        <div className="flex items-center gap-2.5 border-b border-[#1a1a1a] bg-[#2b2b2b] px-4 py-2.5">
          <span className="flex h-7 w-7 flex-none items-center justify-center rounded bg-[#2d8cff] text-[12px] font-bold text-white">Z</span>
          <div>
            <div className="text-[13px] font-semibold text-[#f0f0f0]">Join Meeting</div>
            <div className="text-[10px] text-[#8a8a8a]">No sign-in required — enter the meeting details</div>
          </div>
          <button onClick={onClose} className="ml-auto rounded px-2 py-0.5 text-[11px] text-[#c8c8c8] hover:bg-[#3a3a3a]">Close</button>
        </div>

        {/* step rail */}
        <div className="flex items-center gap-1 border-b border-[#1a1a1a] bg-[#202124] px-4 py-2">
          {STEPS.map((s, i) => (
            <div key={s} className="flex flex-1 items-center gap-1.5">
              <span className={`grid h-5 w-5 flex-none place-items-center rounded-full text-[10px] font-bold ${i < step ? "bg-[#31c48d] text-[#06130b]" : i === step ? "bg-[#2d8cff] text-white" : "bg-[#3a3b40] text-[#9aa0a6]"}`}>
                {i < step ? "✓" : i + 1}
              </span>
              <span className={`truncate text-[10px] ${i === step ? "text-[#e8e8e8]" : "text-[#7d838a]"}`}>{s}</span>
              {i < STEPS.length - 1 && <span className="h-px flex-1 bg-[#3a3b40]" />}
            </div>
          ))}
        </div>

        <div className="px-5 py-4">
          {step === 0 && (
            <div className="space-y-2">
              <label className="block text-[11px] text-[#c8c8c8]">Meeting ID or personal link name</label>
              <input autoFocus value={meetingId} onChange={(e) => setMeetingId(e.target.value)} placeholder="e.g. 894 2210 7731" className={input} />
              {meetingId && digits.length < 6 && <div className="text-[10px] text-[#d0a85a]">Enter at least 6 digits.</div>}
            </div>
          )}

          {step === 1 && (
            <div className="space-y-2">
              <label className="flex items-center gap-1.5 text-[11px] text-[#c8c8c8]"><Users className="h-3.5 w-3.5 text-[#2d8cff]" /> Your display name</label>
              <input autoFocus value={user} onChange={(e) => setUser(e.target.value)} placeholder="How others will see you" className={input} />
            </div>
          )}

          {step === 2 && (
            <div className="space-y-2">
              <label className="flex items-center gap-1.5 text-[11px] text-[#c8c8c8]"><KeyRound className="h-3.5 w-3.5 text-[#2d8cff]" /> Meeting passcode</label>
              <input autoFocus type="password" value={pass} onChange={(e) => setPass(e.target.value)} placeholder="Enter passcode" className={input} onKeyDown={(e) => { if (e.key === "Enter") next(); }} />
            </div>
          )}

          {step === 3 && (
            <div className="space-y-3">
              <div className="relative overflow-hidden rounded border border-[#111] bg-black" style={{ aspectRatio: "16/9" }}>
                <video ref={videoRef} autoPlay muted playsInline className={`h-full w-full object-cover ${useVideo ? "" : "hidden"}`} />
                {!useVideo && (
                  <div className="absolute inset-0 grid place-items-center">
                    <div className="grid h-16 w-16 place-items-center rounded-full bg-[#3b6fd4] text-[20px] font-bold text-white">
                      {(user.trim() || "H").slice(0, 1).toUpperCase()}
                    </div>
                  </div>
                )}
                {camError && <div className="absolute inset-x-0 bottom-0 bg-black/70 px-3 py-1.5 text-[10px] text-[#d0a85a]">{camError}</div>}
              </div>

              <div className="flex items-center gap-2">
                <button onClick={() => setUseAudio((v) => !v)} className={`flex flex-1 items-center justify-center gap-2 rounded py-2 text-[12px] ${useAudio ? "bg-[#2a2b2f] text-[#e8e8e8]" : "bg-[#e5484d] text-white"}`}>
                  {useAudio ? <Mic className="h-4 w-4" /> : <MicOff className="h-4 w-4" />} {useAudio ? "Audio on" : "Audio off"}
                </button>
                <button onClick={() => setUseVideo((v) => !v)} className={`flex flex-1 items-center justify-center gap-2 rounded py-2 text-[12px] ${useVideo ? "bg-[#2a2b2f] text-[#e8e8e8]" : "bg-[#e5484d] text-white"}`}>
                  {useVideo ? <Video className="h-4 w-4" /> : <VideoOff className="h-4 w-4" />} {useVideo ? "Video on" : "Video off"}
                </button>
              </div>

              <label className="block">
                <span className="mb-1 block text-[10px] text-[#8a8a8a]">Camera</span>
                <select value={deviceId} onChange={(e) => changeDevice(e.target.value)} className={input}>
                  {devices.length === 0 && <option value="">Default camera</option>}
                  {devices.map((d) => (
                    <option key={d.deviceId} value={d.deviceId}>{d.label || `Camera ${d.deviceId.slice(0, 6)}`}</option>
                  ))}
                </select>
              </label>
            </div>
          )}
        </div>

        {/* footer */}
        <div className="flex items-center justify-between gap-2 border-t border-[#1a1a1a] bg-[#2b2b2b] px-4 py-2.5">
          {step > 0 ? (
            <button onClick={() => setStep((s) => s - 1)} className="rounded border border-[#111] bg-[#3a3a3a] px-4 py-1.5 text-[12px] text-white hover:bg-[#4a4a4a]">Back</button>
          ) : <span />}
          {step < 3 ? (
            <button onClick={next} disabled={!canNext} className="rounded bg-[#2d8cff] px-5 py-1.5 text-[12px] font-semibold text-white hover:bg-[#3b97ff] disabled:cursor-not-allowed disabled:opacity-40">Continue</button>
          ) : (
            <button onClick={join} className="rounded bg-[#31c48d] px-6 py-1.5 text-[12px] font-bold text-[#06130b] hover:bg-[#3fd59c]">Join Meeting</button>
          )}
        </div>
      </div>
    </div>
  );
}
