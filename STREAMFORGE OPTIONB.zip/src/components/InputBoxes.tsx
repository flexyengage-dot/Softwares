import { useEffect, useRef, type MutableRefObject } from "react";
import { CW, CH, type SceneDef, type Src, type StudioModel } from "../engine/types";
import { drawScene } from "../engine/render";
import { assets } from "../engine/assets";
import { sfx } from "../engine/sfx";

interface Props {
  modelRef: MutableRefObject<StudioModel>;
  bump: () => void;
  onSelect: (id: string | null) => void;
  onRemoveSource: (id: string) => void;
}

/**
 * vMix-style input tiles. Always shows at least two "slots"; filled slots
 * carry live thumbnails plus transport (loop / play-pause / audio) and a
 * close button that clears only that input — the slot stays.
 */
export default function InputBoxes({ modelRef, bump, onSelect, onRemoveSource }: Props) {
  const m = modelRef.current;
  const scene = m.scenes.find((s) => s.id === m.previewId)!;
  const sources = scene.sources;
  const slotCount = Math.max(2, sources.length);
  const slots: (Src | null)[] = Array.from({ length: slotCount }, (_, i) => sources[i] ?? null);

  return (
    <div className="grid grid-cols-2 gap-1.5 p-1.5">
      {slots.map((s, i) =>
        s ? (
          <FilledSlot
            key={s.id}
            src={s}
            index={i}
            modelRef={modelRef}
            selected={m.selectedId === s.id}
            bump={bump}
            onSelect={onSelect}
            onRemove={() => onRemoveSource(s.id)}
          />
        ) : (
          <EmptySlot key={`empty-${i}`} index={i} />
        ),
      )}
    </div>
  );
}

function EmptySlot({ index }: { index: number }) {
  return (
    <div className="flex aspect-video flex-col items-center justify-center rounded-md border border-dashed border-ink-600 bg-ink-900/40 text-fog-500">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
        <path d="M12 5v14M5 12h14" />
      </svg>
      <span className="panel-label mt-1 text-[9px]">INPUT {index + 1}</span>
      <span className="font-mono text-[8px] text-fog-500">use ADD INPUT</span>
    </div>
  );
}

function FilledSlot({
  src, index, modelRef, selected, bump, onSelect, onRemove,
}: {
  src: Src;
  index: number;
  modelRef: MutableRefObject<StudioModel>;
  selected: boolean;
  bump: () => void;
  onSelect: (id: string | null) => void;
  onRemove: () => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const hasAudio = src.type === "video-file" || src.type === "media";
  const isPlayable = hasAudio;

  // draw an isolated live thumb of just this source
  useEffect(() => {
    let raf = 0;
    const loop = () => {
      const c = canvasRef.current;
      if (c) {
        const ctx = c.getContext("2d");
        if (ctx) {
          const solo: SceneDef = { id: "solo", name: "", sources: [{ ...src, x: 0, y: 0, w: CW, h: CH, cropL: 0, cropR: 0, cropT: 0, cropB: 0, angleX: 0, angleY: 0 }] };
          const m = modelRef.current;
          drawScene(ctx, solo, c.width, c.height, performance.now() / 1000, m.zoom.participants, m.zoom.phase === "connected");
        }
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [src.id, src.assetId, src.participantId, src.type]);

  const togglePlay = (e: React.MouseEvent) => {
    e.stopPropagation();
    src.playing = src.playing === false ? true : false;
    if (src.type === "video-file") {
      assets.applyState(src.assetId, { playing: src.playing, loop: src.loop, audioMuted: src.audioMuted, audioVol: src.audioVol });
    }
    sfx.play("tick");
    bump();
  };
  const toggleLoop = (e: React.MouseEvent) => {
    e.stopPropagation();
    src.loop = !src.loop;
    sfx.play("tick");
    bump();
  };
  const toggleAudio = (e: React.MouseEvent) => {
    e.stopPropagation();
    src.audioMuted = !src.audioMuted;
    if (src.type === "video-file") assets.applyState(src.assetId, { playing: src.playing, loop: src.loop, audioMuted: src.audioMuted, audioVol: src.audioVol });
    sfx.play(src.audioMuted ? "select" : "tick");
    bump();
  };
  const toggleVis = (e: React.MouseEvent) => {
    e.stopPropagation();
    src.visible = !src.visible;
    bump();
  };

  const playing = src.playing !== false;

  return (
    <div
      onClick={() => onSelect(selected ? null : src.id)}
      className={`group relative cursor-pointer overflow-hidden rounded-md border transition ${
        selected ? "border-prv shadow-[0_0_0_1px_var(--color-prv),0_0_14px_rgba(47,210,115,0.2)]" : "border-ink-600 hover:border-fog-500"
      } ${!src.visible ? "opacity-50" : ""}`}
    >
      {/* live thumb */}
      <canvas ref={canvasRef} width={220} height={124} className="block aspect-video w-full bg-black" />

      {/* index + close */}
      <span className="absolute left-1 top-1 rounded-sm bg-black/65 px-1.5 py-px font-mono text-[8px] text-fog-200">{index + 1}</span>
      <button
        onClick={(e) => { e.stopPropagation(); sfx.play("select"); onRemove(); }}
        title="Remove this input (slot stays)"
        className="btn absolute right-1 top-1 flex h-4 w-4 items-center justify-center rounded-sm bg-black/60 text-fog-300 hover:bg-prg hover:text-white"
      >
        <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round"><path d="M5 5l14 14M19 5L5 19" /></svg>
      </button>

      {/* name strip */}
      <div className="absolute inset-x-0 bottom-6 truncate bg-gradient-to-t from-black/80 to-transparent px-1.5 pb-0.5 pt-2 panel-label text-[10px] text-fog-100">
        {src.name}
      </div>

      {/* transport toolbar */}
      <div className="absolute inset-x-0 bottom-0 flex items-center gap-0.5 bg-black/75 px-1 py-1">
        <button onClick={toggleVis} title="Show / hide on program" className={`btn flex h-4 w-4 items-center justify-center rounded-sm ${src.visible ? "text-prv" : "text-fog-500"} hover:bg-ink-700`}>
          {src.visible ? (
            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M2 12s3.5-6.5 10-6.5S22 12 22 12s-3.5 6.5-10 6.5S2 12 2 12z" /><circle cx="12" cy="12" r="2.4" /></svg>
          ) : (
            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M4 4l16 16M9.9 5.8A10 10 0 0 1 12 5.5c6.5 0 10 6.5 10 6.5a17 17 0 0 1-3 3.6M6 8.2A16 16 0 0 0 2 12s3.5 6.5 10 6.5" /></svg>
          )}
        </button>

        {isPlayable ? (
          <>
            <button onClick={togglePlay} title={playing ? "Pause" : "Play"} className="btn flex h-4 w-4 items-center justify-center rounded-sm text-fog-200 hover:bg-ink-700 hover:text-prv">
              {playing ? (
                <svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="5" width="4" height="14" rx="1" /><rect x="14" y="5" width="4" height="14" rx="1" /></svg>
              ) : (
                <svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor"><path d="M7 5l12 7-12 7z" /></svg>
              )}
            </button>
            <button onClick={toggleLoop} title="Loop" className={`btn flex h-4 w-4 items-center justify-center rounded-sm ${src.loop ? "text-prv" : "text-fog-500"} hover:bg-ink-700`}>
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M17 2l4 4-4 4" /><path d="M3 11V9a4 4 0 0 1 4-4h14" /><path d="M7 22l-4-4 4-4" /><path d="M21 13v2a4 4 0 0 1-4 4H3" /></svg>
            </button>
            <button onClick={toggleAudio} title={src.audioMuted ? "Un-mute input audio" : "Mute input audio"} className={`btn flex h-4 w-4 items-center justify-center rounded-sm ${src.audioMuted ? "text-prg" : "text-prv"} hover:bg-ink-700`}>
              {src.audioMuted ? (
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M11 5L6 9H2v6h4l5 4z" fill="currentColor" stroke="none" /><path d="M22 9l-6 6M16 9l6 6" /></svg>
              ) : (
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M11 5L6 9H2v6h4l5 4z" fill="currentColor" stroke="none" /><path d="M15.5 8.5a5 5 0 0 1 0 7" /></svg>
              )}
            </button>
          </>
        ) : (
          <span className="px-1 font-mono text-[8px] text-fog-500">STATIC</span>
        )}

        <span className="ml-auto font-mono text-[8px] text-fog-400">{Math.round((src.w / src.bw) * 100)}%</span>
      </div>
    </div>
  );
}
