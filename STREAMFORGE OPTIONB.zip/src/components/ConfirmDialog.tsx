import { AlertTriangle } from "lucide-react";

interface Props {
  title: string;
  message: React.ReactNode;
  confirmLabel?: string;
  cancelLabel?: string;
  danger?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}

export default function ConfirmDialog({
  title, message, confirmLabel = "Yes", cancelLabel = "No", danger = true, onConfirm, onCancel,
}: Props) {
  return (
    <div
      className="fixed inset-0 z-[70] flex items-center justify-center bg-black/60 p-4"
      onContextMenu={(e) => e.preventDefault()}
      onClick={onCancel}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-[420px] overflow-hidden rounded-lg border border-[#111] bg-[#252525] shadow-2xl"
      >
        <div className="flex items-center gap-2.5 border-b border-[#1a1a1a] bg-[#2b2b2b] px-4 py-2.5">
          <AlertTriangle className={`h-4 w-4 ${danger ? "text-[#e0a030]" : "text-[#82aaff]"}`} />
          <span className="text-[13px] font-semibold text-[#f0f0f0]">{title}</span>
        </div>
        <div className="px-5 py-4 text-[12px] leading-relaxed text-[#d6d6d6]">{message}</div>
        <div className="flex items-center justify-end gap-2 border-t border-[#1a1a1a] bg-[#2b2b2b] px-4 py-2.5">
          <button
            onClick={onCancel}
            className="rounded border border-[#111] bg-[#3a3a3a] px-4 py-1.5 text-[12px] text-white hover:bg-[#4a4a4a]"
          >
            {cancelLabel}
          </button>
          <button
            onClick={onConfirm}
            className={`rounded border border-[#111] px-4 py-1.5 text-[12px] font-medium text-white ${
              danger ? "bg-[#8b2e2e] hover:bg-[#a33]" : "bg-[#3d6ea8] hover:bg-[#4a7bb8]"
            }`}
          >
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}
