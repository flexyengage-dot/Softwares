import { useEffect, useMemo, useRef, useState } from "react";
import { CW, CH, SOURCE_META, type SourceType } from "../engine/types";
import { assets } from "../engine/assets";
import { capture } from "../engine/capture";
import { sfx } from "../engine/sfx";
import { BOOKS, lookupVerse } from "../engine/bible";

interface Props {
  type: SourceType;
  existing?: any; // when editing an existing source
  participants: { id: string; name: string }[];
  onCancel: () => void;
  onConfirm: (payload: {
    name: string;
    props: Record<string, unknown>;
    /* file assets — must be applied after source is inserted */
    file?: { kind: "image" | "video"; file: File };
  }) => void;
}

/* Human titles matching OBS wording */
const TYPE_TITLES: Record<SourceType, string> = {
  camera: "Camera (Simulated)",
  "live-cam": "Video Capture Device",
  display: "Display Capture",
  browser: "Browser Source",
  image: "Image (Generated)",
  "image-file": "Image",
  "video-file": "Media Source",
  media: "Media Source (Simulated)",
  text: "Text (GDI+)",
  color: "Color Source",
  "zoom-grid": "Zoom Gallery",
  "zoom-guest": "Zoom Participant",
  ndi: "NDI™ Source",
  gt: "GT Titles",
  stinger: "Text Stinger",
  "srt-listener": "SRT Listener",
  "srt-caller": "SRT Caller",
  webrtc: "WebRTC Input",
  rtmp: "RTMP Server",
  worship: "Praise & Worship Lower Third",
  bible: "Bible Verse",
};

const NDI_SOURCES = [
  "STUDIO-PC (OBS Studio)",
  "PTZ-CAM-2 (NDI|HX)",
  "REPLAY-SERVER (Instant Replay)",
  "MEDIA-PC (VLC Output)",
];

/* Enumerated display / window lists for capture sources */
const SIM_MONITORS = [
  "Display 1 — 1920x1080 @ 60Hz (primary)",
  "Display 2 — 2560x1440 @ 144Hz",
  "Display 3 — 3840x2160 @ 60Hz",
];
const SIM_WINDOWS = [
  "[Holyrics]: Output / Projection Window",
  "[Holyrics]: Stage View",
  "[Chrome]: OBS Studio — Docs",
  "[Zoom]: Meeting — Live Panel",
  "[VS Code]: streamforge/src",
  "[Explorer]: Videos\\StreamForge",
];
const CAPTURE_METHODS = ["Automatic", "BitBlt", "Windows 10 API (WGC)", "DXGI Duplication"];

/* Basic form primitives — keep dialog light and OBS-native looking */
const F = {
  Group: ({ children }: { children: React.ReactNode }) => (
    <div className="space-y-3 border-t border-[#1a1a1a] px-4 py-3 first:border-t-0">{children}</div>
  ),
  Row: ({ label, children }: { label: string; children: React.ReactNode }) => (
    <label className="flex items-center gap-3">
      <span className="w-[120px] flex-none text-[12px] text-[#c8c8c8]">{label}</span>
      <div className="min-w-0 flex-1">{children}</div>
    </label>
  ),
  Text: (p: React.InputHTMLAttributes<HTMLInputElement>) => (
    <input {...p} className={`w-full rounded border border-[#111] bg-[#2b2b2b] px-2 py-1.5 text-[12px] text-[#e8e8e8] focus:border-[#3d6ea8] focus:outline-none ${p.className ?? ""}`} />
  ),
  Num: (p: React.InputHTMLAttributes<HTMLInputElement>) => (
    <input {...p} type="number" className="w-full rounded border border-[#111] bg-[#2b2b2b] px-2 py-1.5 text-[12px] text-[#e8e8e8] focus:border-[#3d6ea8] focus:outline-none" />
  ),
  Select: (p: React.SelectHTMLAttributes<HTMLSelectElement>) => (
    <select {...p} className="w-full rounded border border-[#111] bg-[#2b2b2b] px-2 py-1.5 text-[12px] text-[#e8e8e8] focus:border-[#3d6ea8] focus:outline-none" />
  ),
  Check: ({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) => (
    <label className="flex items-center gap-2 text-[12px] text-[#d4d4d4]">
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} className="accent-[#3d6ea8]" />
      {label}
    </label>
  ),
};

export default function SourceProperties({ type, existing, participants, onCancel, onConfirm }: Props) {
  const isFile = type === "image-file" || type === "video-file";

  const [name, setName] = useState<string>(existing?.name ?? SOURCE_META.find((x) => x.type === type)?.label ?? type);

  /* per-type state — everything defaults sensibly */
  const [flipH, setFlipH] = useState<boolean>(existing?.flipH ?? false);
  const [useLiveCam, setUseLiveCam] = useState<boolean>(existing?.useLiveCam ?? true);

  /* IP / network camera (WiFi / LAN) — real stream URL */
  const [ipUrl, setIpUrl] = useState<string>(existing?.ipUrl ?? "");
  const [ipUser, setIpUser] = useState<string>(existing?.ipUser ?? "");
  const [ipPass, setIpPass] = useState<string>(existing?.ipPass ?? "");
  const [ipKind, setIpKind] = useState<"auto" | "mjpeg" | "hls" | "mp4">(existing?.ipKind ?? "auto");
  const [ipTest, setIpTest] = useState<"" | "ok" | "fail">("");

  const testIp = () => {
    if (!ipUrl.trim()) { setIpTest("fail"); return; }
    const probe = new Image();
    let done = false;
    const finish = (ok: boolean) => { if (!done) { done = true; setIpTest(ok ? "ok" : "fail"); } };
    probe.onload = () => finish(true);
    probe.onerror = () => finish(false);
    setTimeout(() => finish(false), 4000);
    probe.src = ipUrl.trim();
  };

  const [monitor, setMonitor] = useState<string>(existing?.monitor ?? SIM_MONITORS[0]);
  const [captureMethod, setCaptureMethod] = useState<string>(existing?.captureMethod ?? CAPTURE_METHODS[0]);
  const [showCursor, setShowCursor] = useState<boolean>(existing?.showCursor ?? true);
  const [captureRegion, setCaptureRegion] = useState<boolean>(existing?.captureRegion ?? false);
  const [regionX, setRegionX] = useState<number>(existing?.regionX ?? 0);
  const [regionY, setRegionY] = useState<number>(existing?.regionY ?? 0);
  const [regionW, setRegionW] = useState<number>(existing?.regionW ?? 1920);
  const [regionH, setRegionH] = useState<number>(existing?.regionH ?? 1080);

  const [captureType, setCaptureType] = useState<"monitor" | "window">(existing?.captureType ?? "monitor");
  const [win, setWin] = useState<string>(existing?.win ?? SIM_WINDOWS[0]);

  const [url, setUrl] = useState<string>(existing?.url ?? "https://obsproject.com");
  const [pageW, setPageW] = useState<number>(existing?.pageW ?? 1280);
  const [pageH, setPageH] = useState<number>(existing?.pageH ?? 720);
  const [refreshInactive, setRefreshInactive] = useState<boolean>(existing?.refreshInactive ?? false);
  const [controlAudio, setControlAudio] = useState<boolean>(existing?.controlAudio ?? false);
  const [css, setCss] = useState<string>(existing?.css ?? "body { background: rgba(0,0,0,0); }");

  const [text, setText] = useState<string>(existing?.text ?? "Sample Text");
  const [font, setFont] = useState<string>(existing?.font ?? "Segoe UI");
  const [fontSize, setFontSize] = useState<number>(existing?.fontSize ?? 72);
  const [textColor, setTextColor] = useState<string>(existing?.textColor ?? "#ffffff");
  const [textBold, setTextBold] = useState<boolean>(existing?.textBold ?? false);
  const [textShadow, setTextShadow] = useState<boolean>(existing?.textShadow ?? true);
  const [textOutline, setTextOutline] = useState<boolean>(existing?.textOutline ?? false);

  const [colorHex, setColorHex] = useState<string>(existing?.color ?? "#1a1a1a");
  const [colorW, setColorW] = useState<number>(existing?.colorW ?? CW);
  const [colorH, setColorH] = useState<number>(existing?.colorH ?? CH);

  const [participantId, setParticipantId] = useState<string>(existing?.participantId ?? participants[0]?.id ?? "");
  const [pipEnabled, setPipEnabled] = useState<boolean>(existing?.pipEnabled ?? false);
  const [pipCorner, setPipCorner] = useState<"tl" | "tr" | "bl" | "br">(existing?.pipCorner ?? "br");
  const [layout, setLayout] = useState<"grid" | "speaker" | "gallery">(existing?.layout ?? "grid");
  const [showNames, setShowNames] = useState<boolean>(existing?.showNames ?? true);

  const [ndiSource, setNdiSource] = useState<string>(existing?.ndiSource ?? NDI_SOURCES[0]);
  const [ndiLatency, setNdiLatency] = useState<"low" | "normal">(existing?.ndiLatency ?? "low");
  const [ndiBandwidth, setNdiBandwidth] = useState<string>(existing?.ndiBandwidth ?? "Auto");

  const [gtTitle, setGtTitle] = useState<string>(existing?.text ?? "GT TITLES");
  const [gtSubtitle, setGtSubtitle] = useState<string>(existing?.url ?? "GRAPHICS TEMPLATE");
  const [gtTemplate, setGtTemplate] = useState<string>(existing?.gtTemplate ?? "Modern");
  const [gtAlign, setGtAlign] = useState<"left" | "center" | "right">(existing?.gtAlign ?? "center");
  const [gtBg, setGtBg] = useState<"rect" | "card" | "bar" | "transparent">(existing?.gtBg ?? "rect");

  const [stingerText, setStingerText] = useState<string>(existing?.text ?? "TEXT STINGER");
  const [stingerStyle, setStingerStyle] = useState<string>(existing?.stingerStyle ?? "Scroll");
  const [stingerDuration, setStingerDuration] = useState<number>(existing?.stingerDuration ?? 8);

  const [bibleBook, setBibleBook] = useState<string>(existing?.bibleBook ?? "John");
  const [bibleChapter, setBibleChapter] = useState<number>(existing?.bibleChapter ?? 3);
  const [bibleVerse, setBibleVerse] = useState<number>(existing?.bibleVerse ?? 16);
  const [bibleText, setBibleText] = useState<string>(existing?.text ?? "");
  const [bibleRef, setBibleRef] = useState<string>(existing?.url ?? "");
  const [bibleAccent, setBibleAccent] = useState<string>(existing?.color ?? "#d4a437");
  const [bibleStatus, setBibleStatus] = useState<string>("");
  const [bibleBg, setBibleBg] = useState<"transparent" | "solid" | "default" | "image">(existing?.bibleBg ?? "default");
  const [bibleBgColor, setBibleBgColor] = useState<string>(existing?.bibleBgColor ?? "#10131c");
  const [bibleBgVariant, setBibleBgVariant] = useState<number>(existing?.bibleBgVariant ?? 0);
  const [bibleBgAsset, setBibleBgAsset] = useState<string | undefined>(existing?.bibleBgAsset);
  const bibleBgFileRef = useRef<HTMLInputElement>(null);

  const fetchBible = async () => {
    setBibleStatus("Looking up…");
    const res = await lookupVerse({ book: bibleBook, chapter: bibleChapter, verse: bibleVerse });
    if (res) {
      setBibleText(res.text);
      setBibleRef(`${bibleBook} ${bibleChapter}:${bibleVerse}`);
      setBibleStatus(`Loaded (${res.source === "online" ? "fetched online · cached" : "offline cache"})`);
    } else {
      setBibleStatus("Not found offline. Connect to the internet to fetch it, or download the KJV from the Bible menu.");
    }
  };

  const [netHost, setNetHost] = useState<string>(existing?.netHost ?? "0.0.0.0");
  const [netPort, setNetPort] = useState<number>(existing?.netPort ?? 9000);
  const [netPassphrase, setNetPassphrase] = useState<string>(existing?.netPassphrase ?? "");
  const [webrtcRoom, setWebrtcRoom] = useState<string>(existing?.webrtcRoom ?? "studio-live");
  const [rtmpUrl, setRtmpUrl] = useState<string>(existing?.url ?? "rtmp://ingest.streamforge.app/live");

  /* image / media file pickers */
  const [pendingFile, setPendingFile] = useState<File | null>(null);
  const fileRef = useRef<HTMLInputElement | null>(null);
  const [preview, setPreview] = useState<string | null>(null);

  useEffect(() => {
    if (!pendingFile) return;
    const url = URL.createObjectURL(pendingFile);
    setPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [pendingFile]);

  useEffect(() => {
    if (isFile && !existing && !pendingFile) fileRef.current?.click();
  }, [isFile, existing, pendingFile]);

  /* live-cam device probing */
  const [devices, setDevices] = useState<MediaDeviceInfo[]>([]);
  const [liveCamId, setLiveCamId] = useState<string>(existing?.liveCamId ?? "");
  useEffect(() => {
    if (type !== "live-cam") return;
    if (!navigator.mediaDevices?.enumerateDevices) return;
    navigator.mediaDevices.enumerateDevices().then((all) => {
      const cams = all.filter((d) => d.kind === "videoinput");
      setDevices(cams);
      if (!liveCamId && cams[0]?.deviceId) setLiveCamId(cams[0].deviceId);
    }).catch(() => undefined);
  }, [type, liveCamId]);

  const canConfirm = useMemo(() => {
    if (isFile) return !!pendingFile || !!existing?.assetId;
    return true;
  }, [isFile, pendingFile, existing]);

  /* on-confirm — construct props payload per type */
  const confirm = () => {
    if (!canConfirm) {
      sfx.play("deny");
      return;
    }
    const props: Record<string, unknown> = {};

    if (type === "camera") {
      props.ipUrl = ipUrl.trim();
      props.ipUser = ipUser;
      props.ipPass = ipPass;
      props.ipKind = ipKind;
      props.flipH = flipH;
    }
    if (type === "live-cam") {
      props.liveCamId = liveCamId;
      props.deviceLabel = devices.find((d) => d.deviceId === liveCamId)?.label ?? "Default camera";
      props.flipH = flipH;
      if (useLiveCam) capture.startCamera();
    }
    if (type === "display") {
      props.monitor = monitor;
      props.captureMethod = captureMethod;
      props.showCursor = showCursor;
      props.captureRegion = captureRegion;
      props.regionX = regionX;
      props.regionY = regionY;
      props.regionW = regionW;
      props.regionH = regionH;
      props.captureType = captureType;
      props.win = win;
    }
    if (type === "browser") {
      props.url = url;
      props.pageW = pageW;
      props.pageH = pageH;
      props.refreshInactive = refreshInactive;
      props.controlAudio = controlAudio;
      props.css = css;
    }
    if (type === "text") {
      props.text = text;
      props.font = font;
      props.fontSize = fontSize;
      props.textColor = textColor;
      props.textBold = textBold;
      props.textShadow = textShadow;
      props.textOutline = textOutline;
    }
    if (type === "color") {
      props.color = colorHex;
      props.colorW = colorW;
      props.colorH = colorH;
    }
    if (type === "zoom-grid") {
      props.layout = layout;
      props.showNames = showNames;
    }
    if (type === "zoom-guest") {
      props.participantId = participantId;
      props.pipEnabled = pipEnabled;
      props.pipCorner = pipCorner;
    }
    if (type === "image") {
      props.pageW = pageW;
      props.pageH = pageH;
    }
    if (type === "ndi") {
      props.ndiSource = ndiSource;
      props.ndiBandwidth = ndiBandwidth;
      props.ndiLatency = ndiLatency;
    }
    if (type === "gt") {
      props.text = gtTitle;
      props.url = gtSubtitle;
      props.gtTemplate = gtTemplate;
      props.gtAlign = gtAlign;
      props.gtBg = gtBg;
    }
    if (type === "stinger") {
      props.text = stingerText;
      props.stingerStyle = stingerStyle;
      props.stingerDuration = stingerDuration;
    }
    if (type === "bible") {
      props.text = bibleText || `${bibleBook} ${bibleChapter}:${bibleVerse}`;
      props.url = bibleRef || `${bibleBook} ${bibleChapter}:${bibleVerse}`;
      props.color = bibleAccent;
      props.bibleBook = bibleBook;
      props.bibleChapter = bibleChapter;
      props.bibleVerse = bibleVerse;
      props.bibleBg = bibleBg;
      props.bibleBgColor = bibleBgColor;
      props.bibleBgVariant = bibleBgVariant;
      if (bibleBgAsset) props.bibleBgAsset = bibleBgAsset;
      props.bibleBg = bibleBg;
      props.bibleBgColor = bibleBgColor;
      props.bibleBgVariant = bibleBgVariant;
      if (bibleBgAsset) props.bibleBgAsset = bibleBgAsset;
      props.bornAt = (window as unknown as { __sfT?: number }).__sfT ?? 0;
    }
    if (type === "srt-listener" || type === "srt-caller" || type === "webrtc" || type === "rtmp") {
      props.netHost = netHost;
      props.netPort = netPort;
      props.netPassphrase = netPassphrase;
      props.webrtcRoom = webrtcRoom;
      props.ndiLatency = ndiLatency;
      if (type === "webrtc") props.url = `wss://${webrtcRoom}`;
      else if (type === "rtmp") props.url = rtmpUrl;
      else props.url = `srt://${netHost}:${netPort}${type === "srt-listener" ? "?mode=listener" : "?mode=caller"}`;
    }

    const file = pendingFile
      ? { kind: (type === "image-file" ? "image" : "video") as "image" | "video", file: pendingFile }
      : undefined;

    onConfirm({ name: name.trim() || TYPE_TITLES[type], props, file });
  };

  /* ---------- per-type form body ---------- */
  let body: React.ReactNode = null;

  if (type === "live-cam") {
    body = (
      <F.Group>
        <F.Row label="Device">
          <div className="flex items-center gap-2">
            <F.Select value={liveCamId} onChange={(e) => setLiveCamId(e.target.value)}>
              {devices.length === 0 && <option value="">No cameras found — press Refresh</option>}
              {devices.map((d) => (
                <option key={d.deviceId} value={d.deviceId}>
                  {d.label || `Camera (${d.deviceId.slice(0, 6)})`}
                </option>
              ))}
            </F.Select>
            <button
              onClick={() => {
                navigator.mediaDevices?.enumerateDevices().then((all) => {
                  const cams = all.filter((d) => d.kind === "videoinput");
                  setDevices(cams);
                  if (cams[0]?.deviceId) setLiveCamId(cams[0].deviceId);
                }).catch(() => undefined);
              }}
              className="rounded border border-[#111] bg-[#3a3a3a] px-3 py-1.5 text-[11px] text-white hover:bg-[#4a4a4a]"
            >
              Refresh
            </button>
          </div>
        </F.Row>
        <div className="px-0 text-[10px] leading-relaxed text-[#8a8a8a]">
          Lists every real capture device your system sees — built-in, USB webcams and capture cards.
          Plug a camera in, press Refresh, and it appears here.
        </div>
        <F.Check label="Activate camera when this source becomes visible" checked={useLiveCam} onChange={setUseLiveCam} />
        <F.Row label="Options">
          <div className="space-y-1">
            <F.Check label="Flip horizontally (mirror)" checked={flipH} onChange={setFlipH} />
          </div>
        </F.Row>
      </F.Group>
    );
  } else if (type === "camera") {
    body = (
      <F.Group>
        <F.Row label="Stream URL">
          <F.Text value={ipUrl} onChange={(e) => { setIpUrl(e.target.value); setIpTest(""); }} placeholder="http://192.168.1.50/video.mjpg" />
        </F.Row>
        <div className="flex items-center gap-2">
          <button
            onClick={testIp}
            className="rounded border border-[#111] bg-[#3d6ea8] px-3 py-1.5 text-[11px] font-medium text-white hover:bg-[#4a7bb8]"
          >
            Test connection
          </button>
          {ipTest === "ok" && <span className="text-[11px] text-[#31c48d]">Reachable — stream loads.</span>}
          {ipTest === "fail" && <span className="text-[11px] text-[#e5484d]">No response. Check the URL & that the camera is on your network.</span>}
        </div>
        <F.Row label="Stream type">
          <F.Select value={ipKind} onChange={(e) => setIpKind(e.target.value as typeof ipKind)}>
            <option value="auto">Auto-detect</option>
            <option value="mjpeg">MJPEG (most WiFi cams)</option>
            <option value="hls">HLS (.m3u8)</option>
            <option value="mp4">MP4 / direct file</option>
          </F.Select>
        </F.Row>
        <F.Row label="Login (optional)">
          <div className="grid grid-cols-2 gap-2">
            <F.Text value={ipUser} onChange={(e) => setIpUser(e.target.value)} placeholder="username" />
            <F.Text type="password" value={ipPass} onChange={(e) => setIpPass(e.target.value)} placeholder="password" />
          </div>
        </F.Row>
        <div className="rounded border border-[#1a2a3a] bg-[#101a26] px-3 py-2 text-[10px] leading-relaxed text-[#82aaff]">
          Works with cameras on the same WiFi/LAN. Find the camera&apos;s IP from your router, then use its
          MJPEG address — e.g. <span className="font-mono">http://&lt;ip&gt;:8080/video</span> for IP Webcam,
          or the RTSP-to-MJPEG bridge for Hikvision / Dahua / i1-style cams. RTSP itself needs a gateway; MJPEG loads directly.
        </div>
        <F.Row label="Options">
          <div className="space-y-1">
            <F.Check label="Flip horizontally (mirror)" checked={flipH} onChange={setFlipH} />
          </div>
        </F.Row>
      </F.Group>
    );
  } else if (type === "display") {
    body = (
      <F.Group>
        <F.Row label="Capture type">
          <F.Select value={captureType} onChange={(e) => setCaptureType(e.target.value as "monitor" | "window")}>
            <option value="monitor">Monitor</option>
            <option value="window">Window</option>
          </F.Select>
        </F.Row>
        {captureType === "monitor" ? (
          <F.Row label="Monitor">
            <F.Select value={monitor} onChange={(e) => setMonitor(e.target.value)}>
              {SIM_MONITORS.map((m) => <option key={m}>{m}</option>)}
            </F.Select>
          </F.Row>
        ) : (
          <F.Row label="Window">
            <F.Select value={win} onChange={(e) => setWin(e.target.value)}>
              {SIM_WINDOWS.map((w) => <option key={w}>{w}</option>)}
            </F.Select>
          </F.Row>
        )}
        <F.Row label="Capture method">
          <F.Select value={captureMethod} onChange={(e) => setCaptureMethod(e.target.value)}>
            {CAPTURE_METHODS.map((c) => <option key={c}>{c}</option>)}
          </F.Select>
        </F.Row>
        <F.Row label="Options">
          <div className="space-y-1">
            <F.Check label="Show cursor" checked={showCursor} onChange={setShowCursor} />
            <F.Check label="Capture region only" checked={captureRegion} onChange={setCaptureRegion} />
          </div>
        </F.Row>
        {captureRegion && (
          <F.Row label="Region (px)">
            <div className="grid grid-cols-4 gap-1.5">
              <F.Num value={regionX} onChange={(e) => setRegionX(Number(e.target.value) || 0)} placeholder="X" />
              <F.Num value={regionY} onChange={(e) => setRegionY(Number(e.target.value) || 0)} placeholder="Y" />
              <F.Num value={regionW} onChange={(e) => setRegionW(Number(e.target.value) || 0)} placeholder="W" />
              <F.Num value={regionH} onChange={(e) => setRegionH(Number(e.target.value) || 0)} placeholder="H" />
            </div>
          </F.Row>
        )}
      </F.Group>
    );
  } else if (type === "browser") {
    body = (
      <F.Group>
        <F.Row label="URL">
          <F.Text value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://…" />
        </F.Row>
        <F.Row label="Size (px)">
          <div className="grid grid-cols-2 gap-2">
            <F.Num value={pageW} onChange={(e) => setPageW(Number(e.target.value) || 1280)} />
            <F.Num value={pageH} onChange={(e) => setPageH(Number(e.target.value) || 720)} />
          </div>
        </F.Row>
        <F.Row label="Options">
          <div className="space-y-1">
            <F.Check label="Refresh browser when scene becomes inactive" checked={refreshInactive} onChange={setRefreshInactive} />
            <F.Check label="Control audio via OBS mixer" checked={controlAudio} onChange={setControlAudio} />
          </div>
        </F.Row>
        <F.Row label="Custom CSS">
          <textarea
            value={css}
            onChange={(e) => setCss(e.target.value)}
            rows={3}
            className="w-full rounded border border-[#111] bg-[#2b2b2b] px-2 py-1.5 font-mono text-[11px] text-[#e8e8e8] focus:border-[#3d6ea8] focus:outline-none"
          />
        </F.Row>
      </F.Group>
    );
  } else if (type === "text") {
    body = (
      <F.Group>
        <F.Row label="Text">
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            rows={3}
            className="w-full rounded border border-[#111] bg-[#2b2b2b] px-2 py-1.5 text-[12px] text-[#e8e8e8] focus:border-[#3d6ea8] focus:outline-none"
          />
        </F.Row>
        <F.Row label="Font">
          <div className="grid grid-cols-[1fr_90px] gap-2">
            <F.Select value={font} onChange={(e) => setFont(e.target.value)}>
              {["Segoe UI", "Arial", "Barlow Condensed", "Helvetica", "Georgia", "Impact", "Courier New"].map((f) => <option key={f}>{f}</option>)}
            </F.Select>
            <F.Num value={fontSize} min={12} max={288} onChange={(e) => setFontSize(Number(e.target.value) || 72)} />
          </div>
        </F.Row>
        <F.Row label="Colour">
          <input type="color" value={textColor} onChange={(e) => setTextColor(e.target.value)} className="h-8 w-16 rounded border border-[#111] bg-[#2b2b2b]" />
        </F.Row>
        <F.Row label="Style">
          <div className="space-y-1">
            <F.Check label="Bold" checked={textBold} onChange={setTextBold} />
            <F.Check label="Drop shadow" checked={textShadow} onChange={setTextShadow} />
            <F.Check label="Outline" checked={textOutline} onChange={setTextOutline} />
          </div>
        </F.Row>
      </F.Group>
    );
  } else if (type === "color") {
    body = (
      <F.Group>
        <F.Row label="Colour">
          <div className="flex items-center gap-2">
            <input type="color" value={colorHex} onChange={(e) => setColorHex(e.target.value)} className="h-8 w-16 rounded border border-[#111] bg-[#2b2b2b]" />
            <F.Text value={colorHex} onChange={(e) => setColorHex(e.target.value)} />
          </div>
        </F.Row>
        <F.Row label="Size">
          <div className="grid grid-cols-2 gap-2">
            <F.Num value={colorW} onChange={(e) => setColorW(Number(e.target.value) || 0)} />
            <F.Num value={colorH} onChange={(e) => setColorH(Number(e.target.value) || 0)} />
          </div>
        </F.Row>
      </F.Group>
    );
  } else if (type === "image-file" || type === "video-file" || type === "image" || type === "media") {
    body = (
      <F.Group>
        {isFile && (
          <>
            <F.Row label="File">
              <div className="flex items-center gap-2">
                <F.Text value={pendingFile?.name ?? existing?.name ?? ""} readOnly placeholder="Click Browse…" />
                <button
                  onClick={() => fileRef.current?.click()}
                  className="rounded border border-[#111] bg-[#3a3a3a] px-3 py-1.5 text-[12px] text-white hover:bg-[#4a4a4a]"
                >
                  Browse…
                </button>
              </div>
              <input
                ref={fileRef}
                type="file"
                accept={type === "image-file" ? "image/*" : "video/*"}
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) setPendingFile(f);
                  e.target.value = "";
                }}
              />
            </F.Row>
            {preview && (
              <F.Row label="Preview">
                {type === "image-file" ? (
                  <img src={preview} alt="preview" className="max-h-32 rounded border border-[#111]" />
                ) : (
                  <video src={preview} controls className="max-h-32 rounded border border-[#111]" />
                )}
              </F.Row>
            )}
          </>
        )}
        {(type === "image" || type === "media") && (
          <F.Row label="Canvas size">
            <div className="grid grid-cols-2 gap-2">
              <F.Num value={pageW} onChange={(e) => setPageW(Number(e.target.value) || 1280)} />
              <F.Num value={pageH} onChange={(e) => setPageH(Number(e.target.value) || 720)} />
            </div>
          </F.Row>
        )}
      </F.Group>
    );
  } else if (type === "zoom-grid") {
    body = (
      <F.Group>
        <F.Row label="Layout">
          <F.Select value={layout} onChange={(e) => setLayout(e.target.value as any)}>
            <option value="grid">Grid</option>
            <option value="speaker">Active speaker</option>
            <option value="gallery">Gallery</option>
          </F.Select>
        </F.Row>
        <F.Row label="Options">
          <F.Check label="Show participant names" checked={showNames} onChange={setShowNames} />
        </F.Row>
      </F.Group>
    );
  } else if (type === "zoom-guest") {
    body = (
      <F.Group>
        <F.Row label="Participant">
          <F.Select value={participantId} onChange={(e) => setParticipantId(e.target.value)}>
            {participants.length === 0 && <option value="">— (connect Zoom first)</option>}
            {participants.map((p) => (
              <option key={p.id} value={p.id}>{p.name}</option>
            ))}
          </F.Select>
        </F.Row>
        <F.Row label="Options">
          <div className="space-y-1">
            <F.Check label="Show as picture-in-picture" checked={pipEnabled} onChange={setPipEnabled} />
            {pipEnabled && (
              <F.Select value={pipCorner} onChange={(e) => setPipCorner(e.target.value as any)}>
                <option value="tl">Top-left</option>
                <option value="tr">Top-right</option>
                <option value="bl">Bottom-left</option>
                <option value="br">Bottom-right</option>
              </F.Select>
            )}
          </div>
        </F.Row>
      </F.Group>
    );
  } else if (type === "ndi") {
    body = (
      <F.Group>
        <F.Row label="NDI source">
          <F.Select value={ndiSource} onChange={(e) => setNdiSource(e.target.value)}>
            {NDI_SOURCES.map((n) => <option key={n}>{n}</option>)}
          </F.Select>
        </F.Row>
        <F.Row label="Bandwidth">
          <F.Select value={ndiBandwidth} onChange={(e) => setNdiBandwidth(e.target.value)}>
            <option>Auto</option><option>High</option><option>Medium</option><option>Low (UDP multicast)</option>
          </F.Select>
        </F.Row>
        <F.Row label="Latency mode">
          <F.Select value={ndiLatency} onChange={(e) => setNdiLatency(e.target.value as "low" | "normal")}>
            <option value="low">Low (real-time)</option>
            <option value="normal">Normal (buffered)</option>
          </F.Select>
        </F.Row>
        <div className="px-4 pb-2 text-[10px] leading-relaxed text-[#d0a85a]">
          NDI requires a native NDI runtime or bridge on this machine. If no bridge is connected,
          the source displays an offline slate instead of pretending to be live.
        </div>
      </F.Group>
    );
  } else if (type === "gt") {
    body = (
      <F.Group>
        <F.Row label="Title">
          <F.Text value={gtTitle} onChange={(e) => setGtTitle(e.target.value)} />
        </F.Row>
        <F.Row label="Subtitle">
          <F.Text value={gtSubtitle} onChange={(e) => setGtSubtitle(e.target.value)} />
        </F.Row>
        <F.Row label="Template">
          <div className="grid grid-cols-3 gap-2">
            {([
              { v: "Modern", title: "Modern", sub: "Centered title" },
              { v: "Rail", title: "Rail", sub: "Side accent" },
              { v: "Corner", title: "Corner", sub: "Angled corner" },
            ] as const).map((tpl) => (
              <button
                key={tpl.v}
                onClick={() => setGtTemplate(tpl.v)}
                className={`overflow-hidden rounded border text-left transition-colors ${gtTemplate === tpl.v ? "border-[#3d6ea8] bg-[#2a3a55]" : "border-[#111] bg-[#2b2b2b] hover:border-[#444]"}`}
              >
                <div className="relative h-16 bg-[#080a0f]">
                  {tpl.v === "Modern" && <div className="absolute left-0 right-0 top-3 h-1 bg-[#2fd273]" />}
                  {tpl.v === "Rail" && <div className="absolute bottom-2 left-3 top-2 w-1 bg-[#ffb020]" />}
                  {tpl.v === "Corner" && <div className="absolute bottom-0 left-0 h-8 w-16 bg-[#2d8cff]" style={{ clipPath: "polygon(0 100%, 100% 100%, 0 0)" }} />}
                  <div className={`absolute inset-x-2 top-5 truncate text-[10px] font-semibold text-white ${tpl.v === "Rail" ? "pl-4 text-left" : "text-center"}`}>{tpl.title}</div>
                  <div className={`absolute inset-x-2 top-9 truncate text-[8px] text-[#aab] ${tpl.v === "Rail" ? "pl-4 text-left" : "text-center"}`}>{tpl.sub}</div>
                </div>
                <div className="px-2 py-1 text-[10px] text-[#c8c8c8]">{tpl.title}</div>
              </button>
            ))}
          </div>
        </F.Row>
        <F.Row label="Alignment">
          <div className="grid grid-cols-3 gap-1.5">
            {(["left", "center", "right"] as const).map((a) => (
              <button
                key={a}
                onClick={() => setGtAlign(a)}
                className={`rounded border px-2 py-1.5 text-[11px] capitalize transition-colors ${
                  gtAlign === a ? "border-[#3d6ea8] bg-[#2a3a55] text-white" : "border-[#111] bg-[#2b2b2b] text-[#c8c8c8] hover:border-[#444]"
                }`}
              >
                {a}
              </button>
            ))}
          </div>
        </F.Row>
        <F.Row label="Background">
          <div className="grid grid-cols-2 gap-1.5">
            {([
              { v: "rect", label: "Rectangular", desc: "Solid full panel" },
              { v: "card", label: "Card", desc: "Rounded semi-opaque" },
              { v: "bar", label: "Lower bar", desc: "Title strip only" },
              { v: "transparent", label: "Transparent", desc: "Text only" },
            ] as const).map((b) => (
              <button
                key={b.v}
                onClick={() => setGtBg(b.v)}
                className={`rounded border px-2 py-1.5 text-left transition-colors ${
                  gtBg === b.v ? "border-[#3d6ea8] bg-[#2a3a55]" : "border-[#111] bg-[#2b2b2b] hover:border-[#444]"
                }`}
              >
                <div className={`text-[11px] font-medium ${gtBg === b.v ? "text-white" : "text-[#c8c8c8]"}`}>{b.label}</div>
                <div className="text-[9px] text-[#8a8a8a]">{b.desc}</div>
              </button>
            ))}
          </div>
        </F.Row>
      </F.Group>
    );
  } else if (type === "stinger") {
    body = (
      <F.Group>
        <F.Row label="Text">
          <F.Text value={stingerText} onChange={(e) => setStingerText(e.target.value)} />
        </F.Row>
        <F.Row label="Animation">
          <F.Select value={stingerStyle} onChange={(e) => setStingerStyle(e.target.value)}>
            <option>Scroll</option><option>Slide</option><option>Flash</option>
          </F.Select>
        </F.Row>
        <F.Row label="Scroll duration (s)">
          <F.Num value={stingerDuration} min={1} max={30} onChange={(e) => setStingerDuration(Number(e.target.value) || 4)} />
        </F.Row>
        <div className="px-4 pb-2 text-[10px] text-[#8a8a8a]">
          Scroll mode moves long text from right to left like a reader ticker.
        </div>
      </F.Group>
    );
  } else if (type === "bible") {
    body = (
      <F.Group>
        <F.Row label="Reference">
          <div className="grid grid-cols-[1fr_70px_70px] gap-2">
            <F.Select value={bibleBook} onChange={(e) => setBibleBook(e.target.value)}>
              {BOOKS.map((b) => <option key={b.name}>{b.name}</option>)}
            </F.Select>
            <F.Num value={bibleChapter} min={1} onChange={(e) => setBibleChapter(Number(e.target.value) || 1)} />
            <F.Num value={bibleVerse} min={1} onChange={(e) => setBibleVerse(Number(e.target.value) || 1)} />
          </div>
        </F.Row>
        <div className="flex items-center gap-2">
          <button onClick={() => void fetchBible()} className="rounded border border-[#111] bg-[#3d6ea8] px-3 py-1.5 text-[11px] font-medium text-white hover:bg-[#4a7bb8]">
            Look up verse
          </button>
          {bibleStatus && <span className="text-[10px] text-[#8a8a8a]">{bibleStatus}</span>}
        </div>
        {bibleText && (
          <div className="rounded border border-[#1a2a3a] bg-[#101a26] px-3 py-2 font-serif text-[12px] italic leading-relaxed text-[#e9edf3]">
            “{bibleText}”
          </div>
        )}
        <F.Row label="Accent colour">
          <div className="flex items-center gap-2">
            <input type="color" value={bibleAccent} onChange={(e) => setBibleAccent(e.target.value)} className="h-8 w-16 rounded border border-[#111] bg-[#2b2b2b]" />
            <span className="text-[10px] text-[#8a8a8a]">Reference + rules highlight</span>
          </div>
        </F.Row>
        <F.Row label="Background">
          <div className="space-y-2">
            <div className="grid grid-cols-4 gap-1">
              {([["default", "Art"], ["solid", "Solid"], ["image", "Image"], ["transparent", "None"]] as const).map(([v, label]) => (
                <button key={v} onClick={() => setBibleBg(v)}
                  className={`rounded px-1 py-1 text-[10px] font-semibold ${bibleBg === v ? "bg-[#3d6ea8] text-white" : "bg-[#2a2b2f] text-[#9aa0a6] hover:bg-[#3a3b40]"}`}>
                  {label}
                </button>
              ))}
            </div>
            {bibleBg === "default" && (
              <div className="flex gap-1.5">
                {["linear-gradient(160deg,#0c1018,#10141f)", "linear-gradient(160deg,#04060c,#0b101c)", "linear-gradient(160deg,#2a1430,#7a3b28)", "linear-gradient(160deg,#16212b,#0d141b)"].map((g, i) => (
                  <button key={i} onClick={() => setBibleBgVariant(i)} title={`Art ${i + 1}`}
                    className={`h-7 flex-1 rounded border ${bibleBgVariant === i ? "border-[#d4a437]" : "border-black/40"}`} style={{ background: g }} />
                ))}
              </div>
            )}
            {bibleBg === "solid" && (
              <div className="flex items-center gap-2">
                <input type="color" value={bibleBgColor} onChange={(e) => setBibleBgColor(e.target.value)} className="h-8 w-16 rounded border border-[#111] bg-[#2b2b2b]" />
                <span className="font-mono text-[10px] text-[#9aa0a6]">{bibleBgColor}</span>
              </div>
            )}
            {bibleBg === "image" && (
              <div className="flex items-center gap-2">
                <button onClick={() => bibleBgFileRef.current?.click()} className="rounded bg-[#2a2b2f] px-2 py-1 text-[10px] text-[#c8c8c8] hover:bg-[#3a3b40]">Choose image…</button>
                <span className="text-[9px] text-[#7d838a]">{bibleBgAsset ? "image attached" : "no image selected"}</span>
                <input ref={bibleBgFileRef} type="file" accept="image/*" className="hidden"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) { const id = `biblebg-${Date.now()}`; assets.setImage(id, URL.createObjectURL(f)); setBibleBgAsset(id); }
                    e.target.value = "";
                  }} />
              </div>
            )}
          </div>
        </F.Row>
        <div className="px-0 text-[10px] leading-relaxed text-[#82aaff]">
          Tip: enable Live Verse Listening from the Bible menu — when the pastor says a reference out loud,
          the verse is fetched (offline cache first) and dropped into your Preview automatically.
        </div>
      </F.Group>
    );
  } else if (type === "srt-listener" || type === "srt-caller" || type === "webrtc" || type === "rtmp") {
    const isCaller = type === "srt-caller";
    body = (
      <F.Group>
        {type === "webrtc" ? (
          <>
            <F.Row label="Signal server">
              <F.Text value={netHost === "0.0.0.0" ? "wss://signal.streamforge.app" : netHost} onChange={(e) => setNetHost(e.target.value)} />
            </F.Row>
            <F.Row label="Room / Peer ID">
              <F.Text value={webrtcRoom} onChange={(e) => setWebrtcRoom(e.target.value)} />
            </F.Row>
          </>
        ) : type === "rtmp" ? (
          <F.Row label="Ingest URL">
            <F.Text value={rtmpUrl} onChange={(e) => setRtmpUrl(e.target.value)} />
          </F.Row>
        ) : (
          <>
            <F.Row label={isCaller ? "Remote host" : "Listen address"}>
              <F.Text value={netHost} onChange={(e) => setNetHost(e.target.value)} />
            </F.Row>
            <F.Row label="Port">
              <F.Num value={netPort} onChange={(e) => setNetPort(Number(e.target.value) || 9000)} />
            </F.Row>
          </>
        )}
        <F.Row label="Passphrase / key">
          <F.Text type="password" placeholder="SRT / RTMP secret" value={netPassphrase} onChange={(e) => setNetPassphrase(e.target.value)} />
        </F.Row>
        <F.Row label="Latency target">
          <F.Select value={ndiLatency} onChange={(e) => setNdiLatency(e.target.value as "low" | "normal")}>
            <option value="low">Low (~120 ms)</option>
            <option value="normal">Normal (~400 ms)</option>
          </F.Select>
        </F.Row>
      </F.Group>
    );
  }

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/60 p-4" onClick={onCancel}>
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-[560px] max-h-[86vh] overflow-hidden rounded-lg border border-[#111] bg-[#252525] shadow-2xl"
      >
        <div className="flex items-center justify-between border-b border-[#1a1a1a] bg-[#2b2b2b] px-4 py-2.5">
          <div>
            <div className="text-[14px] font-semibold text-[#f0f0f0]">{existing ? "Properties" : "Create Source"} — {TYPE_TITLES[type]}</div>
            <div className="text-[10px] text-[#8a8a8a]">Configure everything, then press OK to add it to your scene</div>
          </div>
          <button onClick={onCancel} className="rounded px-2 py-0.5 text-[11px] text-[#c8c8c8] hover:bg-[#3a3a3a]">ESC</button>
        </div>

        <div className="max-h-[68vh] overflow-y-auto">
          <F.Group>
            <F.Row label="Name">
              <F.Text value={name} onChange={(e) => setName(e.target.value)} />
            </F.Row>
          </F.Group>
          {body}
        </div>

        <div className="flex items-center justify-end gap-2 border-t border-[#1a1a1a] bg-[#2b2b2b] px-4 py-2.5">
          <button onClick={onCancel} className="rounded border border-[#111] bg-[#3a3a3a] px-4 py-1.5 text-[12px] text-white hover:bg-[#4a4a4a]">
            Cancel
          </button>
          <button
            onClick={confirm}
            disabled={!canConfirm}
            className="rounded border border-[#111] bg-[#3d6ea8] px-4 py-1.5 text-[12px] font-medium text-white hover:bg-[#4a7bb8] disabled:cursor-not-allowed disabled:opacity-50"
          >
            OK
          </button>
        </div>
      </div>
    </div>
  );
}

/** Utility used by ObsDock: create the raw source shell that later has `.props` applied */
export function baseSourceForType(type: SourceType, sceneLen: number, defaults: any) {
  const d = defaults[type] ?? defaults.camera;
  const off = (sceneLen % 4) * 36;
  const id = `src-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
  return {
    id,
    name: SOURCE_META.find((x) => x.type === type)?.label ?? type,
    type,
    x: Math.round((CW - d.w) / 2 + off),
    y: Math.round((CH - d.h) / 2 + off * 0.5),
    w: d.w,
    h: d.h,
    bw: d.w,
    bh: d.h,
    visible: true,
    hue: d.hue,
    seed: Math.floor(Math.random() * 9999),
    audioVol: 100,
  };
}

// use ambient asset import so it isn't flagged
void assets;
