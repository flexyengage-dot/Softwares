import { useState, type MutableRefObject } from "react";
import { ENCODERS, RESOLUTIONS, DESTS, REC_FORMATS, type StudioModel } from "../engine/types";

interface Props {
  modelRef: MutableRefObject<StudioModel>;
  bump: () => void;
  onClose: () => void;
}

const TABS = ["General", "Stream", "Output", "Audio", "Video", "Hotkeys", "Advanced"] as const;
type Tab = typeof TABS[number];

const THEMES: { v: StudioModel["theme"]; label: string; sample: string }[] = [
  { v: "obs", label: "OBS (Dark Grey)", sample: "linear-gradient(135deg,#2b2b2b,#1e1e1e)" },
  { v: "dark", label: "Deep Ink", sample: "linear-gradient(135deg,#0f1218,#181d27)" },
  { v: "midnight", label: "Midnight Blue", sample: "linear-gradient(135deg,#0a1929,#132f4c)" },
  { v: "light", label: "Light Studio", sample: "linear-gradient(135deg,#e0e0e0,#f5f5f5)" },
];

const F = {
  Row: ({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) => (
    <div className="grid grid-cols-[180px_1fr] items-start gap-4 py-2">
      <div>
        <div className="text-[12px] text-[#dcdcdc]">{label}</div>
        {hint && <div className="mt-0.5 text-[10px] leading-snug text-[#8a8a8a]">{hint}</div>}
      </div>
      <div>{children}</div>
    </div>
  ),
  Sel: (p: React.SelectHTMLAttributes<HTMLSelectElement>) => (
    <select {...p} className="w-full rounded border border-[#111] bg-[#2b2b2b] px-2 py-1.5 text-[12px] text-[#e8e8e8]" />
  ),
  Text: (p: React.InputHTMLAttributes<HTMLInputElement>) => (
    <input {...p} className="w-full rounded border border-[#111] bg-[#2b2b2b] px-2 py-1.5 text-[12px] text-[#e8e8e8]" />
  ),
  Num: (p: React.InputHTMLAttributes<HTMLInputElement>) => (
    <input {...p} type="number" className="w-full rounded border border-[#111] bg-[#2b2b2b] px-2 py-1.5 text-[12px] text-[#e8e8e8]" />
  ),
  Check: ({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) => (
    <label className="flex items-center gap-2 text-[12px] text-[#d4d4d4]">
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} className="accent-[#3d6ea8]" />
      {label}
    </label>
  ),
};

export default function SettingsDialog({ modelRef, bump, onClose }: Props) {
  const m = modelRef.current;
  const [tab, setTab] = useState<Tab>("General");
  const upd = () => bump();

  const [hotkeyEditing, setHotkeyEditing] = useState<string | null>(null);

  const bindHotkey = (key: string) => (e: React.KeyboardEvent) => {
    e.preventDefault();
    if (e.key === "Escape") { setHotkeyEditing(null); return; }
    m.hotkeys[key] = e.key.length === 1 ? e.key.toUpperCase() : e.key;
    setHotkeyEditing(null);
    upd();
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/60 p-4" onClick={onClose} onContextMenu={(e) => e.preventDefault()}>
      <div
        onClick={(e) => e.stopPropagation()}
        className="flex h-[620px] w-[860px] flex-col overflow-hidden rounded-lg border border-[#111] bg-[#252525] shadow-2xl"
      >
        <div className="flex items-center justify-between border-b border-[#1a1a1a] bg-[#2b2b2b] px-4 py-2.5">
          <div className="text-[14px] font-semibold text-[#f0f0f0]">Settings</div>
          <button onClick={onClose} className="rounded px-2 py-0.5 text-[11px] text-[#c8c8c8] hover:bg-[#3a3a3a]">Close</button>
        </div>

        <div className="flex min-h-0 flex-1">
          {/* left tabs */}
          <div className="w-[170px] flex-none border-r border-[#1a1a1a] bg-[#1f1f1f] py-2">
            {TABS.map((t) => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={`block w-full px-4 py-2 text-left text-[12px] ${
                  tab === t ? "bg-[#3d6ea8] text-white" : "text-[#d0d0d0] hover:bg-[#2a2a2a]"
                }`}
              >
                {t}
              </button>
            ))}
          </div>

          {/* right pane */}
          <div className="min-w-0 flex-1 overflow-y-auto px-6 py-4">
            {tab === "General" && (
              <>
                <div className="mb-3 text-[13px] font-semibold text-[#e8e8e8]">General</div>
                <F.Row label="Language">
                  <F.Sel value={m.language} onChange={(e) => { m.language = e.target.value; upd(); }}>
                    <option>en-US</option><option>en-GB</option><option>fr-FR</option>
                    <option>de-DE</option><option>es-ES</option><option>ja-JP</option>
                    <option>zh-CN</option><option>yo-NG</option>
                  </F.Sel>
                </F.Row>
                <F.Row label="Confirm when going live" hint="Prompt for confirmation before Start Streaming.">
                  <F.Check label="Enabled" checked={m.confirmGoLive} onChange={(v) => { m.confirmGoLive = v; upd(); }} />
                </F.Row>
                <F.Row label="Console sound feedback">
                  <F.Check label="Play synthesised console audio on actions" checked={m.sound} onChange={(v) => { m.sound = v; upd(); }} />
                </F.Row>
                <F.Row label="Safe-area overlay">
                  <F.Check label="Show 90%/rule-of-thirds guides on Program" checked={m.safeAreas} onChange={(v) => { m.safeAreas = v; upd(); }} />
                </F.Row>

                <div className="mb-2 mt-6 text-[13px] font-semibold text-[#e8e8e8]">Theme</div>
                <F.Row label="Colour scheme" hint="Applies to the whole application.">
                  <div className="grid grid-cols-2 gap-2">
                    {THEMES.map((t) => (
                      <button
                        key={t.v}
                        onClick={() => { m.theme = t.v; upd(); }}
                        className={`flex items-center gap-3 rounded border p-2 text-left ${
                          m.theme === t.v ? "border-[#3d6ea8] bg-[#2a3a55]" : "border-[#111] bg-[#2b2b2b] hover:border-[#333]"
                        }`}
                      >
                        <span className="h-7 w-14 flex-none rounded" style={{ background: t.sample }} />
                        <span className="text-[12px] text-[#e8e8e8]">{t.label}</span>
                      </button>
                    ))}
                  </div>
                </F.Row>
              </>
            )}

            {tab === "Stream" && (
              <>
                <div className="mb-3 text-[13px] font-semibold text-[#e8e8e8]">Stream</div>
                <F.Row label="Service">
                  <F.Sel value={m.dest} onChange={(e) => { m.dest = e.target.value; upd(); }}>
                    {DESTS.map((d) => <option key={d.v} value={d.v}>{d.label}</option>)}
                  </F.Sel>
                </F.Row>
                <F.Row label="Stream key" hint="Kept in browser storage only; never logged in plain text.">
                  <F.Text type="password" defaultValue={m.streamKey} onChange={(e) => { m.streamKey = e.target.value; }} />
                </F.Row>
                <F.Row label="Zoom bridge username" hint="Credentials for the Zoom low-latency bridge (JWT/OAuth token supported).">
                  <F.Text defaultValue={m.zoom.user} onChange={(e) => { m.zoom.user = e.target.value; }} />
                </F.Row>
              </>
            )}

            {tab === "Output" && (
              <>
                <div className="mb-3 text-[13px] font-semibold text-[#e8e8e8]">Streaming</div>
                <F.Row label="Encoder">
                  <F.Sel value={m.encoder} onChange={(e) => { m.encoder = e.target.value; upd(); }}>
                    {ENCODERS.map((v) => <option key={v.v} value={v.v}>{v.label}</option>)}
                  </F.Sel>
                </F.Row>
                <F.Row label="Output resolution">
                  <F.Sel value={m.outputRes} onChange={(e) => { m.outputRes = e.target.value; upd(); }}>
                    {RESOLUTIONS.map((v) => <option key={v.v} value={v.v}>{v.label}</option>)}
                  </F.Sel>
                </F.Row>

                <div className="mb-2 mt-6 text-[13px] font-semibold text-[#e8e8e8]">Recording</div>
                <F.Row label="Recording format">
                  <F.Sel value={m.recFormat} onChange={(e) => { m.recFormat = e.target.value; upd(); }}>
                    {REC_FORMATS.map((v) => <option key={v.v} value={v.v}>{v.label}</option>)}
                  </F.Sel>
                </F.Row>
                <F.Row label="Recording path" hint="Files are written to this folder while recording.">
                  <F.Text defaultValue={m.recPath} onChange={(e) => { m.recPath = e.target.value; }} />
                </F.Row>
                <F.Row label="Auto-remux to MP4 when finished">
                  <F.Check label="Enabled" checked={m.autoRemux} onChange={(v) => { m.autoRemux = v; upd(); }} />
                </F.Row>
              </>
            )}

            {tab === "Audio" && (
              <>
                <div className="mb-3 text-[13px] font-semibold text-[#e8e8e8]">Audio</div>
                <F.Row label="Sample rate">
                  <F.Sel value={String(m.sampleRate)} onChange={(e) => { m.sampleRate = Number(e.target.value) as 44100 | 48000; upd(); }}>
                    <option value="44100">44.1 kHz</option>
                    <option value="48000">48 kHz</option>
                  </F.Sel>
                </F.Row>
                <F.Row label="Channels">
                  <F.Sel value={String(m.audioChannels)} onChange={(e) => { m.audioChannels = Number(e.target.value) as 1 | 2 | 6; upd(); }}>
                    <option value="1">Mono</option>
                    <option value="2">Stereo</option>
                    <option value="6">5.1</option>
                  </F.Sel>
                </F.Row>
                <F.Row label="Monitoring device">
                  <F.Sel value={m.monitorDevice} onChange={(e) => { m.monitorDevice = e.target.value; upd(); }}>
                    <option>System Default</option>
                    <option>Speakers (Realtek)</option>
                    <option>Headphones (Focusrite USB)</option>
                    <option>External Monitor Speakers</option>
                  </F.Sel>
                </F.Row>
                <F.Row label="Peak meter type">
                  <F.Sel value={m.peakMeterType} onChange={(e) => { m.peakMeterType = e.target.value as "sample" | "true"; upd(); }}>
                    <option value="sample">Sample peak</option>
                    <option value="true">True peak</option>
                  </F.Sel>
                </F.Row>
                <F.Row label="Low-latency mode">
                  <F.Check label="Prefer low-latency audio path (WASAPI exclusive)" checked={m.lowLatencyAudio} onChange={(v) => { m.lowLatencyAudio = v; upd(); }} />
                </F.Row>
              </>
            )}

            {tab === "Video" && (
              <>
                <div className="mb-3 text-[13px] font-semibold text-[#e8e8e8]">Video</div>
                <F.Row label="Base (canvas) resolution">
                  <F.Sel value={m.baseCanvas} onChange={(e) => { m.baseCanvas = e.target.value; upd(); }}>
                    <option>1920x1080</option><option>2560x1440</option>
                    <option>3840x2160</option><option>1280x720</option>
                  </F.Sel>
                </F.Row>
                <F.Row label="Output (scaled) resolution">
                  <F.Sel value={m.outputScaled} onChange={(e) => { m.outputScaled = e.target.value; upd(); }}>
                    <option>1920x1080</option><option>1280x720</option>
                    <option>854x480</option><option>3840x2160</option>
                  </F.Sel>
                </F.Row>
                <F.Row label="Downscale filter">
                  <F.Sel value={m.scaleFilter} onChange={(e) => { m.scaleFilter = e.target.value as any; upd(); }}>
                    <option value="bilinear">Bilinear (fastest)</option>
                    <option value="bicubic">Bicubic</option>
                    <option value="lanczos">Lanczos (sharpest)</option>
                    <option value="area">Area</option>
                  </F.Sel>
                </F.Row>
                <F.Row label="Common FPS values">
                  <F.Sel value={String(m.fpsTarget)} onChange={(e) => { m.fpsTarget = Number(e.target.value); upd(); }}>
                    <option value="24">24</option><option value="30">30</option>
                    <option value="48">48</option><option value="60">60</option>
                    <option value="120">120</option>
                  </F.Sel>
                </F.Row>
              </>
            )}

            {tab === "Hotkeys" && (
              <>
                <div className="mb-3 text-[13px] font-semibold text-[#e8e8e8]">Hotkeys</div>
                <div className="mb-2 text-[11px] text-[#9a9a9a]">Click a binding to change it; press any key. ESC cancels.</div>
                <div className="space-y-1">
                  {Object.entries(m.hotkeys).map(([action, binding]) => (
                    <div key={action} className="grid grid-cols-[180px_1fr] items-center gap-4">
                      <div className="text-[12px] capitalize text-[#dcdcdc]">{action.replace(/([A-Z])/g, " $1")}</div>
                      <button
                        onClick={() => setHotkeyEditing(action)}
                        onKeyDown={hotkeyEditing === action ? bindHotkey(action) : undefined}
                        className={`w-[180px] rounded border px-3 py-1.5 text-left text-[12px] ${
                          hotkeyEditing === action
                            ? "border-[#3d6ea8] bg-[#2a3a55] text-white"
                            : "border-[#111] bg-[#2b2b2b] text-[#e8e8e8] hover:border-[#333]"
                        }`}
                      >
                        {hotkeyEditing === action ? "Press any key…" : binding}
                      </button>
                    </div>
                  ))}
                </div>
              </>
            )}

            {tab === "Advanced" && (
              <>
                <div className="mb-3 text-[13px] font-semibold text-[#e8e8e8]">General</div>
                <F.Row label="Process priority" hint="Recommended: Above Normal or High while streaming.">
                  <F.Sel value={m.processPriority} onChange={(e) => { m.processPriority = e.target.value as any; upd(); }}>
                    <option value="idle">Idle</option>
                    <option value="below-normal">Below normal</option>
                    <option value="normal">Normal</option>
                    <option value="above-normal">Above normal</option>
                    <option value="high">High</option>
                  </F.Sel>
                </F.Row>
                <div className="mb-2 mt-6 text-[13px] font-semibold text-[#e8e8e8]">Video</div>
                <F.Row label="Color format">
                  <F.Sel value={m.colorFormat} onChange={(e) => { m.colorFormat = e.target.value as any; upd(); }}>
                    <option>NV12</option><option>I420</option><option>P010</option><option>RGB</option>
                  </F.Sel>
                </F.Row>
                <F.Row label="YUV color space">
                  <F.Sel value={m.colorSpace} onChange={(e) => { m.colorSpace = e.target.value as any; upd(); }}>
                    <option value="601">Rec. 601</option>
                    <option value="709">Rec. 709</option>
                    <option value="2100-PQ">Rec. 2100 (PQ)</option>
                    <option value="2100-HLG">Rec. 2100 (HLG)</option>
                  </F.Sel>
                </F.Row>
                <F.Row label="YUV color range">
                  <F.Sel value={m.colorRange} onChange={(e) => { m.colorRange = e.target.value as any; upd(); }}>
                    <option value="partial">Partial (limited)</option>
                    <option value="full">Full</option>
                  </F.Sel>
                </F.Row>
                <F.Row label="Browser sources">
                  <F.Check label="Enable hardware acceleration for browser sources" checked={m.browserHwAccel} onChange={(v) => { m.browserHwAccel = v; upd(); }} />
                </F.Row>
              </>
            )}
          </div>
        </div>

        <div className="flex items-center justify-end gap-2 border-t border-[#1a1a1a] bg-[#2b2b2b] px-4 py-2.5">
          <button onClick={onClose} className="rounded border border-[#111] bg-[#3a3a3a] px-4 py-1.5 text-[12px] text-white hover:bg-[#4a4a4a]">Close</button>
        </div>
      </div>
    </div>
  );
}
