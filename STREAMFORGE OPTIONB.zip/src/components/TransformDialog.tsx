import { useEffect, useState } from "react";
import { CW, CH, clamp, type Src } from "../engine/types";
import { sfx } from "../engine/sfx";

interface Props {
  source: Src | null;
  onClose: () => void;
  bump: () => void;
}

interface St {
  x: number; y: number; w: number; h: number;
  zoom: number;
  cropL: number; cropR: number; cropT: number; cropB: number;
  angleX: number; angleY: number;
}

const fromSource = (s: Src): St => ({
  x: s.x, y: s.y, w: s.w, h: s.h,
  zoom: Math.round((s.w / s.bw) * 100),
  cropL: s.cropL ?? 0, cropR: s.cropR ?? 0, cropT: s.cropT ?? 0, cropB: s.cropB ?? 0,
  angleX: s.angleX ?? 0, angleY: s.angleY ?? 0,
});

function SliderRow({ label, value, min, max, unit, accent, onChange, onDone }: {
  label: string;
  value: number;
  min: number;
  max: number;
  unit: string;
  accent?: string;
  onChange: (v: number) => void;
  onDone: () => void;
}) {
  return (
    <div className="flex items-center gap-2.5">
      <span className="panel-label w-16 flex-none text-[10px] text-fog-400">{label}</span>
      <input
        type="range"
        min={min}
        max={max}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        onPointerUp={onDone}
        onKeyUp={(e) => {
          if (e.key.startsWith("Arrow")) onDone();
        }}
        className="h-1.5 min-w-0 flex-1 cursor-pointer appearance-none rounded-full bg-ink-600 accent-[#2fd273]"
        aria-label={label}
      />
      <span className={`w-12 flex-none text-right font-mono text-[11px] ${accent ?? "text-fog-200"}`}>
        {value}{unit}
      </span>
    </div>
  );
}

export default function TransformDialog({ source, onClose, bump }: Props) {
  const [st, setSt] = useState<St | null>(source ? fromSource(source) : null);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.stopPropagation();
        onClose();
      }
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, [onClose]);

  if (!source || !st) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-6" onClick={onClose}>
        <div className="anim-rise w-[380px] rounded-lg border border-ink-600 bg-ink-850 p-6 text-center shadow-2xl" onClick={(e) => e.stopPropagation()}>
          <h3 className="panel-label text-[16px] font-semibold tracking-[0.14em] text-fog-100">Source Transform</h3>
          <p className="mt-2 font-mono text-[10.5px] leading-relaxed text-fog-400">
            No source is selected.<br />Click a source on the Preview monitor, then double-click to edit its crop, zoom and angles.
          </p>
          <button onClick={onClose} className="btn panel-label mt-4 rounded-md border border-ink-600 bg-ink-750 px-6 py-2 text-[12px] text-fog-200 hover:border-prv hover:text-prv">
            Close
          </button>
        </div>
      </div>
    );
  }

  const set = (patch: Partial<St>) => setSt((v) => (v ? { ...v, ...patch } : v));

  const write = (fn: (s: Src) => void) => {
    fn(source);
    bump();
  };

  const setZoom = (z: number) => {
    const nz = clamp(z, 25, 250);
    const cx = source.x + source.w / 2, cy = source.y + source.h / 2;
    const nw = Math.round((source.bw * nz) / 100);
    write((s) => {
      s.w = nw;
      s.h = Math.round((nw * s.bh) / s.bw);
      s.x = Math.round(cx - s.w / 2);
      s.y = Math.round(cy - s.h / 2);
    });
    set({ zoom: nz, x: source.x, y: source.y, w: source.w, h: source.h });
  };

  const setNum = (k: "x" | "y" | "w" | "h", v: number) => {
    write((s) => {
      if (k === "w" || k === "h") {
        const ratio = s.bw / s.bh;
        if (k === "w") { s.w = clamp(v, 120, CW * 1.8); s.h = Math.round(s.w / ratio); }
        else { s.h = clamp(v, 68, CH * 1.8); s.w = Math.round(s.h * ratio); }
      } else {
        s[k] = v;
      }
    });
    set({ x: source.x, y: source.y, w: source.w, h: source.h, zoom: Math.round((source.w / source.bw) * 100) });
  };

  const setCrops = (k: "cropL" | "cropR" | "cropT" | "cropB", v: number) => {
    write((s) => { s[k] = v; });
    set({ [k]: v } as Partial<St>);
  };

  const setAngle = (k: "angleX" | "angleY", v: number) => {
    write((s) => { s[k] = v; });
    set({ [k]: v } as Partial<St>);
  };

  const resetAll = () => {
    write((s) => {
      s.cropL = 0; s.cropR = 0; s.cropT = 0; s.cropB = 0;
      s.angleX = 0; s.angleY = 0;
      const cx = s.x + s.w / 2, cy = s.y + s.h / 2;
      s.w = s.bw; s.h = s.bh;
      s.x = Math.round(cx - s.w / 2); s.y = Math.round(cy - s.h / 2);
    });
    setSt(fromSource(source));
    sfx.play("select");
  };

  const numIn =
    "w-full rounded border border-ink-600 bg-ink-900 px-2 py-1 font-mono text-[10.5px] text-fog-200 focus:border-prv focus:outline-none";

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-6" onClick={onClose}>
      <div
        className="anim-rise max-h-[88vh] w-[440px] overflow-y-auto rounded-lg border border-ink-600 bg-ink-850 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
        onKeyDown={(e) => {
          if (e.key === "Escape") {
            e.stopPropagation();
            onClose();
          }
        }}
      >
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-ink-700 bg-ink-850 px-4 py-3">
          <div className="min-w-0">
            <h3 className="panel-label text-[15px] font-semibold tracking-[0.14em] text-fog-100">Source Transform</h3>
            <p className="truncate font-mono text-[9.5px] text-fog-500">{source.name} • live on preview</p>
          </div>
          <button onClick={onClose} className="btn rounded border border-ink-600 bg-ink-750 px-2 py-1 font-mono text-[10px] text-fog-300 hover:text-prg">
            ESC
          </button>
        </div>

        <div className="space-y-4 p-4">
          {/* position & size */}
          <section>
            <div className="panel-label mb-1.5 text-[10px] text-fog-500">Position & Size</div>
            <div className="grid grid-cols-4 gap-1.5">
              {(["x", "y", "w", "h"] as const).map((k) => (
                <label key={k} className="block">
                  <span className="panel-label mb-0.5 block text-[9px] text-fog-500">{k.toUpperCase()}</span>
                  <input
                    type="number"
                    className={numIn}
                    value={Math.round(st[k])}
                    onChange={(e) => setNum(k, Number(e.target.value) || 0)}
                  />
                </label>
              ))}
            </div>
          </section>

          {/* zoom */}
          <section>
            <div className="panel-label mb-1.5 text-[10px] text-fog-500">Zoom</div>
            <SliderRow label="Scale" value={st.zoom} min={25} max={250} unit="%" accent="text-prv" onChange={setZoom} onDone={() => { sfx.play("tick"); bump(); }} />
          </section>

          {/* cropping */}
          <section>
            <div className="panel-label mb-1.5 text-[10px] text-fog-500">Cropping</div>
            <div className="space-y-2">
              <SliderRow label="Left" value={st.cropL} min={0} max={45} unit="%" onChange={(v) => setCrops("cropL", v)} onDone={() => { sfx.play("tick"); bump(); }} />
              <SliderRow label="Right" value={st.cropR} min={0} max={45} unit="%" onChange={(v) => setCrops("cropR", v)} onDone={() => { sfx.play("tick"); bump(); }} />
              <SliderRow label="Top" value={st.cropT} min={0} max={45} unit="%" onChange={(v) => setCrops("cropT", v)} onDone={() => { sfx.play("tick"); bump(); }} />
              <SliderRow label="Bottom" value={st.cropB} min={0} max={45} unit="%" onChange={(v) => setCrops("cropB", v)} onDone={() => { sfx.play("tick"); bump(); }} />
            </div>
          </section>

          {/* angles */}
          <section>
            <div className="panel-label mb-1.5 text-[10px] text-fog-500">Angle — projected rotation</div>
            <div className="space-y-2">
              <SliderRow label="Angle X" value={st.angleX} min={-85} max={85} unit="°" accent="text-amb" onChange={(v) => setAngle("angleX", v)} onDone={() => { sfx.play("tick"); bump(); }} />
              <SliderRow label="Angle Y" value={st.angleY} min={-85} max={85} unit="°" accent="text-amb" onChange={(v) => setAngle("angleY", v)} onDone={() => { sfx.play("tick"); bump(); }} />
            </div>
            <p className="mt-1.5 font-mono text-[8.5px] leading-relaxed text-fog-500">
              Angle X tilts about the horizontal axis, Angle Y about the vertical — both preview in real time.
            </p>
          </section>
        </div>

        <div className="flex gap-2 border-t border-ink-700 p-3">
          <button onClick={resetAll} className="btn panel-label flex-1 rounded-md border border-ink-600 bg-ink-750 py-2 text-[12px] text-fog-200 hover:border-amb hover:text-amb">
            Reset all
          </button>
          <button onClick={() => { sfx.play("tick"); onClose(); }} className="btn panel-label flex-1 rounded-md border border-prv/60 bg-prv-dim/40 py-2 text-[12px] font-semibold text-prv hover:bg-prv hover:text-ink-950">
            Done
          </button>
        </div>
      </div>
    </div>
  );
}
