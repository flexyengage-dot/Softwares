import { useRef, useState } from "react";

/**
 * Makes a floating panel draggable by its handle. The panel stays inside the
 * viewport. Returns the current position plus props to spread on the handle.
 */
export function useDraggable(initial: { x: number; y: number }) {
  const [pos, setPos] = useState(() => ({
    x: Math.min(Math.max(8, initial.x), Math.max(8, window.innerWidth - 356)),
    y: Math.min(Math.max(8, initial.y), Math.max(8, window.innerHeight - 120)),
  }));
  const drag = useRef<{ dx: number; dy: number } | null>(null);

  const onPointerDown = (e: React.PointerEvent) => {
    drag.current = { dx: e.clientX - pos.x, dy: e.clientY - pos.y };
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  };
  const onPointerMove = (e: React.PointerEvent) => {
    if (!drag.current) return;
    const x = Math.min(Math.max(8, e.clientX - drag.current.dx), window.innerWidth - 120);
    const y = Math.min(Math.max(8, e.clientY - drag.current.dy), window.innerHeight - 60);
    setPos({ x, y });
  };
  const onPointerUp = () => {
    drag.current = null;
  };

  return {
    pos,
    handleProps: { onPointerDown, onPointerMove, onPointerUp },
    style: { left: pos.x, top: pos.y } as React.CSSProperties,
  };
}
